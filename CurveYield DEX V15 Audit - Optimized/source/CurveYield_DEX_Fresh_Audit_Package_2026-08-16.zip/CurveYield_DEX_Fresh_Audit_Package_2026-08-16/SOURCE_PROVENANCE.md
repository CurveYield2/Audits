# Source Provenance and Licensing

## CurveYield Source

The active CurveYield source was copied from:

`contracts-repo/CurveYield DEX/contracts/`

Modified CurveYield contracts use the licensing identifiers present in their source headers. No license identifier was rewritten while preparing this package.

## Balancer V3 Upstream

- Local source root: `vendor/balancer-v3-upstream`
- Git revision: `80fd29ce4eb627139694db7fef5aba355759d303`
- Included packages: interfaces, vault, pool-utils, solidity-utils, pool-weighted, pool-stable, pool-hooks, and standalone-utils.
- The upstream `LICENSE` file is included verbatim.
- Contracts classified as pure upstream are compiled directly from this tree without CurveYield source edits.

## Balancer ReClamm Upstream

- Local source root: `vendor/balancer-reclamm-upstream`
- Git revision: `d65021227c10366cfb17798d8fa5d827744d70a3`
- Included source: the upstream `contracts/` tree and project build metadata.
- ReClamm source SPDX identifiers remain unchanged.

## Other Dependencies

- OpenZeppelin Contracts version is locked by `package-lock.json` and a source snapshot is included under `third-party-dependencies/`.
- Uniswap Permit2 is locked by `package-lock.json` and a source snapshot is included under `third-party-dependencies/`.
- Base WETH and Permit2 are external standard infrastructure addresses, not CurveYield deployments.

## Important Distinction

CurveYield deploys new instances of the unmodified Balancer contracts. It does not intend to reuse Balancer-governed deployed Vault, router, fee-controller, or factory addresses.

