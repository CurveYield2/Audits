# CurveYield DEX Fresh Audit Package Plan

**Goal:** Produce a self-contained, authoritative audit package for the fresh CurveYield-owned Balancer V3-style DEX deployment on Base.

**Scope:** Active contracts, deployment/configuration scripts, compiler tooling, selected upstream source dependencies, dependency snapshots, current evidence, provenance records, and checksums. Historical deployments and superseded implementations are excluded.

## Tasks

- [x] Inventory the exact active deployment source and deployment entrypoints.
- [x] Copy active CurveYield contracts and tooling without modifying the source tree.
- [x] Copy the Balancer V3 and ReClamm source trees required by the compiler.
- [x] Include OpenZeppelin and Permit2 source snapshots used as dependencies.
- [x] Document contract lineage, purpose, relationships, and deployment status.
- [x] Run the source-identical compilation/preflight and preserve the output.
- [x] Generate a SHA-256 manifest and verify every manifest entry.
- [x] Produce and inspect the final ZIP archive.

## Hard Boundaries

- No on-chain broadcast.
- No use of archived or superseded CurveYield source.
- No edits to upstream Balancer or ReClamm source.
- No claim of deployment readiness while the Vault build exceeds EIP-170.
- The CurveYield DAO is the intended final owner: `0x7142b1Cc5F91A736A62e77581F406338328F05bC`.
