# Build and Deployment Status

## Reproduction

From the package root:

```powershell
Set-Location -LiteralPath '.\workspace\contracts-repo\CurveYield DEX'
npm.cmd ci
npm.cmd run ops:test-curveyield-dex-current
npm.cmd run ops:preflight-curveyield-dex-fresh
```

The preflight command compiles the deployment set, checks the Base chain ID and configured fee cap, reads the current deployer nonce, predicts deterministic deployment addresses, and writes a JSON report. It does not broadcast because it passes `--dry-run`.

## Deployment Entrypoints

- `tooling/scripts/deployCurveYieldDexFresh.mjs`: deployment and post-deployment configuration.
- `tooling/scripts/simulateCurveYieldDexFresh.mjs`: stateful Base simulation attempt.
- `tooling/scripts/curveYieldDexBytecodeSize.mjs`: CurveYield hook/controller runtime-size gate.
- `tooling/lib/compileSolc.mjs`: current generic grouped compiler helper.
- `hardhat.config.cjs`: local and fork simulation configuration.

## Intended Base Parameters

- Chain ID: `8453`
- DAO/final owner: `0x7142b1Cc5F91A736A62e77581F406338328F05bC`
- Gas cap: `0.15 gwei`
- Pool creation fee: `0.00011 ETH`, payable to the DAO
- Protocol swap-fee percentage: `30%` of generated swap-fee revenue
- Protocol yield-fee percentage: `0%`
- Global combined swap-fee cap: `15%`
- Default payout token: `0xd7bb4c715d66a3ac3742ab9d2e2f5274da17ce22`

## Current Validation Evidence

- `evidence/ops-test-current.log`: 12 test files and 62 tests passed in the saved run.
- `evidence/preflight-fresh-current.log`: all 31 expected deployment artifacts compiled in the saved dry run.
- `evidence/bytecode-size-current.log`: CurveYield hooks and controllers measured below EIP-170.
- `evidence/hardhat-fork-deploy-simulation.log`: Hardhat Base fork-engine failure.
- `evidence/hardhat-local-deploy-gas-baseline.log`: local execution that reached the Vault size failure.
- `evidence/curveyield-dex-fresh-2026-07-26T04-56-16-327Z.json`: partial deployment report.

## Blocking Issue

The active helper uses Solidity 0.8.30, via-IR, and 1,000 optimizer runs for every group. Balancer's production build uses contract-specific compiler and optimizer settings. The best upstream-style experiment reduced the Vault runtime to 24,587 bytes, which remains 11 bytes above the EIP-170 maximum of 24,576 bytes.

The required remediation is to reproduce Balancer's exact verified compiler configuration and artifact. The Vault source must remain unmodified.

## Broadcast Status

No fresh deployment transaction has been broadcast. The local partial addresses in evidence files are ephemeral simulation addresses and are not production deployments.

