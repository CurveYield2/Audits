# CurveYield DEX Fresh Audit Package

This package contains the current source and operational tooling for a fresh CurveYield-owned Balancer V3-style DEX deployment on Base.

## Audit Target

The target is the source compiled and deployed by:

`workspace/contracts-repo/CurveYield DEX/tooling/scripts/deployCurveYieldDexFresh.mjs`

The intended deployment contains 31 global contracts plus one `CreatorFeeSplitter` deployed for each new pool by `CurveYieldPoolFactoryWrapper`.

## Package Layout

- `workspace/contracts-repo/CurveYield DEX/contracts/`: active CurveYield contracts only.
- `workspace/contracts-repo/CurveYield DEX/tooling/`: deployment, simulation, source-sync, bytecode-size, and test tooling.
- `workspace/vendor/balancer-v3-upstream/`: selected upstream Balancer V3 packages required by the build.
- `workspace/vendor/balancer-reclamm-upstream/`: upstream ReClamm contracts required by the build.
- `third-party-dependencies/`: review copies of OpenZeppelin Contracts and Uniswap Permit2 source.
- `evidence/`: prior test, preflight, size, simulation, and partial execution output.
- `CONTRACT_CLASSIFICATION_AND_ROLES.md`: contract lineage and architecture map.
- `BUILD_AND_DEPLOYMENT_STATUS.md`: exact build instructions and current blocker.
- `SOURCE_PROVENANCE.md`: upstream revisions and licensing boundaries.
- `SHA256SUMS.txt`: generated content-integrity manifest.

## Authoritative Scope

Only files inside this package are in scope. Historical V5-V14 deployment reports, superseded hook implementations, old addresses, and the source repository's `ARCHIVE DO NOT USE` directory are deliberately excluded.

## Current Status

- No fresh CurveYield DEX deployment has been broadcast.
- A saved dry run compiled all 31 expected deployment artifacts.
- A saved test run reports 62 of 62 tests passing.
- The active generic compiler helper does not yet reproduce Balancer's production Vault artifact. Its best measured Vault runtime is 24,587 bytes, 11 bytes above EIP-170.
- Auditors must treat the Vault compiler mismatch as a deployment blocker, not as authorization to modify Balancer's Vault source.

