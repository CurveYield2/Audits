# CurveYield DEX

CurveYield DEX contract package for a fresh CurveYield-owned Balancer V3-style deployment on Base.

## Active Rule

Use only the current source in `contracts/` and current tooling in `tooling/`.

Do not use any historical deployment plan, historical address manifest, old support-stack script, old audit package, or old test bundle from `ARCHIVE DO NOT USE/`.

The next production deployment must be a fresh deployment of the CurveYield DEX stack. The retained external address is the CurveYield DAO Aragon address only.

## Active Contract Set

- Fee policy and splitting: `PoolFeePolicyRegistry`, `AdminFeeSplitter`, `CreatorFeeSplitter`
- Settlement: `FeeSettlementRouter`, `FeeSettlementKeeper`
- Migration and same-pool route support: `RouteRegistry`, `BalancerV3SwapAdapter`
- Protocol-owned liquidity: `PermanentLiquidityVaultV2`
- Pool creation: `CurveYieldPoolFactoryWrapper`
- Factory access control: `CurveYieldFactoryAllowlist`
- Pool factories: `CurveYieldWeightedPoolFactory`, `CurveYieldStablePoolFactory`, `CurveYieldStableSurgePoolFactory`, `CurveYieldReClammPoolFactory`
- Hooks and controllers: `CurveYieldMevVolumeHookV14`, `CurveYieldStableSurgeVolumeHookV14`, `CurveYieldHookConfigController`, `CurveYieldObservationController`, `CurveYieldVolumeFeeController`, `ObservationQueryProcessor`, `StableSurgeQueryProcessor`

## Archive Boundary

`ARCHIVE DO NOT USE/` contains superseded V5/V8/V13/V14 artifacts, old deployment reports, old scripts, stale handoff packages, and obsolete pre-V14 hook implementations. It is intentionally kept in the repo folder for forensic reference only.

No private keys or secrets are included in this folder.
