import { describe, expect, it } from 'vitest';

const WAD = 10n ** 18n;
const BPS = 10_000n;

function mulDiv(x, y, denominator) {
  return (x * y) / denominator;
}

function quoteAdmin(amount, creatorPlBps, extraPlBps, partnerBps) {
  const creatorPl = mulDiv(amount, creatorPlBps, BPS);
  const extraPl = mulDiv(amount, extraPlBps, BPS);
  const partner = mulDiv(amount, partnerBps, BPS);
  return { creatorPl, extraPl, partner, treasury: amount - creatorPl - extraPl - partner };
}

function quoteCreator(amount, personalBps, permanentBps, partnerBps) {
  const totalBps = personalBps + permanentBps + partnerBps;
  if (totalBps === 0n) {
    return { creator: 0n, admin: 0n, permanent: 0n, partner: 0n, partnerAdmin: 0n, dust: amount };
  }
  const personal = mulDiv(amount, personalBps, totalBps);
  const partnerGross = mulDiv(amount, partnerBps, totalBps);
  const admin = mulDiv(personal, 3_300n, BPS);
  const partnerAdmin = mulDiv(partnerGross, 3_300n, BPS);
  const permanent = mulDiv(amount, permanentBps, totalBps);
  const creator = personal - admin;
  const partner = partnerGross - partnerAdmin;
  const allocated = creator + admin + permanent + partner + partnerAdmin;
  return { creator, admin, permanent, partner, partnerAdmin, dust: amount - allocated };
}

function nextRandom(state) {
  return (state * 6_364_136_223_846_793_005n + 1_442_695_040_888_963_407n) & ((1n << 64n) - 1n);
}

describe('CurveYield DEX audit remediation models', () => {
  it('uses static DAO admin allocation bps over collected admin-fee revenue', () => {
    const allocation = quoteAdmin(300_050n, 3_000n, 0n, 0n);

    expect(allocation.creatorPl).toBe(90_015n);
    expect(allocation.treasury).toBe(210_035n);
  });

  it('sends the full protocol fee to treasury when no DAO allocation is configured', () => {
    expect(quoteAdmin(987_654_321n, 0n, 0n, 0n)).toEqual({
      creatorPl: 0n,
      extraPl: 0n,
      partner: 0n,
      treasury: 987_654_321n,
    });
    expect(quoteAdmin(123n, 0n, 0n, 0n).treasury).toBe(123n);
  });

  it('conserves every unit across 10,000 valid randomized admin and creator allocations', () => {
    let state = 0x4355525645594945n;
    for (let i = 0; i < 10_000; i += 1) {
      state = nextRandom(state);
      const adminCapacityBps = 1n + (state % 10_000n);
      state = nextRandom(state);
      const creatorPlBps = state % (adminCapacityBps + 1n);
      state = nextRandom(state);
      const extraPlBps = state % (adminCapacityBps - creatorPlBps + 1n);
      state = nextRandom(state);
      const partnerBps = state % (adminCapacityBps - creatorPlBps - extraPlBps + 1n);
      state = nextRandom(state);
      const amount = 1n + (state % (10n ** 30n));

      const admin = quoteAdmin(
        amount,
        creatorPlBps,
        extraPlBps,
        partnerBps,
      );
      expect(admin.creatorPl + admin.extraPl + admin.partner + admin.treasury).toBe(amount);
      expect(admin.treasury).toBeGreaterThanOrEqual(0n);

      state = nextRandom(state);
      const personalBps = state % 2_001n;
      state = nextRandom(state);
      const permanentBps = state % 5_001n;
      state = nextRandom(state);
      const maxPartner = 2_000n < 9_000n - personalBps - permanentBps
        ? 2_000n
        : 9_000n - personalBps - permanentBps;
      const creatorPartnerBps = state % (maxPartner + 1n);
      const creator = quoteCreator(amount, personalBps, permanentBps, creatorPartnerBps);
      expect(
        creator.creator + creator.admin + creator.permanent + creator.partner + creator.partnerAdmin + creator.dust,
      ).toBe(amount);
      expect(creator.dust).toBeLessThanOrEqual(2n);
    }
  });

  it('keeps oracle-derived minima positive from zero through 99.99% settlement slippage', () => {
    const quote = WAD;
    for (const slippageBps of [0n, 1n, 100n, 5_000n, 9_999n]) {
      const minimum = mulDiv(quote, BPS - slippageBps, BPS);
      expect(minimum).toBeGreaterThan(0n);
      expect(minimum).toBeLessThanOrEqual(quote);
    }
  });

  it('attributes dust by settlement delta without double-counting shared tokens', () => {
    const ledger = new Map();
    const account = (pool, start, end) => {
      const delta = end - start;
      ledger.set(pool, (ledger.get(pool) ?? 0n) + delta);
      return delta;
    };

    expect(account('pool-a', 40n, 43n)).toBe(3n);
    expect(account('pool-b', 43n, 48n)).toBe(5n);
    expect(ledger.get('pool-a')).toBe(3n);
    expect(ledger.get('pool-b')).toBe(5n);
    expect([...ledger.values()].reduce((sum, value) => sum + value, 0n)).toBe(8n);
  });
});
