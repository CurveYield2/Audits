// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract supports a CurveYield implementation derived from Balancer's smart contracts.
 * Balancer's gracious use of open-source GPL licensing allows CurveYield to use it for the good of all.
 */

import { CurveYieldPoolKind } from "../../../contracts/hooks/CurveYieldHookTypes.sol";
import { VolumeAdaptiveFee } from "../../../contracts/hooks/VolumeAdaptiveFee.sol";

contract CurveYieldHookMathHarness {
    function weightedTurnover(
        uint256 amountGivenScaled18,
        uint256 selectedWeight,
        uint256 selectedBalanceScaled18
    ) external pure returns (uint256) {
        return VolumeAdaptiveFee.weightedTurnover(amountGivenScaled18, selectedWeight, selectedBalanceScaled18);
    }

    function stableTurnover(
        uint256 amountGivenScaled18,
        uint256[] calldata balancesScaled18
    ) external pure returns (uint256) {
        return VolumeAdaptiveFee.stableTurnover(amountGivenScaled18, balancesScaled18);
    }

    function decayActivity(
        uint256 previousActivity,
        uint256 elapsedSeconds,
        uint256 halfLifeSeconds
    ) external pure returns (uint256) {
        return VolumeAdaptiveFee.decayActivity(previousActivity, elapsedSeconds, halfLifeSeconds);
    }

    function nextActivity(
        uint256 previousActivity,
        uint256 turnover,
        uint256 elapsedSeconds,
        uint256 halfLifeSeconds
    ) external pure returns (uint128) {
        return VolumeAdaptiveFee.nextActivity(previousActivity, turnover, elapsedSeconds, halfLifeSeconds);
    }

    function threshold(
        CurveYieldPoolKind kind,
        uint8 reactiveness,
        uint8 halfLifeHours
    ) external pure returns (uint256) {
        return VolumeAdaptiveFee.threshold(kind, reactiveness, halfLifeHours);
    }

    function volumeSurcharge(
        uint256 activity,
        uint256 thresholdValue,
        uint256 maximumSurcharge
    ) external pure returns (uint256) {
        return VolumeAdaptiveFee.volumeSurcharge(activity, thresholdValue, maximumSurcharge);
    }

    function validateConfig(
        CurveYieldPoolKind kind,
        uint256 maxVolumeSurcharge,
        uint8 reactiveness,
        uint8 halfLifeHours
    ) external pure {
        VolumeAdaptiveFee.validateConfig(kind, maxVolumeSurcharge, reactiveness, halfLifeHours);
    }

    function evaluateVector(
        CurveYieldPoolKind kind,
        uint256 amountGivenScaled18,
        uint256 selectedWeight,
        uint256 selectedBalanceScaled18,
        uint256[] calldata balancesScaled18,
        uint256 previousActivity,
        uint256 turnover,
        uint256 elapsedSeconds,
        uint256 halfLifeSeconds,
        uint8 reactiveness,
        uint8 halfLifeHours,
        uint256 activity,
        uint256 maximumSurcharge
    )
        external
        pure
        returns (
            uint256 weighted,
            uint256 stable,
            uint256 decay,
            uint256 thresholdValue,
            uint256 surcharge,
            uint128 accumulated
        )
    {
        weighted = VolumeAdaptiveFee.weightedTurnover(
            amountGivenScaled18,
            selectedWeight,
            selectedBalanceScaled18
        );
        stable = VolumeAdaptiveFee.stableTurnover(amountGivenScaled18, balancesScaled18);
        decay = VolumeAdaptiveFee.decayActivity(previousActivity, elapsedSeconds, halfLifeSeconds);
        thresholdValue = VolumeAdaptiveFee.threshold(kind, reactiveness, halfLifeHours);
        surcharge = VolumeAdaptiveFee.volumeSurcharge(activity, thresholdValue, maximumSurcharge);
        accumulated = VolumeAdaptiveFee.nextActivity(
            previousActivity,
            turnover,
            elapsedSeconds,
            halfLifeSeconds
        );
    }
}
