import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  createPublicClient,
  createTestClient,
  createWalletClient,
  getContract,
  http,
  parseEther,
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { compileContracts } from '../lib/compileSolc.mjs';

const rpcUrl = 'http://127.0.0.1:8628';
const chain = {
  id: 31337,
  name: 'anvil',
  nativeCurrency: { name: 'ETH', symbol: 'ETH', decimals: 18 },
  rpcUrls: {},
};
const owner = privateKeyToAccount('0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80');
const alice = privateKeyToAccount('0x1111111111111111111111111111111111111111111111111111111111111111');
const pool = '0x0000000000000000000000000000000000003001';

const zeroCreatorConfig = {
  creatorPersonalBps: 0,
  creatorPermanentLiquidityBps: 0,
  creatorPartnerRevenueBps: 0,
};
const zeroAdminConfig = {
  adminCreatorPermanentLiquidityBps: 0,
  adminExtraPermanentPoLBps: 0,
  adminPartnerRevenueBps: 0,
};
const disabledPartnerPoL = {
  enabled: false,
  targetPool: '0x0000000000000000000000000000000000000000',
};
const mockHooksConfig = {
  enableHookAdjustedAmounts: false,
  shouldCallBeforeInitialize: false,
  shouldCallAfterInitialize: false,
  shouldCallComputeDynamicSwapFee: false,
  shouldCallBeforeSwap: false,
  shouldCallAfterSwap: false,
  shouldCallBeforeAddLiquidity: false,
  shouldCallAfterAddLiquidity: false,
  shouldCallBeforeRemoveLiquidity: false,
  shouldCallAfterRemoveLiquidity: false,
  hooksContract: owner.address,
};

async function waitForAnvil() {
  const startedAt = Date.now();
  while (Date.now() - startedAt < 15_000) {
    try {
      const response = await fetch(rpcUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_blockNumber', params: [] }),
      });
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  throw new Error('Timed out waiting for bounded local Anvil');
}

async function deploy(walletClient, publicClient, artifact, args = []) {
  const hash = await walletClient.deployContract({
    abi: artifact.abi,
    bytecode: artifact.bytecode,
    args,
    account: walletClient.account,
  });
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  expect(receipt.status).toBe('success');
  return getContract({
    address: receipt.contractAddress,
    abi: artifact.abi,
    client: { public: publicClient },
  });
}

async function write(publicClient, walletClient, contract, functionName, args = []) {
  const hash = await walletClient.writeContract({
    address: contract.address,
    abi: contract.abi,
    functionName,
    args,
    account: walletClient.account,
  });
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  expect(receipt.status).toBe('success');
}

async function expectRevert(publicClient, walletClient, contract, functionName, args = []) {
  await expect(
    publicClient.simulateContract({
      address: contract.address,
      abi: contract.abi,
      functionName,
      args,
      account: walletClient.account,
    }),
  ).rejects.toThrow();
}

describe('CurveYield fee settlement isolation', () => {
  let anvil;
  let shutdownTimer;
  let publicClient;
  let testClient;
  let ownerClient;
  let aliceClient;
  let artifacts;
  let token;
  let vault;
  let controller;
  let registry;
  let adminSplitter;
  let mockRouter;
  let feeRouter;
  let creatorSplitter;
  let keeper;

  beforeAll(async () => {
    ({ compiled: artifacts } = compileContracts(
      [
        'contracts/PoolFeePolicyRegistry.sol',
        'contracts/AdminFeeSplitter.sol',
        'contracts/CreatorFeeSplitter.sol',
        'contracts/RouteRegistry.sol',
        'contracts/FeeSettlementRouter.sol',
        'contracts/FeeSettlementKeeper.sol',
        'tooling/test/contracts/CurveYieldDexAuditMocks.sol',
      ],
      [
        'PoolFeePolicyRegistry',
        'AdminFeeSplitter',
        'CreatorFeeSplitter',
        'RouteRegistry',
        'FeeSettlementRouter',
        'FeeSettlementKeeper',
        'MockDexERC20',
        'MockDexVault',
        'MockDexProtocolFeeController',
        'MockDexBalancerRouter',
      ],
    ));

    const anvilPath = process.env.ANVIL_PATH || 'C:\\Users\\user\\.foundry\\bin\\anvil.exe';
    if (!fs.existsSync(anvilPath)) throw new Error(`Anvil not found at ${anvilPath}`);
    anvil = spawn(anvilPath, ['--port', '8628', '--silent'], {
      cwd: process.cwd(),
      stdio: 'ignore',
      windowsHide: true,
    });
    shutdownTimer = setTimeout(() => {
      if (anvil && !anvil.killed) anvil.kill();
    }, 5 * 60_000);
    shutdownTimer.unref();
    await waitForAnvil();

    publicClient = createPublicClient({ chain, transport: http(rpcUrl) });
    testClient = createTestClient({ chain, mode: 'anvil', transport: http(rpcUrl) });
    ownerClient = createWalletClient({ account: owner, chain, transport: http(rpcUrl) });
    aliceClient = createWalletClient({ account: alice, chain, transport: http(rpcUrl) });
    await testClient.setBalance({ address: alice.address, value: parseEther('10') });

    token = await deploy(ownerClient, publicClient, artifacts.MockDexERC20, ['Fee Token', 'FEE']);
    vault = await deploy(ownerClient, publicClient, artifacts.MockDexVault);
    controller = await deploy(ownerClient, publicClient, artifacts.MockDexProtocolFeeController);
    registry = await deploy(ownerClient, publicClient, artifacts.PoolFeePolicyRegistry, [
      owner.address,
      vault.address,
    ]);
    adminSplitter = await deploy(ownerClient, publicClient, artifacts.AdminFeeSplitter, [
      registry.address,
    ]);
    mockRouter = await deploy(ownerClient, publicClient, artifacts.MockDexBalancerRouter);
    feeRouter = await deploy(ownerClient, publicClient, artifacts.FeeSettlementRouter, [
      owner.address,
      controller.address,
      adminSplitter.address,
      owner.address,
      vault.address,
      mockRouter.address,
      owner.address,
      token.address,
    ]);
    creatorSplitter = await deploy(ownerClient, publicClient, artifacts.CreatorFeeSplitter, [
      owner.address,
      registry.address,
      controller.address,
      feeRouter.address,
      pool,
    ]);
    keeper = await deploy(ownerClient, publicClient, artifacts.FeeSettlementKeeper, [feeRouter.address]);

    await write(publicClient, ownerClient, vault, 'setPoolTokens', [pool, [token.address]]);
    await write(publicClient, ownerClient, vault, 'setHooksConfig', [pool, mockHooksConfig]);
    await write(publicClient, ownerClient, controller, 'setPoolTokens', [pool, [token.address]]);
    await write(publicClient, ownerClient, controller, 'setMockProtocolSwapFeePercentage', [
      pool,
      300_000_000_000_000_000n,
    ]);
    await write(publicClient, ownerClient, registry, 'registerPool', [[
      pool,
      2,
      creatorSplitter.address,
      alice.address,
      alice.address,
      '0x0000000000000000000000000000000000000000',
      '0x0000000000000000000000000000000000000000',
      zeroCreatorConfig,
      zeroAdminConfig,
      disabledPartnerPoL,
    ]].flat());
    await write(publicClient, ownerClient, feeRouter, 'setCreatorFeeSplitter', [
      pool,
      creatorSplitter.address,
    ]);
    await write(publicClient, ownerClient, feeRouter, 'setKeeper', [keeper.address, true]);
  }, 180_000);

  afterAll(async () => {
    if (shutdownTimer) clearTimeout(shutdownTimer);
    if (anvil && !anvil.killed) anvil.kill();
  });

  async function fundFees(protocolAmount, creatorAmount = 0n) {
    await write(publicClient, ownerClient, controller, 'setFeeAmounts', [
      pool,
      [protocolAmount],
      [creatorAmount],
    ]);
    await write(publicClient, ownerClient, token, 'mint', [
      controller.address,
      protocolAmount + creatorAmount,
    ]);
  }

  it('settles ordinary fees when Partner PoL is disabled', async () => {
    const treasuryBefore = await token.read.balanceOf([owner.address]);
    await fundFees(1_000n);
    await write(publicClient, aliceClient, keeper, 'collect', [pool]);
    expect(await token.read.balanceOf([owner.address])).toBe(treasuryBefore + 1_000n);
    expect(await token.read.balanceOf([feeRouter.address])).toBe(0n);
    expect(await token.read.balanceOf([controller.address])).toBe(0n);
  });

  it('keeps strict Partner PoL atomic when the program is disabled', async () => {
    await fundFees(1_000n);
    const controllerBefore = await token.read.balanceOf([controller.address]);
    await expectRevert(publicClient, aliceClient, keeper, 'collectPartnerPoL', [pool]);
    expect(await token.read.balanceOf([controller.address])).toBe(controllerBefore);
    expect(await token.read.balanceOf([feeRouter.address])).toBe(0n);
  });

  it('redirects the optional Partner PoL allocation to fee converter storage when protected settlement is unavailable', async () => {
    await write(publicClient, ownerClient, registry, 'updateAdminFeeConfig', [
      pool,
      {
        adminCreatorPermanentLiquidityBps: 0,
        adminExtraPermanentPoLBps: 100,
        adminPartnerRevenueBps: 0,
      },
    ]);
    await write(publicClient, ownerClient, registry, 'updatePartnerPoLConfig', [
      pool,
      {
        enabled: true,
        targetPool: pool,
      },
    ]);
    const treasuryBefore = await token.read.balanceOf([owner.address]);
    const controllerBefore = await token.read.balanceOf([controller.address]);
    await fundFees(3_000n);
    await write(publicClient, aliceClient, keeper, 'collect', [pool]);
    expect(await token.read.balanceOf([owner.address])).toBe(treasuryBefore + 3_000n);
    expect(await token.read.balanceOf([feeRouter.address])).toBe(0n);
    expect(await token.read.balanceOf([controller.address])).toBe(controllerBefore);
  });

  it('keeps strict Partner PoL atomic when the protected settlement path is unavailable', async () => {
    await fundFees(3_000n);
    const controllerBefore = await token.read.balanceOf([controller.address]);
    await expectRevert(publicClient, aliceClient, keeper, 'collectPartnerPoL', [pool]);
    expect(await token.read.balanceOf([controller.address])).toBe(controllerBefore);
    expect(await token.read.balanceOf([feeRouter.address])).toBe(0n);
  });
});
