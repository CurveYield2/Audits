import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  createPublicClient,
  createTestClient,
  createWalletClient,
  encodeAbiParameters,
  getContract,
  http,
  parseEther,
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { compileContracts } from '../lib/compileSolc.mjs';

const rpcUrl = 'http://127.0.0.1:8627';
const chain = {
  id: 31337,
  name: 'anvil',
  nativeCurrency: { name: 'ETH', symbol: 'ETH', decimals: 18 },
  rpcUrls: {},
};
const owner = privateKeyToAccount('0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80');
const alice = privateKeyToAccount('0x1111111111111111111111111111111111111111111111111111111111111111');
const bob = privateKeyToAccount('0x2222222222222222222222222222222222222222222222222222222222222222');
const pool = '0x0000000000000000000000000000000000001001';
const targetPool = '0x0000000000000000000000000000000000001002';
const creatorPool = '0x0000000000000000000000000000000000001003';
const unregisteredPool = '0x0000000000000000000000000000000000001004';
const tokenA = '0x0000000000000000000000000000000000002001';
const tokenB = '0x0000000000000000000000000000000000002002';

const zeroCreatorConfig = {
  creatorPersonalBps: 0,
  creatorPermanentLiquidityBps: 0,
  creatorPartnerRevenueBps: 0,
};
const zeroAdminConfig = {
  adminCreatorPermanentLiquidityBps: 0,
  adminExtraPermanentPoLBps: 0,
  adminPartnerRevenueBps: 0,
};
const disabledPartnerPoL = {
  enabled: false,
  targetPool: '0x0000000000000000000000000000000000000000',
};
const mockHooksConfig = {
  enableHookAdjustedAmounts: false,
  shouldCallBeforeInitialize: false,
  shouldCallAfterInitialize: false,
  shouldCallComputeDynamicSwapFee: false,
  shouldCallBeforeSwap: false,
  shouldCallAfterSwap: false,
  shouldCallBeforeAddLiquidity: false,
  shouldCallAfterAddLiquidity: false,
  shouldCallBeforeRemoveLiquidity: false,
  shouldCallAfterRemoveLiquidity: false,
  hooksContract: owner.address,
};

async function waitForAnvil() {
  const startedAt = Date.now();
  while (Date.now() - startedAt < 15_000) {
    try {
      const response = await fetch(rpcUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_blockNumber', params: [] }),
      });
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  throw new Error('Timed out waiting for bounded local Anvil');
}

async function deploy(walletClient, publicClient, artifact, args = []) {
  const hash = await walletClient.deployContract({
    abi: artifact.abi,
    bytecode: artifact.bytecode,
    args,
    account: walletClient.account,
  });
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  expect(receipt.status).toBe('success');
  return getContract({
    address: receipt.contractAddress,
    abi: artifact.abi,
    client: { public: publicClient },
  });
}

async function write(publicClient, walletClient, contract, functionName, args = []) {
  const hash = await walletClient.writeContract({
    address: contract.address,
    abi: contract.abi,
    functionName,
    args,
    account: walletClient.account,
  });
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  expect(receipt.status).toBe('success');
}

async function expectRevert(publicClient, walletClient, contract, functionName, args = []) {
  await expect(
    publicClient.simulateContract({
      address: contract.address,
      abi: contract.abi,
      functionName,
      args,
      account: walletClient.account,
    }),
  ).rejects.toThrow();
}

function registerArgs(
  registeredPool,
  splitter,
  controller = alice.address,
  receiver = alice.address,
  creatorConfig = zeroCreatorConfig,
  adminConfig = zeroAdminConfig,
  partnerConfig = disabledPartnerPoL,
) {
  return [
    registeredPool,
    2,
    splitter,
    controller,
    receiver,
    '0x0000000000000000000000000000000000000000',
    '0x0000000000000000000000000000000000000000',
    creatorConfig,
    adminConfig,
    partnerConfig,
  ];
}

describe('CurveYield DEX audit remediation runtime', () => {
  let anvil;
  let shutdownTimer;
  let publicClient;
  let testClient;
  let ownerClient;
  let aliceClient;
  let bobClient;
  let artifacts;
  let vault;
  let controller;
  let registry;
  let adminSplitter;

  beforeAll(async () => {
    ({ compiled: artifacts } = compileContracts(
      [
        'contracts/PoolFeePolicyRegistry.sol',
        'contracts/AdminFeeSplitter.sol',
        'contracts/CreatorFeeSplitter.sol',
        'contracts/RouteRegistry.sol',
        'contracts/adapters/BalancerV3SwapAdapter.sol',
        'tooling/test/contracts/CurveYieldDexAuditMocks.sol',
      ],
      [
        'PoolFeePolicyRegistry',
        'AdminFeeSplitter',
        'CreatorFeeSplitter',
        'RouteRegistry',
        'BalancerV3SwapAdapter',
        'MockDexVault',
        'MockDexProtocolFeeController',
        'MockDexBalancerRouter',
        'MockDexCreatorFeeSplitter',
      ],
    ));

    const anvilPath = process.env.ANVIL_PATH || 'C:\\Users\\user\\.foundry\\bin\\anvil.exe';
    if (!fs.existsSync(anvilPath)) throw new Error(`Anvil not found at ${anvilPath}`);
    anvil = spawn(anvilPath, ['--port', '8627', '--silent'], {
      cwd: process.cwd(),
      stdio: 'ignore',
      windowsHide: true,
    });
    shutdownTimer = setTimeout(() => {
      if (anvil && !anvil.killed) anvil.kill();
    }, 5 * 60_000);
    shutdownTimer.unref();
    await waitForAnvil();

    publicClient = createPublicClient({ chain, transport: http(rpcUrl) });
    testClient = createTestClient({ chain, mode: 'anvil', transport: http(rpcUrl) });
    ownerClient = createWalletClient({ account: owner, chain, transport: http(rpcUrl) });
    aliceClient = createWalletClient({ account: alice, chain, transport: http(rpcUrl) });
    bobClient = createWalletClient({ account: bob, chain, transport: http(rpcUrl) });
    await testClient.setBalance({ address: alice.address, value: parseEther('10') });
    await testClient.setBalance({ address: bob.address, value: parseEther('10') });

    vault = await deploy(ownerClient, publicClient, artifacts.MockDexVault);
    controller = await deploy(ownerClient, publicClient, artifacts.MockDexProtocolFeeController);
    registry = await deploy(ownerClient, publicClient, artifacts.PoolFeePolicyRegistry, [
      owner.address,
      vault.address,
    ]);
    adminSplitter = await deploy(ownerClient, publicClient, artifacts.AdminFeeSplitter, [
      registry.address,
    ]);

    await write(publicClient, ownerClient, vault, 'setPoolTokens', [pool, [tokenA, tokenB]]);
    await write(publicClient, ownerClient, vault, 'setPoolTokens', [targetPool, [tokenA, tokenB]]);
    await write(publicClient, ownerClient, vault, 'setHooksConfig', [targetPool, mockHooksConfig]);
    await write(publicClient, ownerClient, vault, 'setPoolTokens', [creatorPool, [tokenA, tokenB]]);
    const targetSplitter = await deploy(ownerClient, publicClient, artifacts.MockDexCreatorFeeSplitter);
    const poolSplitter = await deploy(ownerClient, publicClient, artifacts.MockDexCreatorFeeSplitter);
    await write(publicClient, ownerClient, registry, 'registerPool', registerArgs(
      targetPool,
      targetSplitter.address,
      owner.address,
      owner.address,
    ));
    await write(publicClient, ownerClient, registry, 'registerPool', registerArgs(pool, poolSplitter.address));
  }, 180_000);

  afterAll(async () => {
    if (shutdownTimer) clearTimeout(shutdownTimer);
    if (anvil && !anvil.killed) anvil.kill();
  });

  it('allocates against static admin bps and conserves the residual', async () => {
    await write(publicClient, ownerClient, registry, 'updateAdminFeeConfig', [
      pool,
      {
        adminCreatorPermanentLiquidityBps: 3_000,
        adminExtraPermanentPoLBps: 0,
        adminPartnerRevenueBps: 0,
      },
    ]);
    const allocation = await adminSplitter.read.quoteAdminAllocation([pool, [300_050n]]);
    expect(allocation[0][0]).toBe(90_015n);
    expect(allocation[3][0]).toBe(210_035n);

    await write(publicClient, ownerClient, registry, 'updateAdminFeeConfig', [pool, zeroAdminConfig]);
    const treasuryOnly = await adminSplitter.read.quoteAdminAllocation([pool, [300_050n]]);
    expect(treasuryOnly[3][0]).toBe(300_050n);
  });

  it('validates Partner PoL targets and static admin allocation consistency', async () => {
    await write(publicClient, ownerClient, registry, 'updateAdminFeeConfig', [
      pool,
      {
        adminCreatorPermanentLiquidityBps: 0,
        adminExtraPermanentPoLBps: 100,
        adminPartnerRevenueBps: 0,
      },
    ]);
    const valid = {
      enabled: true,
      targetPool,
    };
    await expectRevert(publicClient, ownerClient, registry, 'updatePartnerPoLConfig', [
      pool,
      { ...valid, targetPool: unregisteredPool },
    ]);
    await write(publicClient, ownerClient, registry, 'updatePartnerPoLConfig', [pool, valid]);
    await expectRevert(publicClient, ownerClient, registry, 'updateAdminFeeConfig', [pool, zeroAdminConfig]);
    await write(publicClient, ownerClient, registry, 'updatePartnerPoLConfig', [pool, disabledPartnerPoL]);
    await write(publicClient, ownerClient, registry, 'updateAdminFeeConfig', [pool, zeroAdminConfig]);
  });

  it('keeps creator controller and payout state canonical in the registry', async () => {
    const creatorSplitter = await deploy(ownerClient, publicClient, artifacts.CreatorFeeSplitter, [
      owner.address,
      registry.address,
      controller.address,
      owner.address,
      creatorPool,
    ]);
    await write(publicClient, ownerClient, registry, 'registerPool', registerArgs(
      creatorPool,
      creatorSplitter.address,
      alice.address,
      alice.address,
    ));

    await write(publicClient, aliceClient, creatorSplitter, 'setCreatorPayoutReceiver', [bob.address]);
    expect(await registry.read.creatorPayoutReceiverOf([creatorPool])).toBe(bob.address);
    expect(await creatorSplitter.read.creatorPayoutReceiver()).toBe(bob.address);

    await write(publicClient, ownerClient, registry, 'requestCreatorControllerTransfer', [
      creatorPool,
      bob.address,
    ]);
    await expectRevert(
      publicClient,
      aliceClient,
      registry,
      'acceptCreatorControllerTransfer',
      [creatorPool],
    );
    await write(publicClient, bobClient, registry, 'acceptCreatorControllerTransfer', [creatorPool]);
    expect(await creatorSplitter.read.creatorController()).toBe(bob.address);
  });

  it('invalidates every existing route immediately when its adapter is revoked', async () => {
    const routes = await deploy(ownerClient, publicClient, artifacts.RouteRegistry, [owner.address]);
    await write(publicClient, ownerClient, routes, 'setAdapterAllowed', [owner.address, true]);
    await write(publicClient, ownerClient, routes, 'setRoute', [
      tokenA,
      tokenB,
      owner.address,
      '0x1234',
      true,
    ]);
    expect((await routes.read.getExecutableRoute([tokenA, tokenB]))[0]).toBe(owner.address);
    await write(publicClient, ownerClient, routes, 'setAdapterAllowed', [owner.address, false]);
    await expectRevert(publicClient, ownerClient, routes, 'getExecutableRoute', [tokenA, tokenB]);
  });

  it('prevents unauthorized accounts from consuming swap-adapter balances', async () => {
    const mockRouter = await deploy(ownerClient, publicClient, artifacts.MockDexBalancerRouter);
    const adapter = await deploy(ownerClient, publicClient, artifacts.BalancerV3SwapAdapter, [
      owner.address,
      mockRouter.address,
      owner.address,
    ]);
    const routeData = encodeAbiParameters(
      [{ type: 'address' }, { type: 'bool' }, { type: 'bytes' }],
      [pool, false, '0x'],
    );
    await expectRevert(publicClient, aliceClient, adapter, 'swap', [
      tokenA,
      tokenB,
      1n,
      1n,
      routeData,
    ]);
  });
});
