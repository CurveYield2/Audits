import fs from "node:fs";
import path from "node:path";
import {
  createPublicClient,
  createWalletClient,
  defineChain,
  encodeDeployData,
  encodeFunctionData,
  getContractAddress,
  custom,
  http,
  parseAbi,
  toFunctionSelector,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { compileContracts } from "../lib/compileSolc.mjs";
import { balancerReClammRoot, balancerV3Root, dexRoot } from "../lib/paths.mjs";

const DRY_RUN = process.argv.includes("--dry-run");
const USE_HARDHAT_PROVIDER = process.env.CURVEYIELD_USE_HARDHAT_PROVIDER === "1";
const BASE_CHAIN_ID = 8453;
const BASE_RPC_URL =
  process.env.BASE_RPC_URL ||
  "https://base.blockpi.network/v1/rpc/5dc6f4de0d718b40b40a14ea237ffc11ddbb82a4";
const DAO = envAddress(
  "CURVEYIELD_DAO",
  "0x7142b1Cc5F91A736A62e77581F406338328F05bC",
);
const DEFAULT_PAYOUT_TOKEN = envAddress(
  "CURVEYIELD_DEFAULT_PAYOUT_TOKEN",
  "0xd7bb4c715d66a3ac3742ab9d2e2f5274da17ce22",
);
const WETH = envAddress("WETH", "0x4200000000000000000000000000000000000006");
const PERMIT2 = envAddress(
  "PERMIT2",
  "0x000000000022D473030F116dDEE9F6B43aC78BA3",
);
const MAX_FEE_PER_GAS = envBigInt("MAX_FEE_PER_GAS_WEI", 150_000_000n);
const MAX_PRIORITY_FEE_PER_GAS = envBigInt("MAX_PRIORITY_FEE_PER_GAS_WEI", 1_000_000n);
const POOL_CREATION_FEE_WEI = envBigInt("POOL_CREATION_FEE_WEI", 110_000_000_000_000n);
const ROOT_TRANSFER_DELAY = envBigInt("ROOT_TRANSFER_DELAY_SECONDS", 0n);

const FP_ONE = 10n ** 18n;
const PROTOCOL_SWAP_FEE_PERCENTAGE = envBigInt(
  "PROTOCOL_SWAP_FEE_PERCENTAGE",
  300_000_000_000_000_000n,
);
const PROTOCOL_YIELD_FEE_PERCENTAGE = envBigInt("PROTOCOL_YIELD_FEE_PERCENTAGE", 0n);
const VAULT_PAUSE_WINDOW_SECONDS = Number(envBigInt("VAULT_PAUSE_WINDOW_SECONDS", 365n * 24n * 60n * 60n));
const VAULT_BUFFER_PERIOD_SECONDS = Number(envBigInt("VAULT_BUFFER_PERIOD_SECONDS", 30n * 24n * 60n * 60n));
const FACTORY_PAUSE_WINDOW_SECONDS = Number(
  envBigInt("FACTORY_PAUSE_WINDOW_SECONDS", 365n * 24n * 60n * 60n),
);
const MIN_TRADE_AMOUNT = envBigInt("MIN_TRADE_AMOUNT", 1_000_000n);
const MIN_WRAP_AMOUNT = envBigInt("MIN_WRAP_AMOUNT", 1_000_000n);
const DEFAULT_MEV_TAX_MULTIPLIER = envBigInt("DEFAULT_MEV_TAX_MULTIPLIER", 0n);
const DEFAULT_MEV_TAX_THRESHOLD = envBigInt("DEFAULT_MEV_TAX_THRESHOLD", 0n);
const DEFAULT_MAX_SURGE_FEE_PERCENTAGE = envBigInt(
  "DEFAULT_MAX_SURGE_FEE_PERCENTAGE",
  800_000_000_000_000_000n,
);
const DEFAULT_SURGE_THRESHOLD_PERCENTAGE = envBigInt(
  "DEFAULT_SURGE_THRESHOLD_PERCENTAGE",
  300_000_000_000_000_000n,
);
const GLOBAL_COMBINED_FEE_CAP = envBigInt("GLOBAL_COMBINED_FEE_CAP", 150_000_000_000_000_000n);

const REPORT_PATH = path.join(
  dexRoot,
  "deployment-artifacts",
  `curveyield-dex-fresh-${new Date().toISOString().replace(/[:.]/g, "-")}.json`,
);

const base = defineChain({
  id: BASE_CHAIN_ID,
  name: "Base",
  nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
  rpcUrls: { default: { http: [BASE_RPC_URL] } },
  blockExplorers: { default: { name: "BaseScan", url: "https://basescan.org" } },
});

const hardhatRuntime = USE_HARDHAT_PROVIDER ? (await import("hardhat")).default : null;
const transport = USE_HARDHAT_PROVIDER ? custom(hardhatRuntime.network.provider) : http(BASE_RPC_URL);
const publicClient = createPublicClient({ chain: base, transport });

const coreEntries = [
  "contracts/CurveYieldBootstrapAuthorizer.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/authorizer/TimelockAuthorizer.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/ProtocolFeeController.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/VaultAdmin.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/VaultExtension.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/Vault.sol",
];
const routerEntries = [
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/Router.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/BatchRouter.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/CompositeLiquidityRouter.sol",
  "../../vendor/balancer-v3-upstream/pkg/standalone-utils/contracts/BalancerContractRegistry.sol",
  "../../vendor/balancer-v3-upstream/pkg/standalone-utils/contracts/ProtocolFeeSweeper.sol",
];
const supportEntries = [
  "../../vendor/balancer-reclamm-upstream/contracts/ReClammPoolHelper.sol",
  "contracts/AdminFeeSplitter.sol",
  "contracts/CreatorFeeSplitter.sol",
  "contracts/FeeSettlementKeeper.sol",
  "contracts/FeeSettlementRouter.sol",
  "contracts/PermanentLiquidityVaultV2.sol",
  "contracts/PoolFeePolicyRegistry.sol",
  "contracts/RouteRegistry.sol",
  "contracts/adapters/BalancerV3SwapAdapter.sol",
];
const hooksEntries = [
  "contracts/hooks/CurveYieldHookConfigController.sol",
  "contracts/hooks/CurveYieldMevVolumeHookV14.sol",
  "contracts/hooks/CurveYieldObservationController.sol",
  "contracts/hooks/CurveYieldStableSurgeVolumeHookV14.sol",
  "contracts/hooks/CurveYieldVolumeFeeController.sol",
  "contracts/hooks/ObservationQueryProcessor.sol",
  "contracts/hooks/StableSurgeQueryProcessor.sol",
];
const factoryEntries = [
  "contracts/CurveYieldPoolFactoryWrapper.sol",
  "contracts/factories/CurveYieldReClammPoolFactory.sol",
  "contracts/factories/CurveYieldStablePoolFactory.sol",
  "contracts/factories/CurveYieldStableSurgePoolFactory.sol",
  "contracts/factories/CurveYieldWeightedPoolFactory.sol",
];

const expectedContracts = [
  "CurveYieldBootstrapAuthorizer",
  "ProtocolFeeController",
  "VaultAdmin",
  "VaultExtension",
  "Vault",
  "TimelockAuthorizer",
  "Router",
  "BatchRouter",
  "CompositeLiquidityRouter",
  "BalancerContractRegistry",
  "ProtocolFeeSweeper",
  "ReClammPoolHelper",
  "PoolFeePolicyRegistry",
  "AdminFeeSplitter",
  "RouteRegistry",
  "PermanentLiquidityVaultV2",
  "FeeSettlementRouter",
  "FeeSettlementKeeper",
  "BalancerV3SwapAdapter",
  "CurveYieldHookConfigController",
  "ObservationQueryProcessor",
  "CurveYieldObservationController",
  "CurveYieldVolumeFeeController",
  "StableSurgeQueryProcessor",
  "CurveYieldMevVolumeHookV14",
  "CurveYieldStableSurgeVolumeHookV14",
  "CurveYieldWeightedPoolFactory",
  "CurveYieldStablePoolFactory",
  "CurveYieldStableSurgePoolFactory",
  "CurveYieldReClammPoolFactory",
  "CurveYieldPoolFactoryWrapper",
];

const authAbi = parseAbi([
  "function grantPermission(bytes32 actionId,address account,address where)",
  "function hasPermission(bytes32 actionId,address account,address where) view returns (bool)",
  "function isRoot(address account) view returns (bool)",
  "function getPendingRoot() view returns (address)",
]);
const authenticatedAbi = parseAbi([
  "function getActionId(bytes4 selector) view returns (bytes32)",
]);

const report = {
  mode: USE_HARDHAT_PROVIDER ? "hardhat-fork-simulation" : DRY_RUN ? "dry-run" : "broadcast",
  startedAt: new Date().toISOString(),
  baseRpcUrl: BASE_RPC_URL,
  chainId: BASE_CHAIN_ID,
  dao: DAO,
  defaultPayoutToken: DEFAULT_PAYOUT_TOKEN,
  weth: WETH,
  permit2: PERMIT2,
  maxFeePerGasWei: MAX_FEE_PER_GAS.toString(),
  maxPriorityFeePerGasWei: MAX_PRIORITY_FEE_PER_GAS.toString(),
  upstreamRoots: {
    balancerV3Root,
    balancerReClammRoot,
  },
  compileEntryGroups: {
    coreEntries,
    routerEntries,
    supportEntries,
    hooksEntries,
    factoryEntries,
  },
  parameters: {
    protocolSwapFeePercentage: PROTOCOL_SWAP_FEE_PERCENTAGE.toString(),
    protocolYieldFeePercentage: PROTOCOL_YIELD_FEE_PERCENTAGE.toString(),
    vaultPauseWindowSeconds: VAULT_PAUSE_WINDOW_SECONDS,
    vaultBufferPeriodSeconds: VAULT_BUFFER_PERIOD_SECONDS,
    factoryPauseWindowSeconds: FACTORY_PAUSE_WINDOW_SECONDS,
    minTradeAmount: MIN_TRADE_AMOUNT.toString(),
    minWrapAmount: MIN_WRAP_AMOUNT.toString(),
    poolCreationFeeWei: POOL_CREATION_FEE_WEI.toString(),
    defaultMevTaxMultiplier: DEFAULT_MEV_TAX_MULTIPLIER.toString(),
    defaultMevTaxThreshold: DEFAULT_MEV_TAX_THRESHOLD.toString(),
    defaultMaxSurgeFeePercentage: DEFAULT_MAX_SURGE_FEE_PERCENTAGE.toString(),
    defaultSurgeThresholdPercentage: DEFAULT_SURGE_THRESHOLD_PERCENTAGE.toString(),
    globalCombinedFeeCap: GLOBAL_COMBINED_FEE_CAP.toString(),
  },
  deployer: null,
  startingNonce: null,
  predictedDeployments: [],
  deployments: {},
  configTransactions: [],
  permissionGrants: [],
  ownershipTransfers: [],
};

async function main() {
  const privateKey = loadPrivateKey();
  const account = privateKeyToAccount(privateKey);
  const walletClient = createWalletClient({ account, chain: base, transport });
  report.deployer = account.address;
  if (USE_HARDHAT_PROVIDER) {
    await hardhatRuntime.network.provider.request({
      method: "hardhat_setBalance",
      params: [account.address, "0x56bc75e2d63100000"],
    });
  }

  const chainId = await publicClient.getChainId();
  if (chainId !== BASE_CHAIN_ID) throw new Error(`Wrong chain id ${chainId}; expected ${BASE_CHAIN_ID}`);
  const latestBlock = await publicClient.getBlock({ blockTag: "latest" });
  if ((latestBlock.baseFeePerGas || 0n) > MAX_FEE_PER_GAS) {
    throw new Error(
      `Base fee ${latestBlock.baseFeePerGas} exceeds maxFeePerGas ${MAX_FEE_PER_GAS}; refusing to send`,
    );
  }

  const startingNonce = await publicClient.getTransactionCount({ address: account.address, blockTag: "pending" });
  report.startingNonce = startingNonce;
  let nextNonce = startingNonce;

  console.log(`Mode: ${report.mode}`);
  console.log(`Deployer: ${account.address}`);
  console.log(`Pending nonce: ${startingNonce}`);
  console.log(`DAO/final owner: ${DAO}`);
  console.log(`Gas cap: ${MAX_FEE_PER_GAS} wei`);
  console.log("Compiling active CurveYield DEX deployment set...");

  const artifacts = compileAll();
  for (const name of expectedContracts) {
    if (!artifacts[name]) throw new Error(`Missing compiled artifact: ${name}`);
  }
  console.log(`Compiled ${Object.keys(artifacts).length} contract artifacts needed for deployment.`);

  const plannedDeployNames = expectedContracts;
  for (let i = 0; i < plannedDeployNames.length; i += 1) {
    report.predictedDeployments.push({
      nonce: startingNonce + i,
      name: plannedDeployNames[i],
      expectedAddress: getContractAddress({ from: account.address, nonce: BigInt(startingNonce + i) }),
    });
  }
  saveReport();

  if (DRY_RUN) {
    console.log(`Dry-run report written: ${REPORT_PATH}`);
    return;
  }

  const deployments = {};
  const libraries = {};
  const deploy = async (name, args = [], options = {}) => {
    const expected = getContractAddress({ from: account.address, nonce: BigInt(nextNonce) });
    const artifact = artifacts[name];
    const bytecode = linkBytecode(artifact, libraries);
    const data = encodeDeployData({ abi: artifact.abi, bytecode, args });
    const gas = await estimateGasWithMargin({ account: account.address, data, value: 0n });
    console.log(`Deploying ${name} nonce=${nextNonce} expected=${expected} gas=${gas}`);
    const hash = await walletClient.sendTransaction({
      account,
      chain: base,
      data,
      gas,
      maxFeePerGas: MAX_FEE_PER_GAS,
      maxPriorityFeePerGas: MAX_PRIORITY_FEE_PER_GAS,
      nonce: nextNonce,
      value: 0n,
    });
    nextNonce += 1;
    const receipt = await publicClient.waitForTransactionReceipt({ hash, confirmations: 1, timeout: 120_000 });
    if (receipt.status !== "success") throw new Error(`${name} deployment reverted: ${hash}`);
    if (receipt.contractAddress?.toLowerCase() !== expected.toLowerCase()) {
      throw new Error(`${name} deployed at ${receipt.contractAddress}; expected ${expected}`);
    }
    deployments[name] = receipt.contractAddress;
    if (options.library) libraries[name] = receipt.contractAddress;
    report.deployments[name] = {
      address: receipt.contractAddress,
      transactionHash: hash,
      gasUsed: receipt.gasUsed.toString(),
      nonce: nextNonce - 1,
      sourceName: artifact.sourceName,
    };
    saveReport();
    return receipt.contractAddress;
  };

  const predictedVault = report.predictedDeployments.find((entry) => entry.name === "Vault").expectedAddress;
  const bootstrapAuthorizer = await deploy("CurveYieldBootstrapAuthorizer", [account.address]);
  const protocolFeeController = await deploy("ProtocolFeeController", [
    predictedVault,
    PROTOCOL_SWAP_FEE_PERCENTAGE,
    PROTOCOL_YIELD_FEE_PERCENTAGE,
  ]);
  const vaultAdmin = await deploy("VaultAdmin", [
    predictedVault,
    VAULT_PAUSE_WINDOW_SECONDS,
    VAULT_BUFFER_PERIOD_SECONDS,
    MIN_TRADE_AMOUNT,
    MIN_WRAP_AMOUNT,
  ]);
  const vaultExtension = await deploy("VaultExtension", [predictedVault, vaultAdmin]);
  const vault = await deploy("Vault", [vaultExtension, bootstrapAuthorizer, protocolFeeController]);
  if (vault.toLowerCase() !== predictedVault.toLowerCase()) throw new Error("Predicted Vault mismatch");
  const authorizer = await deploy("TimelockAuthorizer", [account.address, DAO, vault, ROOT_TRANSFER_DELAY]);

  const router = await deploy("Router", [vault, WETH, PERMIT2, "CurveYield Router v1"]);
  const batchRouter = await deploy("BatchRouter", [vault, WETH, PERMIT2, "CurveYield BatchRouter v1"]);
  const compositeLiquidityRouter = await deploy("CompositeLiquidityRouter", [
    vault,
    WETH,
    PERMIT2,
    "CurveYield CompositeLiquidityRouter v1",
  ]);
  const contractRegistry = await deploy("BalancerContractRegistry", [vault]);
  const protocolFeeSweeper = await deploy("ProtocolFeeSweeper", [vault, DAO]);
  const reClammPoolHelper = await deploy("ReClammPoolHelper", [vault]);
  const poolFeePolicyRegistry = await deploy("PoolFeePolicyRegistry", [account.address, vault]);
  const adminFeeSplitter = await deploy("AdminFeeSplitter", [poolFeePolicyRegistry]);
  const routeRegistry = await deploy("RouteRegistry", [account.address]);
  const permanentLiquidityVault = await deploy("PermanentLiquidityVaultV2", [
    account.address,
    router,
    vault,
    routeRegistry,
    PERMIT2,
  ]);
  const feeSettlementRouter = await deploy("FeeSettlementRouter", [
    account.address,
    protocolFeeController,
    adminFeeSplitter,
    permanentLiquidityVault,
    vault,
    router,
    DAO,
    DEFAULT_PAYOUT_TOKEN,
  ]);
  const feeSettlementKeeper = await deploy("FeeSettlementKeeper", [feeSettlementRouter]);
  const balancerV3SwapAdapter = await deploy("BalancerV3SwapAdapter", [
    account.address,
    router,
    feeSettlementRouter,
  ]);
  const hookConfigController = await deploy("CurveYieldHookConfigController", [vault]);
  await deploy("ObservationQueryProcessor", [], { library: true });
  const observationController = await deploy("CurveYieldObservationController", [vault]);
  const volumeFeeController = await deploy("CurveYieldVolumeFeeController", [
    vault,
    poolFeePolicyRegistry,
    observationController,
  ]);
  await deploy("StableSurgeQueryProcessor", [], { library: true });
  const mevVolumeHook = await deploy("CurveYieldMevVolumeHookV14", [
    vault,
    contractRegistry,
    poolFeePolicyRegistry,
    hookConfigController,
    observationController,
    volumeFeeController,
    DEFAULT_MEV_TAX_MULTIPLIER,
    DEFAULT_MEV_TAX_THRESHOLD,
  ]);
  const stableSurgeVolumeHook = await deploy("CurveYieldStableSurgeVolumeHookV14", [
    vault,
    contractRegistry,
    poolFeePolicyRegistry,
    hookConfigController,
    observationController,
    volumeFeeController,
    DEFAULT_MAX_SURGE_FEE_PERCENTAGE,
    DEFAULT_SURGE_THRESHOLD_PERCENTAGE,
    "CurveYield StableSurge Volume Hook v1",
  ]);
  const weightedFactory = await deploy("CurveYieldWeightedPoolFactory", [
    vault,
    FACTORY_PAUSE_WINDOW_SECONDS,
    "CurveYield WeightedPoolFactory v1",
    "CurveYield WeightedPool v1",
    account.address,
  ]);
  const stableFactory = await deploy("CurveYieldStablePoolFactory", [
    vault,
    FACTORY_PAUSE_WINDOW_SECONDS,
    "CurveYield StablePoolFactory v1",
    "CurveYield StablePool v1",
    account.address,
  ]);
  const stableSurgeFactory = await deploy("CurveYieldStableSurgePoolFactory", [
    stableSurgeVolumeHook,
    FACTORY_PAUSE_WINDOW_SECONDS,
    "CurveYield StableSurgePoolFactory v1",
    "CurveYield StableSurgePool v1",
    account.address,
  ]);
  const reClammFactory = await deploy("CurveYieldReClammPoolFactory", [
    vault,
    reClammPoolHelper,
    FACTORY_PAUSE_WINDOW_SECONDS,
    "CurveYield ReClammPoolFactory v1",
    "CurveYield ReClammPool v1",
    account.address,
  ]);
  const wrapper = await deploy("CurveYieldPoolFactoryWrapper", [
    account.address,
    poolFeePolicyRegistry,
    protocolFeeController,
    feeSettlementRouter,
    stableSurgeFactory,
    stableFactory,
    weightedFactory,
    reClammFactory,
  ]);

  const call = async (label, address, abi, functionName, args = []) => {
    const data = encodeFunctionData({ abi, functionName, args });
    const gas = await estimateGasWithMargin({ account: account.address, to: address, data, value: 0n });
    console.log(`Config ${label} nonce=${nextNonce} gas=${gas}`);
    const hash = await walletClient.sendTransaction({
      account,
      chain: base,
      to: address,
      data,
      gas,
      maxFeePerGas: MAX_FEE_PER_GAS,
      maxPriorityFeePerGas: MAX_PRIORITY_FEE_PER_GAS,
      nonce: nextNonce,
      value: 0n,
    });
    nextNonce += 1;
    const receipt = await publicClient.waitForTransactionReceipt({ hash, confirmations: 1, timeout: 120_000 });
    if (receipt.status !== "success") throw new Error(`${label} reverted: ${hash}`);
    report.configTransactions.push({
      label,
      to: address,
      functionName,
      args: stringifyArgs(args),
      transactionHash: hash,
      gasUsed: receipt.gasUsed.toString(),
      nonce: nextNonce - 1,
    });
    saveReport();
  };

  const ownableAbi = parseAbi([
    "function transferOwnership(address newOwner)",
    "function owner() view returns (address)",
  ]);
  const vaultAbi = parseAbi(["function setAuthorizer(address newAuthorizer)"]);
  const registryAbi = artifacts.BalancerContractRegistry.abi;
  const hookConfigAbi = artifacts.CurveYieldHookConfigController.abi;
  const observationAbi = artifacts.CurveYieldObservationController.abi;
  const volumeFeeAbi = artifacts.CurveYieldVolumeFeeController.abi;
  const feeRouterAbi = artifacts.FeeSettlementRouter.abi;
  const feeRegistryAbi = artifacts.PoolFeePolicyRegistry.abi;
  const permanentVaultAbi = artifacts.PermanentLiquidityVaultV2.abi;
  const routeRegistryAbi = artifacts.RouteRegistry.abi;
  const swapAdapterAbi = artifacts.BalancerV3SwapAdapter.abi;
  const factoryAllowlistAbi = parseAbi(["function setAllowedPoolCreator(address account,bool allowed)"]);
  const wrapperAbi = artifacts.CurveYieldPoolFactoryWrapper.abi;

  const grant = async (target, targetAbi, signature, grantee, label) => {
    const selector = toFunctionSelector(signature);
    const actionId = await publicClient.readContract({
      address: target,
      abi: authenticatedAbi,
      functionName: "getActionId",
      args: [selector],
    });
    const already = await publicClient.readContract({
      address: authorizer,
      abi: authAbi,
      functionName: "hasPermission",
      args: [actionId, grantee, target],
    });
    if (already) return;
    await call(`grant ${label}`, authorizer, authAbi, "grantPermission", [actionId, grantee, target]);
    report.permissionGrants.push({ target, grantee, signature, actionId, label });
    saveReport();
  };

  await grant(contractRegistry, registryAbi, "registerBalancerContract(uint8,string,address)", account.address, "deployer registry register");
  await grant(contractRegistry, registryAbi, "addOrUpdateBalancerContractAlias(string,address)", account.address, "deployer registry alias");
  await grant(hookConfigController, hookConfigAbi, "setApprovedHook(address,bool)", account.address, "deployer hook-config approve hook");
  await grant(hookConfigController, hookConfigAbi, "setFactoryPoolKind(address,uint8)", account.address, "deployer hook-config factory kind");
  await grant(hookConfigController, hookConfigAbi, "setSettlementRouter(address,bool)", account.address, "deployer hook-config settlement router");
  await grant(hookConfigController, hookConfigAbi, "setGlobalCombinedFeeCap(uint256)", account.address, "deployer hook-config global fee cap");
  await grant(observationController, observationAbi, "setApprovedHook(address,bool)", account.address, "deployer observation approve hook");
  await grant(volumeFeeController, volumeFeeAbi, "setApprovedHook(address,bool)", account.address, "deployer volume approve hook");
  await grant(protocolFeeController, artifacts.ProtocolFeeController.abi, "withdrawProtocolFees(address,address)", feeSettlementRouter, "fee router withdraw protocol fees");

  for (const sig of [
    "registerBalancerContract(uint8,string,address)",
    "addOrUpdateBalancerContractAlias(string,address)",
  ]) {
    await grant(contractRegistry, registryAbi, sig, DAO, `DAO registry ${sig}`);
  }
  for (const sig of [
    "setApprovedHook(address,bool)",
    "setFactoryPoolKind(address,uint8)",
    "setSettlementRouter(address,bool)",
    "setGlobalCombinedFeeCap(uint256)",
    "setPoolCombinedFeeCap(address,bool,uint256)",
    "setSettlementOracleConfig(address,uint32,uint16)",
    "setProtectedSettlementPaused(bool)",
  ]) {
    await grant(hookConfigController, hookConfigAbi, sig, DAO, `DAO hook-config ${sig}`);
  }
  for (const sig of ["setApprovedHook(address,bool)"]) {
    await grant(observationController, observationAbi, sig, DAO, `DAO observation ${sig}`);
    await grant(volumeFeeController, volumeFeeAbi, sig, DAO, `DAO volume ${sig}`);
  }
  for (const sig of [
    "disableMevTax()",
    "enableMevTax()",
    "setMaxMevSwapFeePercentage(uint256)",
    "setDefaultMevTaxMultiplier(uint256)",
    "setDefaultMevTaxThreshold(uint256)",
    "addMevTaxExemptSenders(address[])",
    "removeMevTaxExemptSenders(address[])",
  ]) {
    await grant(mevVolumeHook, artifacts.CurveYieldMevVolumeHookV14.abi, sig, DAO, `DAO MEV hook ${sig}`);
  }

  await call("vault install TimelockAuthorizer", vault, vaultAbi, "setAuthorizer", [authorizer]);

  const ContractType = { OTHER: 0, POOL_FACTORY: 1, ROUTER: 2, HOOK: 3 };
  for (const [contractType, name, address] of [
    [ContractType.ROUTER, "curveyield-v1-router", router],
    [ContractType.ROUTER, "curveyield-v1-batch-router", batchRouter],
    [ContractType.ROUTER, "curveyield-v1-composite-liquidity-router", compositeLiquidityRouter],
    [ContractType.POOL_FACTORY, "curveyield-v1-weighted-pool-factory", weightedFactory],
    [ContractType.POOL_FACTORY, "curveyield-v1-stable-pool-factory", stableFactory],
    [ContractType.POOL_FACTORY, "curveyield-v1-stable-surge-pool-factory", stableSurgeFactory],
    [ContractType.POOL_FACTORY, "curveyield-v1-reclamm-pool-factory", reClammFactory],
    [ContractType.HOOK, "curveyield-v1-mev-volume-hook", mevVolumeHook],
    [ContractType.HOOK, "curveyield-v1-stable-surge-volume-hook", stableSurgeVolumeHook],
    [ContractType.OTHER, "curveyield-v1-protocol-fee-sweeper", protocolFeeSweeper],
    [ContractType.OTHER, "curveyield-v1-reclamm-pool-helper", reClammPoolHelper],
  ]) {
    await call(`registry register ${name}`, contractRegistry, registryAbi, "registerBalancerContract", [
      contractType,
      name,
      address,
    ]);
  }
  for (const [alias, address] of [
    ["Router", router],
    ["BatchRouter", batchRouter],
    ["CompositeLiquidityRouter", compositeLiquidityRouter],
    ["WeightedPool", weightedFactory],
    ["StablePool", stableFactory],
    ["StableSurgePool", stableSurgeFactory],
    ["ReClammPool", reClammFactory],
    ["MevCaptureHook", mevVolumeHook],
    ["StableSurgeHook", stableSurgeVolumeHook],
  ]) {
    await call(`registry alias ${alias}`, contractRegistry, registryAbi, "addOrUpdateBalancerContractAlias", [
      alias,
      address,
    ]);
  }

  await call("registry set wrapper registrar", poolFeePolicyRegistry, feeRegistryAbi, "setPoolRegistrar", [
    wrapper,
    true,
  ]);
  await call("route registry allow balancer adapter", routeRegistry, routeRegistryAbi, "setAdapterAllowed", [
    balancerV3SwapAdapter,
    true,
  ]);
  await call("permanent vault set settlement router", permanentLiquidityVault, permanentVaultAbi, "setSettlementRouter", [
    feeSettlementRouter,
  ]);
  await call("fee router approve keeper", feeSettlementRouter, feeRouterAbi, "setKeeper", [
    feeSettlementKeeper,
    true,
  ]);
  await call("fee router approve wrapper registrar", feeSettlementRouter, feeRouterAbi, "setCreatorFeeSplitterRegistrar", [
    wrapper,
    true,
  ]);
  await call("fee router approve MEV hook BPT settlement", feeSettlementRouter, feeRouterAbi, "setProtectedBptSettlementHook", [
    mevVolumeHook,
    true,
  ]);
  await call(
    "fee router approve StableSurge hook BPT settlement",
    feeSettlementRouter,
    feeRouterAbi,
    "setProtectedBptSettlementHook",
    [stableSurgeVolumeHook, true],
  );
  await call("swap adapter authorize permanent vault", balancerV3SwapAdapter, swapAdapterAbi, "setAuthorizedCaller", [
    permanentLiquidityVault,
    true,
  ]);
  await call("wrapper set creation fee", wrapper, wrapperAbi, "setPoolCreationFeeConfig", [
    DAO,
    POOL_CREATION_FEE_WEI,
  ]);

  for (const [label, factory] of [
    ["weighted", weightedFactory],
    ["stable", stableFactory],
    ["stable surge", stableSurgeFactory],
    ["reclamm", reClammFactory],
  ]) {
    await call(`factory allow wrapper ${label}`, factory, factoryAllowlistAbi, "setAllowedPoolCreator", [
      wrapper,
      true,
    ]);
  }

  const HookKind = { WEIGHTED: 1, STABLE: 2, STABLE_SURGE: 3 };
  for (const [label, factory, kind] of [
    ["weighted", weightedFactory, HookKind.WEIGHTED],
    ["stable", stableFactory, HookKind.STABLE],
    ["stable surge", stableSurgeFactory, HookKind.STABLE_SURGE],
  ]) {
    await call(`hook config factory kind ${label}`, hookConfigController, hookConfigAbi, "setFactoryPoolKind", [
      factory,
      kind,
    ]);
  }
  await call("hook config approve MEV hook", hookConfigController, hookConfigAbi, "setApprovedHook", [
    mevVolumeHook,
    true,
  ]);
  await call("hook config approve StableSurge hook", hookConfigController, hookConfigAbi, "setApprovedHook", [
    stableSurgeVolumeHook,
    true,
  ]);
  await call("hook config approve fee router settlement", hookConfigController, hookConfigAbi, "setSettlementRouter", [
    feeSettlementRouter,
    true,
  ]);
  await call("hook config set global combined fee cap", hookConfigController, hookConfigAbi, "setGlobalCombinedFeeCap", [
    GLOBAL_COMBINED_FEE_CAP,
  ]);
  for (const [label, hook] of [
    ["MEV", mevVolumeHook],
    ["StableSurge", stableSurgeVolumeHook],
  ]) {
    await call(`observation approve ${label} hook`, observationController, observationAbi, "setApprovedHook", [
      hook,
      true,
    ]);
    await call(`volume approve ${label} hook`, volumeFeeController, volumeFeeAbi, "setApprovedHook", [
      hook,
      true,
    ]);
  }

  for (const [name, address] of [
    ["PoolFeePolicyRegistry", poolFeePolicyRegistry],
    ["RouteRegistry", routeRegistry],
    ["PermanentLiquidityVaultV2", permanentLiquidityVault],
    ["FeeSettlementRouter", feeSettlementRouter],
    ["BalancerV3SwapAdapter", balancerV3SwapAdapter],
    ["CurveYieldWeightedPoolFactory", weightedFactory],
    ["CurveYieldStablePoolFactory", stableFactory],
    ["CurveYieldStableSurgePoolFactory", stableSurgeFactory],
    ["CurveYieldReClammPoolFactory", reClammFactory],
    ["CurveYieldPoolFactoryWrapper", wrapper],
  ]) {
    await call(`transfer ownership ${name} to DAO`, address, ownableAbi, "transferOwnership", [DAO]);
    report.ownershipTransfers.push({ name, address, pendingOwner: DAO });
    saveReport();
  }

  report.completedAt = new Date().toISOString();
  saveReport();
  console.log(`Deployment/config complete. Report: ${REPORT_PATH}`);
}

function compileAll() {
  const groups = [
    [
      coreEntries,
      [
        "CurveYieldBootstrapAuthorizer",
        "TimelockAuthorizer",
        "ProtocolFeeController",
        "VaultAdmin",
        "VaultExtension",
        "Vault",
      ],
    ],
    [
      routerEntries,
      ["Router", "BatchRouter", "CompositeLiquidityRouter", "BalancerContractRegistry", "ProtocolFeeSweeper"],
    ],
    [
      supportEntries,
      [
        "ReClammPoolHelper",
        "AdminFeeSplitter",
        "FeeSettlementKeeper",
        "FeeSettlementRouter",
        "PermanentLiquidityVaultV2",
        "PoolFeePolicyRegistry",
        "RouteRegistry",
        "BalancerV3SwapAdapter",
      ],
    ],
    [
      hooksEntries,
      [
        "CurveYieldHookConfigController",
        "ObservationQueryProcessor",
        "CurveYieldObservationController",
        "CurveYieldVolumeFeeController",
        "StableSurgeQueryProcessor",
        "CurveYieldMevVolumeHookV14",
        "CurveYieldStableSurgeVolumeHookV14",
      ],
    ],
    [
      factoryEntries,
      [
        "CurveYieldPoolFactoryWrapper",
        "CurveYieldReClammPoolFactory",
        "CurveYieldStablePoolFactory",
        "CurveYieldStableSurgePoolFactory",
        "CurveYieldWeightedPoolFactory",
      ],
    ],
  ];
  const merged = {};
  for (const [entries, names] of groups) {
    const startedAt = Date.now();
    const { compiled } = compileContracts(entries, names);
    Object.assign(merged, compiled);
    console.log(`Compiled group in ${((Date.now() - startedAt) / 1000).toFixed(1)}s: ${names.join(", ")}`);
  }
  return merged;
}

function linkBytecode(artifact, libraries) {
  let linked = artifact.bytecode.replace(/^0x/, "");
  for (const refsBySource of Object.values(artifact.linkReferences || {})) {
    for (const [libraryName, refs] of Object.entries(refsBySource)) {
      const libraryAddress = libraries[libraryName];
      if (!libraryAddress) throw new Error(`Missing library deployment for ${artifact.contractName}:${libraryName}`);
      const replacement = libraryAddress.replace(/^0x/, "").toLowerCase();
      for (const ref of refs) {
        const start = ref.start * 2;
        const length = ref.length * 2;
        linked = `${linked.slice(0, start)}${replacement.padStart(length, "0")}${linked.slice(start + length)}`;
      }
    }
  }
  if (linked.includes("__$")) throw new Error(`Unlinked library placeholder remains in ${artifact.contractName}`);
  return `0x${linked}`;
}

async function estimateGasWithMargin(tx) {
  const estimate = await publicClient.estimateGas(tx);
  return (estimate * 125n) / 100n + 25_000n;
}

function loadPrivateKey() {
  const raw =
    process.env.DEPLOYER_PRIVATE_KEY ||
    process.env.PRIVATE_KEY ||
    process.env.BASE_DEPLOYER_PRIVATE_KEY;
  if (!raw) {
    throw new Error("DEPLOYER_PRIVATE_KEY is not set in this process.");
  }
  const key = raw.startsWith("0x") ? raw : `0x${raw}`;
  if (!/^0x[0-9a-fA-F]{64}$/.test(key)) {
    throw new Error("DEPLOYER_PRIVATE_KEY is present but not a 32-byte hex private key.");
  }
  return key;
}

function envBigInt(name, fallback) {
  const value = process.env[name];
  if (value === undefined || value === "") return fallback;
  return BigInt(value);
}

function envAddress(name, fallback) {
  const value = process.env[name] || fallback;
  if (!/^0x[0-9a-fA-F]{40}$/.test(value)) throw new Error(`${name} is not a valid address: ${value}`);
  return value;
}

function stringifyArgs(args) {
  return args.map((arg) => {
    if (typeof arg === "bigint") return arg.toString();
    if (Array.isArray(arg)) return stringifyArgs(arg);
    return arg;
  });
}

function saveReport() {
  fs.mkdirSync(path.dirname(REPORT_PATH), { recursive: true });
  fs.writeFileSync(REPORT_PATH, `${JSON.stringify(report, null, 2)}\n`);
}

main().catch((error) => {
  report.failedAt = new Date().toISOString();
  report.error = error?.stack || String(error);
  saveReport();
  console.error(error);
  process.exitCode = 1;
});
