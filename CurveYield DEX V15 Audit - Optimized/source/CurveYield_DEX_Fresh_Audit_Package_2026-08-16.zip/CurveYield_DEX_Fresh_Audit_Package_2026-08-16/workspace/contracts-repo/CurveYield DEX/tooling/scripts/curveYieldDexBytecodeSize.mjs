import { compileContracts } from '../lib/compileSolc.mjs';

const entries = [
  'contracts/hooks/CurveYieldMevVolumeHookV14.sol',
  'contracts/hooks/CurveYieldStableSurgeVolumeHookV14.sol',
  'contracts/hooks/CurveYieldHookConfigController.sol',
  'contracts/hooks/CurveYieldObservationController.sol',
  'contracts/hooks/CurveYieldVolumeFeeController.sol',
];

const names = [
  'CurveYieldMevVolumeHookV14',
  'CurveYieldStableSurgeVolumeHookV14',
  'CurveYieldHookConfigController',
  'CurveYieldObservationController',
  'CurveYieldVolumeFeeController',
];

const { compiled } = compileContracts(entries, names);
const maxSize = 24_576;
let failed = false;

for (const name of names) {
  const artifact = compiled[name];
  if (!artifact) {
    failed = true;
    console.error(`${name}: missing artifact`);
    continue;
  }

  const bytecode = artifact.deployedBytecode.startsWith('0x')
    ? artifact.deployedBytecode.slice(2)
    : artifact.deployedBytecode;
  const bytes = bytecode.length / 2;
  const status = bytes <= maxSize ? 'OK' : 'TOO LARGE';
  if (bytes > maxSize) failed = true;
  console.log(`${name}: ${bytes} bytes (${status})`);
}

if (failed) process.exit(1);
