// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This test contract exercises a CurveYield implementation derived from Balancer's smart contracts.
 * Balancer's gracious use of open-source GPL licensing allows CurveYield to use it for the good of all.
 */

import { IERC20 } from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

import { IRateProvider } from "@balancer-labs/v3-interfaces/contracts/solidity-utils/helpers/IRateProvider.sol";
import { IVault } from "@balancer-labs/v3-interfaces/contracts/vault/IVault.sol";
import {
    TokenConfig,
    TokenType
} from "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";

import {
    CurveYieldPoolKind,
    Observation,
    ObservationState
} from "../../../contracts/hooks/CurveYieldHookTypes.sol";
import { PoolObservation } from "../../../contracts/hooks/PoolObservation.sol";

contract MockObservationVault {
    mapping(address pool => bool initialized) private _initialized;
    mapping(address pool => uint256[] balances) private _balances;

    function setPoolState(
        address pool,
        bool initialized,
        uint256[] calldata balances
    ) external {
        _initialized[pool] = initialized;
        _balances[pool] = balances;
    }

    function isPoolInitialized(address pool) external view returns (bool) {
        return _initialized[pool];
    }

    function getCurrentLiveBalances(
        address pool
    ) external view returns (uint256[] memory) {
        return _balances[pool];
    }
}

contract MockObservationPool {
    uint256 public totalSupply;
    uint256[] private _normalizedWeights;

    constructor(uint256 totalSupply_, uint256[] memory normalizedWeights_) {
        totalSupply = totalSupply_;
        _normalizedWeights = normalizedWeights_;
    }

    function getNormalizedWeights() external view returns (uint256[] memory) {
        return _normalizedWeights;
    }
}

contract CurveYieldObservationHarness is PoolObservation {
    error InvalidLogicalObservationIndex(uint256 index, uint256 cardinality);
    error InsufficientObservationHistory(address pool, uint32 secondsAgo);

    constructor(IVault vault) PoolObservation(vault) {}

    function registerPool(
        address pool,
        address[] calldata tokens,
        CurveYieldPoolKind kind
    ) external {
        _registerObservationPool(
            address(this),
            pool,
            _tokenConfig(tokens),
            kind
        );
    }

    function initializeFromVault(address pool) external {
        _initializeObservation(pool);
    }

    function initializeAt(
        address pool,
        uint256[] calldata balancesScaled18,
        uint256 totalBptSupply,
        uint48 timestamp
    ) external {
        _initializeObservationAt(pool, balancesScaled18, totalBptSupply, timestamp);
    }

    function initializeStandaloneAt(
        address pool,
        uint256[] calldata balancesScaled18,
        uint256 totalBptSupply,
        uint48 timestamp
    ) external {
        if (_observationTokenCounts[pool] == 0) {
            address[] memory tokens = new address[](2);
            tokens[0] = address(0x1001);
            tokens[1] = address(0x1002);
            _registerObservationPool(
                address(this),
                pool,
                _tokenConfig(tokens),
                CurveYieldPoolKind.STABLE
            );
        }
        _initializeObservationAt(pool, balancesScaled18, totalBptSupply, timestamp);
    }

    function observeTwiceAt(
        address pool,
        uint256[] calldata firstBalancesScaled18,
        uint256[] calldata secondBalancesScaled18,
        uint256 totalBptSupply,
        uint48 timestamp
    ) external {
        _observeAt(pool, firstBalancesScaled18, totalBptSupply, timestamp);
        _observeAt(pool, secondBalancesScaled18, totalBptSupply, timestamp);
    }

    function checkpointAt(
        address pool,
        uint256[] calldata balancesScaled18,
        uint256 totalBptSupply,
        uint48 timestamp
    ) external {
        _checkpointAt(pool, balancesScaled18, totalBptSupply, timestamp);
    }

    function fillSyntheticSamples(
        address pool,
        uint48 startingTimestamp,
        uint16 sampleCount,
        uint256[] calldata balancesScaled18,
        uint256 totalBptSupply
    ) external {
        for (uint256 i = 1; i <= sampleCount; ++i) {
            _checkpointAt(
                pool,
                balancesScaled18,
                totalBptSupply,
                startingTimestamp + uint48(i * 120)
            );
        }
    }

    function getTimeWeightedBalancesPerBptAt(
        address pool,
        uint48 currentTimestamp,
        uint32 secondsAgo
    ) external view returns (uint256[] memory) {
        return _getTimeWeightedBalancesPerBptAt(pool, currentTimestamp, secondsAgo);
    }

    function observationState(
        address pool
    )
        external
        view
        returns (
            uint16 index,
            uint16 cardinality,
            uint48 initializedAt,
            uint48 lastTimestamp,
            uint48 lastSampleTimestamp,
            bool initialized,
            int128[8] memory cumulativeLogs,
            int128[8] memory instantLogs
        )
    {
        ObservationState storage state = _observationStates[pool];
        return (
            state.index,
            state.cardinality,
            state.initializedAt,
            state.lastTimestamp,
            state.lastSampleTimestamp,
            state.initialized,
            state.cumulativeLogs,
            state.instantLogs
        );
    }

    function physicalObservation(
        address pool,
        uint16 physicalIndex
    ) external view returns (uint48 timestamp, int128[8] memory cumulativeLogs) {
        Observation storage sample = _poolObservations[pool][physicalIndex];
        return (sample.timestamp, sample.cumulativeLogs);
    }

    function registeredPoolMetadata(
        address pool
    )
        external
        view
        returns (
            address factory,
            CurveYieldPoolKind kind,
            uint8 tokenCount,
            address[8] memory tokens,
            uint64[8] memory normalizedWeights
        )
    {
        return (
            _observationFactories[pool],
            _observationPoolKinds[pool],
            _observationTokenCounts[pool],
            _observationTokens[pool],
            _observationNormalizedWeights[pool]
        );
    }

    function logicalObservation(
        address pool,
        uint16 logicalIndex
    ) external view returns (uint48 timestamp, int128[8] memory cumulativeLogs) {
        ObservationState storage state = _observationStates[pool];
        if (logicalIndex >= state.cardinality) {
            revert InvalidLogicalObservationIndex(logicalIndex, state.cardinality);
        }

        uint256 oldest = state.cardinality == 512
            ? (uint256(state.index) + 1) % 512
            : 0;
        Observation storage sample = _poolObservations[pool][
            (oldest + logicalIndex) % 512
        ];
        return (sample.timestamp, sample.cumulativeLogs);
    }

    function observationAccumulatorHorizonIsSafe() external pure returns (bool) {
        uint256 maximumLogMagnitude = 136e18;
        return maximumLogMagnitude * type(uint48).max < uint256(int256(type(int128).max));
    }

    function _tokenConfig(
        address[] memory tokens
    ) private pure returns (TokenConfig[] memory config) {
        config = new TokenConfig[](tokens.length);
        for (uint256 i = 0; i < tokens.length; ++i) {
            config[i] = TokenConfig({
                token: IERC20(tokens[i]),
                tokenType: TokenType.STANDARD,
                rateProvider: IRateProvider(address(0)),
                paysYieldFees: false
            });
        }
    }
}
