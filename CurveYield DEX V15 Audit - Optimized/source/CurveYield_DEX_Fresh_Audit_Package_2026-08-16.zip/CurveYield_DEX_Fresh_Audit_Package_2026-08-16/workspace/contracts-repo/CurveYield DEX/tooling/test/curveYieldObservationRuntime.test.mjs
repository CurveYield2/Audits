import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  createPublicClient,
  createWalletClient,
  getContract,
  http,
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { compileContracts } from '../lib/compileSolc.mjs';

const WAD = 10n ** 18n;
const rpcUrl = 'http://127.0.0.1:8635';
const chain = {
  id: 31337,
  name: 'anvil',
  nativeCurrency: { name: 'ETH', symbol: 'ETH', decimals: 18 },
  rpcUrls: {},
};
const owner = privateKeyToAccount(
  '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80',
);

async function waitForAnvil() {
  const startedAt = Date.now();
  while (Date.now() - startedAt < 15_000) {
    try {
      const response = await fetch(rpcUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_blockNumber', params: [] }),
      });
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  throw new Error('Timed out waiting for bounded local Anvil');
}

function linkedBytecode(artifact, libraries) {
  let object = artifact.bytecode.slice(2);
  for (const [sourceName, sourceLibraries] of Object.entries(artifact.linkReferences || {})) {
    for (const [libraryName, references] of Object.entries(sourceLibraries)) {
      const address = libraries[`${sourceName}:${libraryName}`] || libraries[libraryName];
      if (!address) throw new Error(`Missing link address for ${sourceName}:${libraryName}`);
      const normalizedAddress = address.toLowerCase().replace(/^0x/, '');
      for (const reference of references) {
        const start = reference.start * 2;
        const length = reference.length * 2;
        object = `${object.slice(0, start)}${normalizedAddress.padStart(length, '0')}${object.slice(start + length)}`;
      }
    }
  }
  if (object.includes('__$')) throw new Error('Unresolved Solidity library link placeholder');
  return `0x${object}`;
}

async function deploy(walletClient, publicClient, artifact, args = [], libraries = {}) {
  const bytecode = Object.keys(libraries).length === 0
    ? artifact.bytecode
    : linkedBytecode(artifact, libraries);
  const hash = await walletClient.deployContract({
    abi: artifact.abi,
    bytecode,
    args,
    account: walletClient.account,
  });
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  expect(receipt.status).toBe('success');
  return getContract({
    address: receipt.contractAddress,
    abi: artifact.abi,
    client: { public: publicClient },
  });
}

async function write(publicClient, walletClient, contract, functionName, args = [], gas) {
  const hash = await walletClient.writeContract({
    address: contract.address,
    abi: contract.abi,
    functionName,
    args,
    gas,
    account: walletClient.account,
  });
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  expect(receipt.status).toBe('success');
}

function tokenAddresses(count, offset = 0) {
  return Array.from({ length: count }, (_, index) =>
    `0x${BigInt(10_000 + offset + index).toString(16).padStart(40, '0')}`);
}

function expectRelativeClose(actual, expected, relativeTolerance = 20_000n) {
  const difference = actual > expected ? actual - expected : expected - actual;
  const maximumDifference = (expected * relativeTolerance) / WAD + 2n;
  expect(difference).toBeLessThanOrEqual(maximumDifference);
}

describe('CurveYield PoolObservation Solidity runtime', () => {
  let anvil;
  let shutdownTimer;
  let publicClient;
  let walletClient;
  let compiled;
  let vault;
  let harness;
  let mainPool;

  beforeAll(async () => {
    ({ compiled } = compileContracts(
      [
        'contracts/hooks/ObservationQueryProcessor.sol',
        'contracts/hooks/PoolObservation.sol',
        'tooling/test/contracts/CurveYieldObservationHarness.sol',
      ],
      [
        'ObservationQueryProcessor',
        'CurveYieldObservationHarness',
        'MockObservationVault',
        'MockObservationPool',
      ],
    ));

    const anvilPath = process.env.ANVIL_PATH || 'C:\\Users\\user\\.foundry\\bin\\anvil.exe';
    if (!fs.existsSync(anvilPath)) throw new Error(`Anvil not found at ${anvilPath}`);
    anvil = spawn(
      anvilPath,
      ['--port', '8635', '--silent', '--gas-limit', '300000000'],
      {
        cwd: process.cwd(),
        stdio: 'ignore',
        windowsHide: true,
      },
    );
    shutdownTimer = setTimeout(() => {
      if (anvil && !anvil.killed) anvil.kill();
    }, 5 * 60_000);
    shutdownTimer.unref();
    await waitForAnvil();

    publicClient = createPublicClient({ chain, transport: http(rpcUrl) });
    walletClient = createWalletClient({ account: owner, chain, transport: http(rpcUrl) });
    const queryLibrary = await deploy(
      walletClient,
      publicClient,
      compiled.ObservationQueryProcessor,
    );
    vault = await deploy(walletClient, publicClient, compiled.MockObservationVault);
    harness = await deploy(
      walletClient,
      publicClient,
      compiled.CurveYieldObservationHarness,
      [vault.address],
      { ObservationQueryProcessor: queryLibrary.address },
    );
    mainPool = await deploy(walletClient, publicClient, compiled.MockObservationPool, [
      100n * WAD,
      [(50n * WAD) / 100n, (50n * WAD) / 100n],
    ]);
    await write(publicClient, walletClient, harness, 'registerPool', [
      mainPool.address,
      tokenAddresses(2),
      2,
    ]);
  }, 180_000);

  afterAll(() => {
    if (shutdownTimer) clearTimeout(shutdownTimer);
    if (anvil && !anvil.killed) anvil.kill();
  });

  it('initializes at 1,000, replaces twice at 1,120, and queries both states', async () => {
    const oldBalances = [200n * WAD, 800n * WAD];
    const intermediateBalances = [400n * WAD, 400n * WAD];
    const finalBalances = [800n * WAD, 200n * WAD];

    await write(publicClient, walletClient, harness, 'initializeAt', [
      mainPool.address,
      oldBalances,
      100n * WAD,
      1_000,
    ]);
    await write(publicClient, walletClient, harness, 'observeTwiceAt', [
      mainPool.address,
      intermediateBalances,
      finalBalances,
      100n * WAD,
      1_120,
    ]);

    const state = await harness.read.observationState([mainPool.address]);
    expect(state[0]).toBe(1);
    expect(state[1]).toBe(2);
    expect(state[3]).toBe(1_120);
    expect(state[4]).toBe(1_120);

    const means = await harness.read.getTimeWeightedBalancesPerBptAt([
      mainPool.address,
      1_240,
      240,
    ]);
    expectRelativeClose(means[0], 4n * WAD);
    expectRelativeClose(means[1], 4n * WAD);
  });

  it('fills 513 additional samples and overwrites the oldest ring entries', async () => {
    await write(
      publicClient,
      walletClient,
      harness,
      'fillSyntheticSamples',
      [mainPool.address, 1_240, 513, [800n * WAD, 200n * WAD], 100n * WAD],
      250_000_000n,
    );

    const state = await harness.read.observationState([mainPool.address]);
    expect(state[1]).toBe(512);
    const oldest = await harness.read.logicalObservation([mainPool.address, 0]);
    expect(oldest[0]).toBe(1_480);
    const newest = await harness.read.logicalObservation([mainPool.address, 511]);
    expect(newest[0]).toBe(62_800);

    await expect(
      harness.read.getTimeWeightedBalancesPerBptAt([mainPool.address, 62_800, 61_321]),
    ).rejects.toThrow(/InsufficientObservationHistory/);
  }, 180_000);

  it('returns raw ring metadata and exact stored cumulative values', async () => {
    const state = await harness.read.observationState([mainPool.address]);
    const newest = await harness.read.physicalObservation([mainPool.address, state[0]]);
    expect(newest[0]).toBe(62_800);
    expect(newest[1]).toHaveLength(8);
    expect(newest[1][0]).toBeGreaterThan(0n);
  });

  it('initializes, checkpoints, and queries every token count from two through eight', async () => {
    for (let tokenCount = 2; tokenCount <= 8; tokenCount += 1) {
      const weights = Array(tokenCount).fill(WAD / BigInt(tokenCount));
      weights[weights.length - 1] += WAD - weights.reduce((sum, weight) => sum + weight, 0n);
      const pool = await deploy(walletClient, publicClient, compiled.MockObservationPool, [
        100n * WAD,
        weights,
      ]);
      const balances = Array.from(
        { length: tokenCount },
        (_, index) => BigInt(index + 1) * 100n * WAD,
      );
      await write(publicClient, walletClient, harness, 'registerPool', [
        pool.address,
        tokenAddresses(tokenCount, tokenCount * 100),
        2,
      ]);
      await write(publicClient, walletClient, vault, 'setPoolState', [
        pool.address,
        true,
        balances,
      ]);
      await write(publicClient, walletClient, harness, 'initializeFromVault', [pool.address]);
      const initializedState = await harness.read.observationState([pool.address]);
      const checkpointTimestamp = initializedState[3] + 120;
      await write(publicClient, walletClient, harness, 'checkpointAt', [
        pool.address,
        balances,
        100n * WAD,
        checkpointTimestamp,
      ]);
      const means = await harness.read.getTimeWeightedBalancesPerBptAt([
        pool.address,
        checkpointTimestamp,
        120,
      ]);
      expect(means).toHaveLength(tokenCount);
      for (let index = 0; index < tokenCount; index += 1) {
        expectRelativeClose(means[index], BigInt(index + 1) * WAD);
      }
    }
  }, 180_000);

  it('caches Weighted pool provenance, token order, and normalized weights', async () => {
    const tokens = tokenAddresses(3, 500);
    const weights = [20n * WAD / 100n, 30n * WAD / 100n, 50n * WAD / 100n];
    const pool = await deploy(walletClient, publicClient, compiled.MockObservationPool, [
      100n * WAD,
      weights,
    ]);

    await write(publicClient, walletClient, harness, 'registerPool', [
      pool.address,
      tokens,
      1,
    ]);

    const metadata = await harness.read.registeredPoolMetadata([pool.address]);
    expect(metadata[0].toLowerCase()).toBe(harness.address.toLowerCase());
    expect(metadata[1]).toBe(1);
    expect(metadata[2]).toBe(3);
    expect(metadata[3].slice(0, 3).map((token) => token.toLowerCase())).toEqual(
      tokens.map((token) => token.toLowerCase()),
    );
    expect(metadata[4].slice(0, 3)).toEqual(weights);
  }, 180_000);

  it('proves the signed accumulator covers the full uint48 timestamp horizon', async () => {
    expect(await harness.read.observationAccumulatorHorizonIsSafe()).toBe(true);
  });

  it('rejects zero windows, zero supply, zero balance-per-BPT, and wrong lengths', async () => {
    await expect(
      harness.read.getTimeWeightedBalancesPerBptAt([mainPool.address, 62_800, 0]),
    ).rejects.toThrow();
    await expect(
      harness.read.initializeStandaloneAt([
        '0x0000000000000000000000000000000000009001',
        [WAD, WAD],
        0n,
        1_000,
      ]),
    ).rejects.toThrow();
    await expect(
      harness.read.initializeStandaloneAt([
        '0x0000000000000000000000000000000000009002',
        [0n, WAD],
        WAD,
        1_000,
      ]),
    ).rejects.toThrow();
    await expect(
      harness.read.initializeStandaloneAt([
        '0x0000000000000000000000000000000000009003',
        [WAD],
        WAD,
        1_000,
      ]),
    ).rejects.toThrow();
  });
});
