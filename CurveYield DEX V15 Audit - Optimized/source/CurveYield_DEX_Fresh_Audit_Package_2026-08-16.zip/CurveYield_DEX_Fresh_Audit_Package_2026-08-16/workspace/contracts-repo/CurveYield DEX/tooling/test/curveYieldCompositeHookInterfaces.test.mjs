import fs from 'node:fs';
import { describe, expect, it } from 'vitest';
import { compileContracts } from '../lib/compileSolc.mjs';

const files = {
  types: 'contracts/hooks/CurveYieldHookTypes.sol',
  observation: 'contracts/interfaces/ICurveYieldPoolObservation.sol',
  composite: 'contracts/interfaces/ICurveYieldCompositeHook.sol',
  provenance: 'contracts/interfaces/ICurveYieldFactoryProvenance.sol',
};

function read(file) {
  return fs.readFileSync(file, 'utf8');
}

describe('CurveYield composite hook types and interfaces', () => {
  it('defines the approved pool kinds, constants, and fixed-width storage types', () => {
    const source = read(files.types);

    expect(source).toContain('enum CurveYieldPoolKind');
    expect(source).toMatch(/NONE,\s*WEIGHTED,\s*STABLE,\s*STABLE_SURGE/);
    expect(source).toContain('CREATOR_CONFIG_DELAY = 24 hours');
    expect(source).toContain('IMMUTABLE_COMBINED_FEE_HARD_MAX = 0.20e18');
    expect(source).toContain('MAX_OBSERVATIONS = 512');
    expect(source).toContain('MIN_OBSERVATION_SPACING = 120 seconds');
    expect(source).toContain('OBSERVATION_WARM_UP = 30 minutes');
    expect(source).toContain('MIN_SETTLEMENT_WINDOW = 10 minutes');
    expect(source).toContain('MAX_SETTLEMENT_WINDOW = 12 hours');

    expect(source).toContain('uint64 maxVolumeSurcharge;');
    expect(source).toContain('uint8 reactiveness;');
    expect(source).toContain('uint8 halfLifeHours;');
    expect(source).toContain('bool creatorChangesFrozen;');
    expect(source).toContain('uint48 executableAt;');
    expect(source).toContain('uint128 activity;');
    expect(source).toContain('uint48 lastUpdated;');
    expect(source).toContain('uint16 index;');
    expect(source).toContain('uint16 cardinality;');
    expect(source).toContain('int128[8] cumulativeLogs;');
    expect(source).toContain('int128[8] instantLogs;');
  });

  it('exposes the common observation and protected-settlement quote surface', () => {
    const source = read(files.observation);

    expect(source).toContain('function initializeObservation(address pool) external;');
    expect(source).toContain('function checkpoint(address pool) external;');
    expect(source).toContain('function isObservationWarm(address pool) external view returns (bool);');
    expect(source).toMatch(
      /function getTimeWeightedBalancesPerBpt\(\s*address pool,\s*uint32 secondsAgo\s*\)/,
    );
    expect(source).toContain('returns (uint256[] memory balancesPerBpt);');
    expect(source).toMatch(
      /function quoteOracleProtectedBptOut\(\s*address pool,\s*uint256\[\] calldata exactAmountsInRaw\s*\)/,
    );
    expect(source).toContain('returns (uint256 oracleExpectedBptOut, uint256 oracleMinBptOut);');
    expect(source).toMatch(
      /function quoteOracleProtectedBptOutScaled18\(\s*address pool,\s*uint256\[\] calldata exactAmountsInScaled18\s*\)/,
    );
  });

  it('exposes the approved DAO and delayed creator configuration surface', () => {
    const source = read(files.composite);
    const requiredSignatures = [
      'function setFactoryPoolKind(address factory, CurveYieldPoolKind kind) external;',
      'function setSettlementRouter(address settlementRouter, bool approved) external;',
      'function setGlobalCombinedFeeCap(uint256 newCap) external;',
      'function setPoolCombinedFeeCap(address pool, bool enabled, uint256 newCap) external;',
      'function setSettlementOracleConfig(address pool, uint32 window, uint16 slippageBps) external;',
      'function setProtectedSettlementPaused(bool paused) external;',
      'function queueCreatorVolumeFeeConfig(',
      'function cancelCreatorVolumeFeeConfig(address pool) external;',
      'function executeCreatorVolumeFeeConfig(address pool) external;',
      'function setPoolVolumeFeeConfigImmediately(',
      'function cancelPendingCreatorVolumeFeeConfig(address pool) external;',
      'function freezeCreatorVolumeFeeConfig(address pool, bool frozen) external;',
    ];

    expect(source).toContain('interface ICurveYieldCompositeHook is ICurveYieldPoolObservation');
    for (const signature of requiredSignatures) {
      expect(source, signature).toContain(signature);
    }
  });

  it('defines factory provenance without a token or pool allowlist', () => {
    const source = read(files.provenance);

    expect(source).toContain('function isPoolFromFactory(address pool) external view returns (bool);');
    expect(source).toContain('function getVault() external view returns (address);');
    expect(source).not.toMatch(/tokenAllowlist|poolAllowlist|allowedToken|allowedPool/);
  });

  it('retains the CurveYield header, GPL license, and Balancer attribution', () => {
    for (const file of Object.values(files)) {
      const source = read(file);
      expect(source, file).toContain('// SPDX-License-Identifier: GPL-3.0-or-later');
      expect(source, file).toContain('@title CurveYield System Component');
      expect(source, file).toContain('https://docs.curveyield.com');
      expect(source, file).toContain(
        "This contract supports a CurveYield implementation derived from Balancer's smart contracts.",
      );
      expect(source, file).toContain(
        "Balancer's gracious use of open-source GPL licensing allows CurveYield to use it for the good of all.",
      );
    }
  });

  it('compiles all shared interfaces without Forge', () => {
    const { compiled } = compileContracts(Object.values(files), [
      'ICurveYieldPoolObservation',
      'ICurveYieldCompositeHook',
      'ICurveYieldFactoryProvenance',
    ]);

    expect(compiled.ICurveYieldPoolObservation).toBeTruthy();
    expect(compiled.ICurveYieldCompositeHook).toBeTruthy();
    expect(compiled.ICurveYieldFactoryProvenance).toBeTruthy();
  });
});
