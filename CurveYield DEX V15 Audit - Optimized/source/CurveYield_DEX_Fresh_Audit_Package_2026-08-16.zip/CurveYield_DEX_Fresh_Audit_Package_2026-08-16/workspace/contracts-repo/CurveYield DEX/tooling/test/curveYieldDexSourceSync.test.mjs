import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import {
  existsSync,
  mkdirSync,
  mkdtempSync,
  readdirSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import os from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { fileURLToPath } from "node:url";
import { describe, expect, test } from "vitest";

const testDirectory = path.dirname(fileURLToPath(import.meta.url));
const dexRoot = path.resolve(testDirectory, "..", "..");
const workspaceRoot = path.resolve(dexRoot, "..", "..");
const canonicalRoot = path.join(dexRoot, "contracts");
const mirrorRoot = path.join(workspaceRoot, "src", "curveyield", "dex");
const syncScript = path.join(
  dexRoot,
  "tooling",
  "lib",
  "syncCurveYieldDexSources.mjs",
);
const syncModuleUrl = pathToFileURL(syncScript).href;

function collectSolidityFiles(root, current = root, result = new Map()) {
  for (const entry of readdirSync(current, { withFileTypes: true })) {
    const absolutePath = path.join(current, entry.name);

    if (entry.isDirectory()) {
      collectSolidityFiles(root, absolutePath, result);
    } else if (entry.isFile() && entry.name.endsWith(".sol")) {
      const relativePath = path.relative(root, absolutePath).replaceAll("\\", "/");
      const hash = createHash("sha256")
        .update(readFileSync(absolutePath))
        .digest("hex");
      result.set(relativePath, hash);
    }
  }

  return result;
}

describe("CurveYield DEX source synchronization", () => {
  test("the canonical and runnable Solidity trees match byte for byte", () => {
    const canonicalFiles = collectSolidityFiles(canonicalRoot);
    const mirrorFiles = collectSolidityFiles(mirrorRoot);

    expect([...mirrorFiles.keys()].sort()).toEqual(
      [...canonicalFiles.keys()].sort(),
    );

    for (const [relativePath, canonicalHash] of canonicalFiles) {
      expect(mirrorFiles.get(relativePath), relativePath).toBe(canonicalHash);
    }
  });

  test("the source synchronization CLI accepts a clean check", () => {
    const result = spawnSync(
      process.execPath,
      [syncScript, "--check"],
      {
        cwd: workspaceRoot,
        encoding: "utf8",
        timeout: 30_000,
      },
    );

    expect(result.status, `${result.stdout}\n${result.stderr}`).toBe(0);
  });

  test("comparison reports an extra Solidity file in either tree", async () => {
    const { compareSolidityTrees } = await import(syncModuleUrl);
    const temporaryRoot = mkdtempSync(
      path.join(os.tmpdir(), "curveyield-source-sync-"),
    );
    const canonical = path.join(temporaryRoot, "canonical");
    const mirror = path.join(temporaryRoot, "mirror");

    try {
      mkdirSync(canonical);
      mkdirSync(mirror);
      writeFileSync(path.join(canonical, "Shared.sol"), "canonical");
      writeFileSync(path.join(mirror, "Shared.sol"), "canonical");
      writeFileSync(path.join(mirror, "Extra.sol"), "extra");

      const comparison = compareSolidityTrees(canonical, mirror);

      expect(comparison.matches).toBe(false);
      expect(comparison.extraInMirror).toEqual(["Extra.sol"]);
      expect(comparison.extraInCanonical).toEqual([]);
    } finally {
      rmSync(temporaryRoot, { recursive: true, force: true });
    }
  });

  test("write mode copies canonical Solidity and removes only extra mirror Solidity", async () => {
    const { syncSolidityTrees } = await import(syncModuleUrl);
    const temporaryRoot = mkdtempSync(
      path.join(os.tmpdir(), "curveyield-source-write-"),
    );
    const canonical = path.join(temporaryRoot, "canonical");
    const mirror = path.join(temporaryRoot, "mirror");

    try {
      mkdirSync(path.join(canonical, "nested"), { recursive: true });
      mkdirSync(path.join(mirror, "nested"), { recursive: true });
      writeFileSync(path.join(canonical, "nested", "Shared.sol"), "new");
      writeFileSync(path.join(mirror, "nested", "Shared.sol"), "old");
      writeFileSync(path.join(mirror, "Extra.sol"), "remove");
      writeFileSync(path.join(mirror, "keep.txt"), "keep");

      const canonicalBefore = collectSolidityFiles(canonical);
      const actions = [];
      syncSolidityTrees(canonical, mirror, (action) => actions.push(action));

      expect(readFileSync(path.join(mirror, "nested", "Shared.sol"), "utf8")).toBe(
        "new",
      );
      expect(existsSync(path.join(mirror, "Extra.sol"))).toBe(false);
      expect(readFileSync(path.join(mirror, "keep.txt"), "utf8")).toBe("keep");
      expect(collectSolidityFiles(canonical)).toEqual(canonicalBefore);
      expect(actions.map(({ type }) => type).sort()).toEqual(["copy", "remove"]);
    } finally {
      rmSync(temporaryRoot, { recursive: true, force: true });
    }
  });

  test("workspace safety rejects a path outside the workspace", async () => {
    const { assertSafeWorkspacePath } = await import(syncModuleUrl);
    const outside = mkdtempSync(path.join(os.tmpdir(), "curveyield-outside-"));

    try {
      expect(() =>
        assertSafeWorkspacePath(workspaceRoot, outside, "outside"),
      ).toThrow(/outside the workspace/i);
    } finally {
      rmSync(outside, { recursive: true, force: true });
    }
  });
});
