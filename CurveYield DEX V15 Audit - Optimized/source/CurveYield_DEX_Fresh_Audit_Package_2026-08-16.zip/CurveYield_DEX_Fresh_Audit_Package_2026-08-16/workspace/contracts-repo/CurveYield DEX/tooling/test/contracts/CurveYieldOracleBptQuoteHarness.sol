// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This test contract calls Balancer's exact BasePoolMath implementation independently from the
 * CurveYield hook. Balancer's gracious use of open-source GPL licensing allows CurveYield to use it
 * for the good of all.
 */

import { Math } from "@openzeppelin/contracts/utils/math/Math.sol";

import { IBasePool } from "@balancer-labs/v3-interfaces/contracts/vault/IBasePool.sol";
import { BasePoolMath } from "@balancer-labs/v3-vault/contracts/BasePoolMath.sol";
import { FixedPoint } from "@balancer-labs/v3-solidity-utils/contracts/math/FixedPoint.sol";

contract CurveYieldOracleBptQuoteHarness {
    using FixedPoint for uint256;

    function quote(
        address pool,
        uint256[] memory timeWeightedBalancesPerBpt,
        uint256[] memory exactAmountsInScaled18,
        uint256 currentSupply,
        uint256 staticSwapFeePercentage,
        uint16 slippageBps
    ) external view returns (uint256 expectedBptOut, uint256 minBptOut) {
        uint256[] memory oracleBalances = new uint256[](
            timeWeightedBalancesPerBpt.length
        );
        for (uint256 i = 0; i < oracleBalances.length; ++i) {
            oracleBalances[i] = timeWeightedBalancesPerBpt[i].mulDown(
                currentSupply
            );
        }

        (expectedBptOut, ) = BasePoolMath.computeAddLiquidityUnbalanced(
            oracleBalances,
            exactAmountsInScaled18,
            currentSupply,
            staticSwapFeePercentage,
            IBasePool(pool)
        );
        minBptOut = Math.mulDiv(
            expectedBptOut,
            10_000 - slippageBps,
            10_000
        );
    }
}
