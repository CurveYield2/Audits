import { describe, expect, it } from 'vitest';

const MAX_OBSERVATIONS = 512;
const MIN_SAMPLE_SPACING = 120n;
const LOG_SCALE = 10n ** 18n;

function interpolate(begin, end, elapsed, duration) {
  return begin.map((value, index) => value + ((end[index] - value) * elapsed) / duration);
}

class ObservationModel {
  constructor(tokenCount) {
    if (tokenCount < 2 || tokenCount > 8) throw new Error('invalid token count');
    this.tokenCount = tokenCount;
    this.initialized = false;
    this.lastTimestamp = 0n;
    this.lastSampleTimestamp = 0n;
    this.instantLogs = Array(tokenCount).fill(0n);
    this.cumulativeLogs = Array(tokenCount).fill(0n);
    this.ring = Array(MAX_OBSERVATIONS);
    this.index = 0;
    this.cardinality = 0;
  }

  initialize(timestamp, instantLogs) {
    if (this.initialized) throw new Error('already initialized');
    this.#validateLogs(instantLogs);
    this.initialized = true;
    this.lastTimestamp = timestamp;
    this.lastSampleTimestamp = timestamp;
    this.instantLogs = [...instantLogs];
    this.#store(timestamp);
  }

  install(timestamp, instantLogs) {
    this.#validateInitialized();
    this.#validateLogs(instantLogs);
    this.#accrue(timestamp);
    this.instantLogs = [...instantLogs];
    if (timestamp - this.lastSampleTimestamp >= MIN_SAMPLE_SPACING) {
      this.#store(timestamp);
      this.lastSampleTimestamp = timestamp;
    }
  }

  checkpoint(timestamp) {
    this.#validateInitialized();
    this.#accrue(timestamp);
    if (timestamp - this.lastSampleTimestamp >= MIN_SAMPLE_SPACING) {
      this.#store(timestamp);
      this.lastSampleTimestamp = timestamp;
    }
  }

  observations() {
    const result = [];
    const oldest = this.cardinality === MAX_OBSERVATIONS
      ? (this.index + 1) % MAX_OBSERVATIONS
      : 0;
    for (let logical = 0; logical < this.cardinality; logical += 1) {
      result.push(this.ring[(oldest + logical) % MAX_OBSERVATIONS]);
    }
    return result;
  }

  cumulativeAt(timestamp, now = this.lastTimestamp) {
    this.#validateInitialized();
    if (timestamp > now) throw new Error('future query');

    const currentCumulative = this.#currentCumulative(now);
    if (timestamp >= this.lastTimestamp) {
      return this.cumulativeLogs.map(
        (value, index) => value + this.instantLogs[index] * (timestamp - this.lastTimestamp),
      );
    }

    const ordered = this.observations();
    if (timestamp < ordered[0].timestamp) throw new Error('insufficient history');

    let low = 0;
    let high = ordered.length - 1;
    while (low <= high) {
      const middle = (low + high) >> 1;
      const sample = ordered[middle];
      if (sample.timestamp === timestamp) return [...sample.cumulativeLogs];
      if (sample.timestamp < timestamp) low = middle + 1;
      else high = middle - 1;
    }

    const before = ordered[high];
    const after = low < ordered.length
      ? ordered[low]
      : { timestamp: now, cumulativeLogs: currentCumulative };
    return interpolate(
      before.cumulativeLogs,
      after.cumulativeLogs,
      timestamp - before.timestamp,
      after.timestamp - before.timestamp,
    );
  }

  averageLogs(now, window) {
    if (window === 0n) throw new Error('zero window');
    const start = this.cumulativeAt(now - window, now);
    const end = this.#currentCumulative(now);
    return end.map((value, index) => (value - start[index]) / window);
  }

  geometricMeans(now, window) {
    return this.averageLogs(now, window).map(
      (averageLog) => Math.exp(Number(averageLog) / Number(LOG_SCALE)),
    );
  }

  metadata() {
    return {
      index: this.index,
      cardinality: this.cardinality,
      lastTimestamp: this.lastTimestamp,
      lastSampleTimestamp: this.lastSampleTimestamp,
    };
  }

  #currentCumulative(timestamp) {
    if (timestamp < this.lastTimestamp) throw new Error('timestamp regression');
    return this.cumulativeLogs.map(
      (value, index) => value + this.instantLogs[index] * (timestamp - this.lastTimestamp),
    );
  }

  #accrue(timestamp) {
    if (timestamp < this.lastTimestamp) throw new Error('timestamp regression');
    const elapsed = timestamp - this.lastTimestamp;
    for (let index = 0; index < this.tokenCount; index += 1) {
      this.cumulativeLogs[index] += this.instantLogs[index] * elapsed;
    }
    this.lastTimestamp = timestamp;
  }

  #store(timestamp) {
    if (this.cardinality === 0) {
      this.index = 0;
      this.cardinality = 1;
    } else {
      this.index = (this.index + 1) % MAX_OBSERVATIONS;
      if (this.cardinality < MAX_OBSERVATIONS) this.cardinality += 1;
    }
    this.ring[this.index] = {
      timestamp,
      cumulativeLogs: [...this.cumulativeLogs],
    };
  }

  #validateInitialized() {
    if (!this.initialized) throw new Error('not initialized');
  }

  #validateLogs(logs) {
    if (logs.length !== this.tokenCount) throw new Error('wrong log count');
  }
}

function logWad(value) {
  return BigInt(Math.round(Math.log(value) * Number(LOG_SCALE)));
}

describe('CurveYield independent pool-observation model', () => {
  it('accrues old state, replaces same-timestamp state, and spans both states', () => {
    const oldLogs = Array.from({ length: 8 }, (_, index) => BigInt(index + 1) * 100n);
    const firstReplacement = Array.from({ length: 8 }, (_, index) => BigInt(index + 1) * 300n);
    const finalReplacement = Array.from({ length: 8 }, (_, index) => BigInt(index + 1) * 500n);
    const model = new ObservationModel(8);

    model.initialize(1_000n, oldLogs);
    model.install(1_120n, firstReplacement);
    const afterFirst = [...model.cumulativeLogs];
    model.install(1_120n, finalReplacement);

    expect(model.cumulativeLogs).toEqual(afterFirst);
    expect(model.averageLogs(1_240n, 240n)).toEqual(
      oldLogs.map((oldLog, index) => (oldLog + finalReplacement[index]) / 2n),
    );
  });

  it('stores no more than one sample every 120 seconds', () => {
    const model = new ObservationModel(2);
    model.initialize(1_000n, [10n, 20n]);
    model.checkpoint(1_050n);
    model.install(1_119n, [20n, 40n]);
    expect(model.metadata().cardinality).toBe(1);
    model.checkpoint(1_120n);
    expect(model.metadata().cardinality).toBe(2);
  });

  it('interpolates between samples and extrapolates from the last instant state', () => {
    const model = new ObservationModel(2);
    model.initialize(1_000n, [100n, -100n]);
    model.install(1_120n, [300n, -300n]);
    model.checkpoint(1_240n);

    expect(model.cumulativeAt(1_060n)).toEqual([6_000n, -6_000n]);
    expect(model.cumulativeAt(1_180n)).toEqual([30_000n, -30_000n]);
    expect(model.cumulativeAt(1_300n, 1_300n)).toEqual([66_000n, -66_000n]);
  });

  it('fills and wraps the 512-entry ring in chronological order', () => {
    const model = new ObservationModel(2);
    model.initialize(1_000n, [1n, 2n]);
    for (let sample = 1n; sample <= 512n; sample += 1n) {
      model.checkpoint(1_000n + sample * 120n);
    }

    const observations = model.observations();
    expect(observations).toHaveLength(512);
    expect(model.metadata().cardinality).toBe(512);
    expect(observations[0].timestamp).toBe(1_120n);
    expect(observations[511].timestamp).toBe(62_440n);
    expect(() => model.cumulativeAt(1_119n)).toThrow('insufficient history');
  });

  it('reconstructs time-weighted geometric means', () => {
    const model = new ObservationModel(2);
    model.initialize(1_000n, [logWad(2), logWad(8)]);
    model.install(1_120n, [logWad(8), logWad(2)]);

    const means = model.geometricMeans(1_240n, 240n);
    expect(means[0]).toBeCloseTo(4, 12);
    expect(means[1]).toBeCloseTo(4, 12);
  });

  it('supports every approved token count from two through eight independently', () => {
    for (let tokenCount = 2; tokenCount <= 8; tokenCount += 1) {
      const logs = Array.from({ length: tokenCount }, (_, index) => BigInt(index + 1) * 10n);
      const model = new ObservationModel(tokenCount);
      model.initialize(1_000n, logs);
      model.checkpoint(1_120n);
      expect(model.averageLogs(1_120n, 120n)).toEqual(logs);
    }
  });

  it('rejects zero windows, old history, and invalid lifecycle input', () => {
    expect(() => new ObservationModel(1)).toThrow('invalid token count');
    expect(() => new ObservationModel(9)).toThrow('invalid token count');

    const model = new ObservationModel(2);
    expect(() => model.checkpoint(1_000n)).toThrow('not initialized');
    model.initialize(1_000n, [1n, 2n]);
    expect(() => model.averageLogs(1_100n, 0n)).toThrow('zero window');
    expect(() => model.cumulativeAt(999n)).toThrow('insufficient history');
    expect(() => model.install(999n, [1n, 2n])).toThrow('timestamp regression');
    expect(() => model.install(1_100n, [1n])).toThrow('wrong log count');
  });
});
