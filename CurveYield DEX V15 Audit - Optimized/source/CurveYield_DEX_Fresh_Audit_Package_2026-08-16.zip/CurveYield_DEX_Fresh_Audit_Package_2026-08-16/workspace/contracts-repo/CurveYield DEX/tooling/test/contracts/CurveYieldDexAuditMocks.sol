// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import { IBalancerV3Vault } from "../../../contracts/interfaces/IBalancerV3Vault.sol";
import { HooksConfig } from "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";

contract MockDexERC20 {
    string public name;
    string public symbol;
    uint8 public constant decimals = 18;
    uint256 public totalSupply;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    constructor(string memory name_, string memory symbol_) {
        name = name_;
        symbol = symbol_;
    }

    function mint(address receiver, uint256 amount) external {
        balanceOf[receiver] += amount;
        totalSupply += amount;
    }

    function transfer(address receiver, uint256 amount) external returns (bool) {
        _transfer(msg.sender, receiver, amount);
        return true;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }

    function transferFrom(address sender, address receiver, uint256 amount) external returns (bool) {
        uint256 approved = allowance[sender][msg.sender];
        require(approved >= amount, "allowance");
        if (approved != type(uint256).max) allowance[sender][msg.sender] = approved - amount;
        _transfer(sender, receiver, amount);
        return true;
    }

    function _transfer(address sender, address receiver, uint256 amount) private {
        require(balanceOf[sender] >= amount, "balance");
        balanceOf[sender] -= amount;
        balanceOf[receiver] += amount;
    }
}

contract MockDexCreatorFeeSplitter {
    uint256 public syncCount;

    function syncCreatorSwapFee() external {
        ++syncCount;
    }
}

contract MockDexVault is IBalancerV3Vault {
    mapping(address => address[]) private _poolTokens;
    mapping(address => HooksConfig) private _hooksConfig;

    function setPoolTokens(address pool, address[] calldata tokens) external {
        _poolTokens[pool] = tokens;
    }

    function setHooksConfig(address pool, HooksConfig calldata hooksConfig) external {
        _hooksConfig[pool] = hooksConfig;
    }

    function getPoolTokens(address pool) external view returns (address[] memory tokens) {
        return _poolTokens[pool];
    }

    function getHooksConfig(address pool) external view returns (HooksConfig memory hooksConfig) {
        return _hooksConfig[pool];
    }

    function getPoolRoleAccounts(address) external pure returns (PoolRoleAccounts memory roleAccounts) {
        return roleAccounts;
    }
}

contract MockDexProtocolFeeController {
    mapping(address => uint256) public protocolSwapFeePercentage;
    mapping(address => uint256) public creatorSwapFeePercentage;
    mapping(address => address[]) private _poolTokens;
    mapping(address => uint256[]) private _protocolFeeAmounts;
    mapping(address => uint256[]) private _creatorFeeAmounts;

    function setPoolTokens(address pool, address[] calldata tokens) external {
        _poolTokens[pool] = tokens;
    }

    function setFeeAmounts(
        address pool,
        uint256[] calldata protocolAmounts,
        uint256[] calldata creatorAmounts
    ) external {
        require(
            protocolAmounts.length == _poolTokens[pool].length
                && creatorAmounts.length == _poolTokens[pool].length,
            "length"
        );
        _protocolFeeAmounts[pool] = protocolAmounts;
        _creatorFeeAmounts[pool] = creatorAmounts;
    }

    function setMockProtocolSwapFeePercentage(address pool, uint256 percentage) external {
        protocolSwapFeePercentage[pool] = percentage;
    }

    function getPoolProtocolSwapFeeInfo(address pool) external view returns (uint256, bool) {
        return (protocolSwapFeePercentage[pool], true);
    }

    function setPoolCreatorSwapFeePercentage(address pool, uint256 percentage) external {
        creatorSwapFeePercentage[pool] = percentage;
    }

    function getPoolCreatorSwapFeePercentage(address pool) external view returns (uint256) {
        return creatorSwapFeePercentage[pool];
    }

    function setProtocolSwapFeePercentage(address pool, uint256 percentage) external {
        protocolSwapFeePercentage[pool] = percentage;
    }

    function collectAggregateFees(address) external {}

    function getProtocolFeeAmounts(address pool) external view returns (uint256[] memory amounts) {
        return _protocolFeeAmounts[pool];
    }

    function getPoolCreatorFeeAmounts(address pool) external view returns (uint256[] memory amounts) {
        return _creatorFeeAmounts[pool];
    }

    function withdrawProtocolFees(address pool, address recipient) external {
        _withdraw(pool, recipient, _protocolFeeAmounts[pool]);
        delete _protocolFeeAmounts[pool];
    }

    function withdrawPoolCreatorFees(address pool, address recipient) external {
        _withdraw(pool, recipient, _creatorFeeAmounts[pool]);
        delete _creatorFeeAmounts[pool];
    }

    function _withdraw(address pool, address recipient, uint256[] storage amounts) private {
        address[] storage tokens = _poolTokens[pool];
        require(tokens.length == amounts.length, "length");
        for (uint256 i = 0; i < tokens.length; ++i) {
            if (amounts[i] != 0) {
                require(MockDexERC20(tokens[i]).transfer(recipient, amounts[i]), "transfer");
            }
        }
    }
}

contract MockDexBalancerRouter {
    function getPermit2() external pure returns (address) {
        return address(1);
    }

    function querySwapSingleTokenExactIn(
        address,
        address,
        address,
        uint256 amountIn,
        address,
        bytes calldata
    ) external pure returns (uint256) {
        return amountIn;
    }

    function swapSingleTokenExactIn(
        address,
        address,
        address,
        uint256 amountIn,
        uint256,
        uint256,
        bool,
        bytes calldata
    ) external pure returns (uint256) {
        return amountIn;
    }

    function queryAddLiquidityUnbalanced(
        address,
        uint256[] calldata exactAmountsIn,
        address,
        bytes calldata
    ) external pure returns (uint256 bptAmountOut) {
        for (uint256 i = 0; i < exactAmountsIn.length; ++i) {
            bptAmountOut += exactAmountsIn[i];
        }
    }

    function queryAddLiquiditySingleTokenExactOut(
        address,
        address,
        uint256 exactBptAmountOut,
        address,
        bytes calldata
    ) external pure returns (uint256 amountIn) {
        return exactBptAmountOut;
    }
}

contract MockDexPermit2 {
    struct PermitAllowance {
        uint160 amount;
        uint48 expiration;
    }

    mapping(address => mapping(address => mapping(address => PermitAllowance))) public permitAllowance;

    function approve(address token, address spender, uint160 amount, uint48 expiration) external {
        permitAllowance[msg.sender][token][spender] =
            PermitAllowance({ amount: amount, expiration: expiration });
    }

    function transferFrom(address sender, address receiver, uint160 amount, address token) external {
        PermitAllowance storage approved = permitAllowance[sender][token][msg.sender];
        require(approved.expiration >= block.timestamp, "expired");
        require(approved.amount >= amount, "permit");
        approved.amount -= amount;
        require(MockDexERC20(token).transferFrom(sender, receiver, amount), "transfer");
    }
}

contract MockDexMigrationRouter {
    MockDexPermit2 public immutable permit2;
    IBalancerV3Vault public immutable vault;

    mapping(address => uint256[]) private _exitAmounts;
    mapping(address => uint256) public joinBptOut;

    constructor(address permit2_, address vault_) {
        permit2 = MockDexPermit2(permit2_);
        vault = IBalancerV3Vault(vault_);
    }

    function getPermit2() external view returns (address) {
        return address(permit2);
    }

    function setExitAmounts(address pool, uint256[] calldata amounts) external {
        _exitAmounts[pool] = amounts;
    }

    function setJoinBptOut(address pool, uint256 amount) external {
        joinBptOut[pool] = amount;
    }

    function removeLiquidityProportional(
        address pool,
        uint256 exactBptAmountIn,
        uint256[] memory minAmountsOut,
        bool,
        bytes memory
    ) external returns (uint256[] memory amountsOut) {
        permit2.transferFrom(msg.sender, address(this), uint160(exactBptAmountIn), pool);
        amountsOut = _exitAmounts[pool];
        address[] memory tokens = vault.getPoolTokens(pool);
        require(tokens.length == amountsOut.length && tokens.length == minAmountsOut.length, "length");
        for (uint256 i = 0; i < tokens.length; ++i) {
            require(amountsOut[i] >= minAmountsOut[i], "minimum");
            require(MockDexERC20(tokens[i]).transfer(msg.sender, amountsOut[i]), "transfer");
        }
    }

    function queryRemoveLiquidityProportional(
        address pool,
        uint256,
        address,
        bytes memory
    ) external view returns (uint256[] memory amountsOut) {
        return _exitAmounts[pool];
    }

    function addLiquidityUnbalanced(
        address pool,
        uint256[] memory exactAmountsIn,
        uint256 minBptAmountOut,
        bool,
        bytes memory
    ) external returns (uint256 bptAmountOut) {
        address[] memory tokens = vault.getPoolTokens(pool);
        require(tokens.length == exactAmountsIn.length, "length");
        for (uint256 i = 0; i < tokens.length; ++i) {
            if (exactAmountsIn[i] != 0) {
                permit2.transferFrom(msg.sender, address(this), uint160(exactAmountsIn[i]), tokens[i]);
            }
        }
        bptAmountOut = joinBptOut[pool];
        require(bptAmountOut >= minBptAmountOut, "minimum");
        MockDexERC20(pool).mint(msg.sender, bptAmountOut);
    }

    function queryAddLiquidityUnbalanced(
        address pool,
        uint256[] calldata,
        address,
        bytes memory
    ) external view returns (uint256 bptAmountOut) {
        return joinBptOut[pool];
    }
}
