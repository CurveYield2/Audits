import fs from 'node:fs';
import { describe, expect, it } from 'vitest';
import { compileContracts } from '../lib/compileSolc.mjs';

describe('PoolFeePolicyRegistry source', () => {
  it('compiles with updated creator cap constants and disabled creator arb fee', () => {
    const { compiled } = compileContracts(
      ['contracts/PoolFeePolicyRegistry.sol'],
      ['PoolFeePolicyRegistry']
    );
    expect(compiled.PoolFeePolicyRegistry).toBeTruthy();

    const source = fs.readFileSync('contracts/lib/CurveYieldFeeMath.sol', 'utf8');
    expect(source).toContain('CREATOR_PERSONAL_MAX_BPS = 2_000');
    expect(source).toContain('CREATOR_PL_MAX_BPS = 5_000');
    expect(source).not.toContain('CREATOR_ARB_MAX_BPS');
    expect(source).toContain('CREATOR_PARTNER_MAX_BPS = 2_000');
    expect(source).toContain('CREATOR_TOTAL_MAX_BPS = 9_000');
  }, 30_000);

  it('rejects BPT-producing creator policy for ReClamm pools until a ReClamm settlement path exists', () => {
    const source = fs.readFileSync('contracts/PoolFeePolicyRegistry.sol', 'utf8');

    expect(source).toContain('ReClammBptSettlementUnsupported');
    expect(source).toContain('_validatePoolTypePolicyCompatibility');
    expect(source).toContain('poolType == PoolType.ReClamm');
    expect(source).toContain('creatorConfig.creatorPermanentLiquidityBps != 0');
  });

  it('keeps Partner PoL config limited to static admin fee allocation without onchain matching sources', () => {
    const source = fs.readFileSync('contracts/PoolFeePolicyRegistry.sol', 'utf8');

    expect(source).toContain('struct PartnerPoLConfig');
    expect(source).toContain('address targetPool;');
    expect(source).not.toContain('crvYieldSource');
    expect(source).not.toContain('crvYieldMatchBps');
    expect(source).not.toContain('partnerTokenSource');
    expect(source).not.toContain('partnerMatchBps');
  });
});
