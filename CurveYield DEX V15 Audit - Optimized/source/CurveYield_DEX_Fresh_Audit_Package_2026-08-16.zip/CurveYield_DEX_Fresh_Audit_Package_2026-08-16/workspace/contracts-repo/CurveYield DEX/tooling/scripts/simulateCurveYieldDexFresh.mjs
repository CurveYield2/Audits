import fs from "node:fs";
import path from "node:path";
import {
  concat,
  createPublicClient,
  defineChain,
  encodeDeployData,
  encodeFunctionData,
  getContractAddress,
  http,
  keccak256,
  padHex,
  parseAbi,
  toFunctionSelector,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { compileContracts } from "../lib/compileSolc.mjs";
import { balancerReClammRoot, balancerV3Root, dexRoot } from "../lib/paths.mjs";

const BASE_CHAIN_ID = 8453;
const BASE_RPC_URL =
  process.env.SIMULATION_BASE_RPC_URL ||
  process.env.BASE_RPC_URL ||
  "https://base-mainnet.core.chainstack.com/e9c42c80240f7039626857286cb976bc";
const DAO = envAddress(
  "CURVEYIELD_DAO",
  "0x7142b1Cc5F91A736A62e77581F406338328F05bC",
);
const DEFAULT_PAYOUT_TOKEN = envAddress(
  "CURVEYIELD_DEFAULT_PAYOUT_TOKEN",
  "0xd7bb4c715d66a3ac3742ab9d2e2f5274da17ce22",
);
const WETH = envAddress("WETH", "0x4200000000000000000000000000000000000006");
const PERMIT2 = envAddress(
  "PERMIT2",
  "0x000000000022D473030F116dDEE9F6B43aC78BA3",
);
const MAX_FEE_PER_GAS = envBigInt("MAX_FEE_PER_GAS_WEI", 150_000_000n);
const MAX_PRIORITY_FEE_PER_GAS = envBigInt("MAX_PRIORITY_FEE_PER_GAS_WEI", 1_000_000n);
const POOL_CREATION_FEE_WEI = envBigInt("POOL_CREATION_FEE_WEI", 110_000_000_000_000n);
const ROOT_TRANSFER_DELAY = envBigInt("ROOT_TRANSFER_DELAY_SECONDS", 0n);
const ETH_USD = Number(process.env.ETH_USD || "1624.95");

const PROTOCOL_SWAP_FEE_PERCENTAGE = envBigInt(
  "PROTOCOL_SWAP_FEE_PERCENTAGE",
  300_000_000_000_000_000n,
);
const PROTOCOL_YIELD_FEE_PERCENTAGE = envBigInt("PROTOCOL_YIELD_FEE_PERCENTAGE", 0n);
const VAULT_PAUSE_WINDOW_SECONDS = Number(envBigInt("VAULT_PAUSE_WINDOW_SECONDS", 365n * 24n * 60n * 60n));
const VAULT_BUFFER_PERIOD_SECONDS = Number(envBigInt("VAULT_BUFFER_PERIOD_SECONDS", 30n * 24n * 60n * 60n));
const FACTORY_PAUSE_WINDOW_SECONDS = Number(
  envBigInt("FACTORY_PAUSE_WINDOW_SECONDS", 365n * 24n * 60n * 60n),
);
const MIN_TRADE_AMOUNT = envBigInt("MIN_TRADE_AMOUNT", 1_000_000n);
const MIN_WRAP_AMOUNT = envBigInt("MIN_WRAP_AMOUNT", 1_000_000n);
const DEFAULT_MEV_TAX_MULTIPLIER = envBigInt("DEFAULT_MEV_TAX_MULTIPLIER", 0n);
const DEFAULT_MEV_TAX_THRESHOLD = envBigInt("DEFAULT_MEV_TAX_THRESHOLD", 0n);
const DEFAULT_MAX_SURGE_FEE_PERCENTAGE = envBigInt(
  "DEFAULT_MAX_SURGE_FEE_PERCENTAGE",
  800_000_000_000_000_000n,
);
const DEFAULT_SURGE_THRESHOLD_PERCENTAGE = envBigInt(
  "DEFAULT_SURGE_THRESHOLD_PERCENTAGE",
  300_000_000_000_000_000n,
);
const GLOBAL_COMBINED_FEE_CAP = envBigInt("GLOBAL_COMBINED_FEE_CAP", 150_000_000_000_000_000n);

const REPORT_PATH = path.join(
  dexRoot,
  "deployment-artifacts",
  `curveyield-dex-fresh-live-simulation-${new Date().toISOString().replace(/[:.]/g, "-")}.json`,
);

const base = defineChain({
  id: BASE_CHAIN_ID,
  name: "Base",
  nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
  rpcUrls: { default: { http: [BASE_RPC_URL] } },
  blockExplorers: { default: { name: "BaseScan", url: "https://basescan.org" } },
});

const publicClient = createPublicClient({ chain: base, transport: http(BASE_RPC_URL) });

const coreEntries = [
  "contracts/CurveYieldBootstrapAuthorizer.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/authorizer/TimelockAuthorizer.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/ProtocolFeeController.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/VaultAdmin.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/VaultExtension.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/Vault.sol",
];
const routerEntries = [
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/Router.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/BatchRouter.sol",
  "../../vendor/balancer-v3-upstream/pkg/vault/contracts/CompositeLiquidityRouter.sol",
  "../../vendor/balancer-v3-upstream/pkg/standalone-utils/contracts/BalancerContractRegistry.sol",
  "../../vendor/balancer-v3-upstream/pkg/standalone-utils/contracts/ProtocolFeeSweeper.sol",
];
const supportEntries = [
  "../../vendor/balancer-reclamm-upstream/contracts/ReClammPoolHelper.sol",
  "contracts/AdminFeeSplitter.sol",
  "contracts/CreatorFeeSplitter.sol",
  "contracts/FeeSettlementKeeper.sol",
  "contracts/FeeSettlementRouter.sol",
  "contracts/PermanentLiquidityVaultV2.sol",
  "contracts/PoolFeePolicyRegistry.sol",
  "contracts/RouteRegistry.sol",
  "contracts/adapters/BalancerV3SwapAdapter.sol",
];
const hooksEntries = [
  "contracts/hooks/CurveYieldHookConfigController.sol",
  "contracts/hooks/CurveYieldMevVolumeHookV14.sol",
  "contracts/hooks/CurveYieldObservationController.sol",
  "contracts/hooks/CurveYieldStableSurgeVolumeHookV14.sol",
  "contracts/hooks/CurveYieldVolumeFeeController.sol",
  "contracts/hooks/ObservationQueryProcessor.sol",
  "contracts/hooks/StableSurgeQueryProcessor.sol",
];
const factoryEntries = [
  "contracts/CurveYieldPoolFactoryWrapper.sol",
  "contracts/factories/CurveYieldReClammPoolFactory.sol",
  "contracts/factories/CurveYieldStablePoolFactory.sol",
  "contracts/factories/CurveYieldStableSurgePoolFactory.sol",
  "contracts/factories/CurveYieldWeightedPoolFactory.sol",
];
const expectedContracts = [
  "CurveYieldBootstrapAuthorizer",
  "ProtocolFeeController",
  "VaultAdmin",
  "VaultExtension",
  "Vault",
  "TimelockAuthorizer",
  "Router",
  "BatchRouter",
  "CompositeLiquidityRouter",
  "BalancerContractRegistry",
  "ProtocolFeeSweeper",
  "ReClammPoolHelper",
  "PoolFeePolicyRegistry",
  "AdminFeeSplitter",
  "RouteRegistry",
  "PermanentLiquidityVaultV2",
  "FeeSettlementRouter",
  "FeeSettlementKeeper",
  "BalancerV3SwapAdapter",
  "CurveYieldHookConfigController",
  "ObservationQueryProcessor",
  "CurveYieldObservationController",
  "CurveYieldVolumeFeeController",
  "StableSurgeQueryProcessor",
  "CurveYieldMevVolumeHookV14",
  "CurveYieldStableSurgeVolumeHookV14",
  "CurveYieldWeightedPoolFactory",
  "CurveYieldStablePoolFactory",
  "CurveYieldStableSurgePoolFactory",
  "CurveYieldReClammPoolFactory",
  "CurveYieldPoolFactoryWrapper",
];

const authAbi = parseAbi(["function grantPermission(bytes32 actionId,address account,address where)"]);
const factoryAllowlistAbi = parseAbi(["function setAllowedPoolCreator(address account,bool allowed)"]);

const report = {
  mode: "eth_simulateV1",
  startedAt: new Date().toISOString(),
  rpcUrl: BASE_RPC_URL,
  chainId: BASE_CHAIN_ID,
  ethUsd: ETH_USD,
  maxFeePerGasWei: MAX_FEE_PER_GAS.toString(),
  maxPriorityFeePerGasWei: MAX_PRIORITY_FEE_PER_GAS.toString(),
  dao: DAO,
  defaultPayoutToken: DEFAULT_PAYOUT_TOKEN,
  weth: WETH,
  permit2: PERMIT2,
  upstreamRoots: { balancerV3Root, balancerReClammRoot },
  parameters: {
    protocolSwapFeePercentage: PROTOCOL_SWAP_FEE_PERCENTAGE.toString(),
    protocolYieldFeePercentage: PROTOCOL_YIELD_FEE_PERCENTAGE.toString(),
    vaultPauseWindowSeconds: VAULT_PAUSE_WINDOW_SECONDS,
    vaultBufferPeriodSeconds: VAULT_BUFFER_PERIOD_SECONDS,
    factoryPauseWindowSeconds: FACTORY_PAUSE_WINDOW_SECONDS,
    minTradeAmount: MIN_TRADE_AMOUNT.toString(),
    minWrapAmount: MIN_WRAP_AMOUNT.toString(),
    poolCreationFeeWei: POOL_CREATION_FEE_WEI.toString(),
    defaultMevTaxMultiplier: DEFAULT_MEV_TAX_MULTIPLIER.toString(),
    defaultMevTaxThreshold: DEFAULT_MEV_TAX_THRESHOLD.toString(),
    defaultMaxSurgeFeePercentage: DEFAULT_MAX_SURGE_FEE_PERCENTAGE.toString(),
    defaultSurgeThresholdPercentage: DEFAULT_SURGE_THRESHOLD_PERCENTAGE.toString(),
    globalCombinedFeeCap: GLOBAL_COMBINED_FEE_CAP.toString(),
  },
  deployer: null,
  startingNonce: null,
  predictedDeployments: [],
  calls: [],
  simulation: null,
};

async function main() {
  const privateKey = loadPrivateKey();
  const account = privateKeyToAccount(privateKey);
  report.deployer = account.address;

  const chainId = await publicClient.getChainId();
  if (chainId !== BASE_CHAIN_ID) throw new Error(`Wrong chain id ${chainId}; expected ${BASE_CHAIN_ID}`);
  const latestBlock = await publicClient.getBlock({ blockTag: "latest" });
  if ((latestBlock.baseFeePerGas || 0n) > MAX_FEE_PER_GAS) {
    throw new Error(
      `Base fee ${latestBlock.baseFeePerGas} exceeds maxFeePerGas ${MAX_FEE_PER_GAS}; refusing to simulate deploy cost`,
    );
  }

  const startingNonce = await publicClient.getTransactionCount({ address: account.address, blockTag: "pending" });
  report.startingNonce = startingNonce;
  let nextNonce = startingNonce;

  console.log(`Simulation mode: eth_simulateV1`);
  console.log(`RPC: ${BASE_RPC_URL}`);
  console.log(`Deployer: ${account.address}`);
  console.log(`Pending nonce: ${startingNonce}`);
  console.log(`DAO/final owner: ${DAO}`);
  console.log(`Gas cap: ${MAX_FEE_PER_GAS} wei`);
  console.log("Compiling active CurveYield DEX deployment set...");

  const artifacts = compileAll();
  for (const name of expectedContracts) {
    if (!artifacts[name]) throw new Error(`Missing compiled artifact: ${name}`);
  }

  const libraries = {};
  const predicted = {};
  for (let i = 0; i < expectedContracts.length; i += 1) {
    const nonce = startingNonce + i;
    const expectedAddress = getContractAddress({ from: account.address, nonce: BigInt(nonce) });
    predicted[expectedContracts[i]] = expectedAddress;
    report.predictedDeployments.push({ nonce, name: expectedContracts[i], expectedAddress });
  }

  const calls = [];
  const pushDeploy = (name, args = [], options = {}) => {
    const expected = getContractAddress({ from: account.address, nonce: BigInt(nextNonce) });
    if (expected.toLowerCase() !== predicted[name].toLowerCase()) {
      throw new Error(`${name} expected ${predicted[name]}, got ${expected}`);
    }
    const artifact = artifacts[name];
    const bytecode = linkBytecode(artifact, libraries);
    const data = encodeDeployData({ abi: artifact.abi, bytecode, args });
    pushCall({ label: `deploy ${name}`, from: account.address, data, nonce: nextNonce });
    if (options.library) libraries[name] = expected;
    nextNonce += 1;
    return expected;
  };

  const vault = predicted.Vault;
  const bootstrapAuthorizer = pushDeploy("CurveYieldBootstrapAuthorizer", [account.address]);
  const protocolFeeController = pushDeploy("ProtocolFeeController", [
    vault,
    PROTOCOL_SWAP_FEE_PERCENTAGE,
    PROTOCOL_YIELD_FEE_PERCENTAGE,
  ]);
  const vaultAdmin = pushDeploy("VaultAdmin", [
    vault,
    VAULT_PAUSE_WINDOW_SECONDS,
    VAULT_BUFFER_PERIOD_SECONDS,
    MIN_TRADE_AMOUNT,
    MIN_WRAP_AMOUNT,
  ]);
  const vaultExtension = pushDeploy("VaultExtension", [vault, vaultAdmin]);
  pushDeploy("Vault", [vaultExtension, bootstrapAuthorizer, protocolFeeController]);
  const authorizer = pushDeploy("TimelockAuthorizer", [account.address, DAO, vault, ROOT_TRANSFER_DELAY]);
  const router = pushDeploy("Router", [vault, WETH, PERMIT2, "CurveYield Router v1"]);
  const batchRouter = pushDeploy("BatchRouter", [vault, WETH, PERMIT2, "CurveYield BatchRouter v1"]);
  const compositeLiquidityRouter = pushDeploy("CompositeLiquidityRouter", [
    vault,
    WETH,
    PERMIT2,
    "CurveYield CompositeLiquidityRouter v1",
  ]);
  const contractRegistry = pushDeploy("BalancerContractRegistry", [vault]);
  const protocolFeeSweeper = pushDeploy("ProtocolFeeSweeper", [vault, DAO]);
  const reClammPoolHelper = pushDeploy("ReClammPoolHelper", [vault]);
  const poolFeePolicyRegistry = pushDeploy("PoolFeePolicyRegistry", [account.address, vault]);
  pushDeploy("AdminFeeSplitter", [poolFeePolicyRegistry]);
  const routeRegistry = pushDeploy("RouteRegistry", [account.address]);
  const permanentLiquidityVault = pushDeploy("PermanentLiquidityVaultV2", [
    account.address,
    router,
    vault,
    routeRegistry,
    PERMIT2,
  ]);
  const feeSettlementRouter = pushDeploy("FeeSettlementRouter", [
    account.address,
    protocolFeeController,
    predicted.AdminFeeSplitter,
    permanentLiquidityVault,
    vault,
    router,
    DAO,
    DEFAULT_PAYOUT_TOKEN,
  ]);
  const feeSettlementKeeper = pushDeploy("FeeSettlementKeeper", [feeSettlementRouter]);
  const balancerV3SwapAdapter = pushDeploy("BalancerV3SwapAdapter", [
    account.address,
    router,
    feeSettlementRouter,
  ]);
  const hookConfigController = pushDeploy("CurveYieldHookConfigController", [vault]);
  pushDeploy("ObservationQueryProcessor", [], { library: true });
  const observationController = pushDeploy("CurveYieldObservationController", [vault]);
  const volumeFeeController = pushDeploy("CurveYieldVolumeFeeController", [
    vault,
    poolFeePolicyRegistry,
    observationController,
  ]);
  pushDeploy("StableSurgeQueryProcessor", [], { library: true });
  const mevVolumeHook = pushDeploy("CurveYieldMevVolumeHookV14", [
    vault,
    contractRegistry,
    poolFeePolicyRegistry,
    hookConfigController,
    observationController,
    volumeFeeController,
    DEFAULT_MEV_TAX_MULTIPLIER,
    DEFAULT_MEV_TAX_THRESHOLD,
  ]);
  const stableSurgeVolumeHook = pushDeploy("CurveYieldStableSurgeVolumeHookV14", [
    vault,
    contractRegistry,
    poolFeePolicyRegistry,
    hookConfigController,
    observationController,
    volumeFeeController,
    DEFAULT_MAX_SURGE_FEE_PERCENTAGE,
    DEFAULT_SURGE_THRESHOLD_PERCENTAGE,
    "CurveYield StableSurge Volume Hook v1",
  ]);
  const weightedFactory = pushDeploy("CurveYieldWeightedPoolFactory", [
    vault,
    FACTORY_PAUSE_WINDOW_SECONDS,
    "CurveYield WeightedPoolFactory v1",
    "CurveYield WeightedPool v1",
    account.address,
  ]);
  const stableFactory = pushDeploy("CurveYieldStablePoolFactory", [
    vault,
    FACTORY_PAUSE_WINDOW_SECONDS,
    "CurveYield StablePoolFactory v1",
    "CurveYield StablePool v1",
    account.address,
  ]);
  const stableSurgeFactory = pushDeploy("CurveYieldStableSurgePoolFactory", [
    stableSurgeVolumeHook,
    FACTORY_PAUSE_WINDOW_SECONDS,
    "CurveYield StableSurgePoolFactory v1",
    "CurveYield StableSurgePool v1",
    account.address,
  ]);
  const reClammFactory = pushDeploy("CurveYieldReClammPoolFactory", [
    vault,
    reClammPoolHelper,
    FACTORY_PAUSE_WINDOW_SECONDS,
    "CurveYield ReClammPoolFactory v1",
    "CurveYield ReClammPool v1",
    account.address,
  ]);
  const wrapper = pushDeploy("CurveYieldPoolFactoryWrapper", [
    account.address,
    poolFeePolicyRegistry,
    protocolFeeController,
    feeSettlementRouter,
    stableSurgeFactory,
    stableFactory,
    weightedFactory,
    reClammFactory,
  ]);

  const call = (label, to, abi, functionName, args = []) => {
    const data = encodeFunctionData({ abi, functionName, args });
    pushCall({ label, from: account.address, to, data, nonce: nextNonce });
    nextNonce += 1;
  };

  const ownableAbi = parseAbi(["function transferOwnership(address newOwner)"]);
  const registryAbi = artifacts.BalancerContractRegistry.abi;
  const vaultAbi = parseAbi(["function setAuthorizer(address newAuthorizer)"]);
  const hookConfigAbi = artifacts.CurveYieldHookConfigController.abi;
  const observationAbi = artifacts.CurveYieldObservationController.abi;
  const volumeFeeAbi = artifacts.CurveYieldVolumeFeeController.abi;
  const feeRouterAbi = artifacts.FeeSettlementRouter.abi;
  const feeRegistryAbi = artifacts.PoolFeePolicyRegistry.abi;
  const permanentVaultAbi = artifacts.PermanentLiquidityVaultV2.abi;
  const routeRegistryAbi = artifacts.RouteRegistry.abi;
  const swapAdapterAbi = artifacts.BalancerV3SwapAdapter.abi;
  const wrapperAbi = artifacts.CurveYieldPoolFactoryWrapper.abi;

  const grant = (target, signature, grantee, label) => {
    const actionId = computeActionId(target, signature);
    call(`grant ${label}`, authorizer, authAbi, "grantPermission", [actionId, grantee, target]);
  };

  grant(contractRegistry, "registerBalancerContract(uint8,string,address)", account.address, "deployer registry register");
  grant(contractRegistry, "addOrUpdateBalancerContractAlias(string,address)", account.address, "deployer registry alias");
  grant(hookConfigController, "setApprovedHook(address,bool)", account.address, "deployer hook-config approve hook");
  grant(hookConfigController, "setFactoryPoolKind(address,uint8)", account.address, "deployer hook-config factory kind");
  grant(hookConfigController, "setSettlementRouter(address,bool)", account.address, "deployer hook-config settlement router");
  grant(hookConfigController, "setGlobalCombinedFeeCap(uint256)", account.address, "deployer hook-config global fee cap");
  grant(observationController, "setApprovedHook(address,bool)", account.address, "deployer observation approve hook");
  grant(volumeFeeController, "setApprovedHook(address,bool)", account.address, "deployer volume approve hook");
  grant(protocolFeeController, "withdrawProtocolFees(address,address)", feeSettlementRouter, "fee router withdraw protocol fees");

  for (const sig of [
    "registerBalancerContract(uint8,string,address)",
    "addOrUpdateBalancerContractAlias(string,address)",
  ]) {
    grant(contractRegistry, sig, DAO, `DAO registry ${sig}`);
  }
  for (const sig of [
    "setApprovedHook(address,bool)",
    "setFactoryPoolKind(address,uint8)",
    "setSettlementRouter(address,bool)",
    "setGlobalCombinedFeeCap(uint256)",
    "setPoolCombinedFeeCap(address,bool,uint256)",
    "setSettlementOracleConfig(address,uint32,uint16)",
    "setProtectedSettlementPaused(bool)",
  ]) {
    grant(hookConfigController, sig, DAO, `DAO hook-config ${sig}`);
  }
  for (const sig of ["setApprovedHook(address,bool)"]) {
    grant(observationController, sig, DAO, `DAO observation ${sig}`);
    grant(volumeFeeController, sig, DAO, `DAO volume ${sig}`);
  }
  for (const sig of [
    "disableMevTax()",
    "enableMevTax()",
    "setMaxMevSwapFeePercentage(uint256)",
    "setDefaultMevTaxMultiplier(uint256)",
    "setDefaultMevTaxThreshold(uint256)",
    "addMevTaxExemptSenders(address[])",
    "removeMevTaxExemptSenders(address[])",
  ]) {
    grant(mevVolumeHook, sig, DAO, `DAO MEV hook ${sig}`);
  }

  call("vault install TimelockAuthorizer", vault, vaultAbi, "setAuthorizer", [authorizer]);

  const ContractType = { OTHER: 0, POOL_FACTORY: 1, ROUTER: 2, HOOK: 3 };
  for (const [contractType, name, address] of [
    [ContractType.ROUTER, "curveyield-v1-router", router],
    [ContractType.ROUTER, "curveyield-v1-batch-router", batchRouter],
    [ContractType.ROUTER, "curveyield-v1-composite-liquidity-router", compositeLiquidityRouter],
    [ContractType.POOL_FACTORY, "curveyield-v1-weighted-pool-factory", weightedFactory],
    [ContractType.POOL_FACTORY, "curveyield-v1-stable-pool-factory", stableFactory],
    [ContractType.POOL_FACTORY, "curveyield-v1-stable-surge-pool-factory", stableSurgeFactory],
    [ContractType.POOL_FACTORY, "curveyield-v1-reclamm-pool-factory", reClammFactory],
    [ContractType.HOOK, "curveyield-v1-mev-volume-hook", mevVolumeHook],
    [ContractType.HOOK, "curveyield-v1-stable-surge-volume-hook", stableSurgeVolumeHook],
    [ContractType.OTHER, "curveyield-v1-protocol-fee-sweeper", protocolFeeSweeper],
    [ContractType.OTHER, "curveyield-v1-reclamm-pool-helper", reClammPoolHelper],
  ]) {
    call(`registry register ${name}`, contractRegistry, registryAbi, "registerBalancerContract", [
      contractType,
      name,
      address,
    ]);
  }
  for (const [alias, address] of [
    ["Router", router],
    ["BatchRouter", batchRouter],
    ["CompositeLiquidityRouter", compositeLiquidityRouter],
    ["WeightedPool", weightedFactory],
    ["StablePool", stableFactory],
    ["StableSurgePool", stableSurgeFactory],
    ["ReClammPool", reClammFactory],
    ["MevCaptureHook", mevVolumeHook],
    ["StableSurgeHook", stableSurgeVolumeHook],
  ]) {
    call(`registry alias ${alias}`, contractRegistry, registryAbi, "addOrUpdateBalancerContractAlias", [
      alias,
      address,
    ]);
  }

  call("registry set wrapper registrar", poolFeePolicyRegistry, feeRegistryAbi, "setPoolRegistrar", [
    wrapper,
    true,
  ]);
  call("route registry allow balancer adapter", routeRegistry, routeRegistryAbi, "setAdapterAllowed", [
    balancerV3SwapAdapter,
    true,
  ]);
  call("permanent vault set settlement router", permanentLiquidityVault, permanentVaultAbi, "setSettlementRouter", [
    feeSettlementRouter,
  ]);
  call("fee router approve keeper", feeSettlementRouter, feeRouterAbi, "setKeeper", [
    feeSettlementKeeper,
    true,
  ]);
  call("fee router approve wrapper registrar", feeSettlementRouter, feeRouterAbi, "setCreatorFeeSplitterRegistrar", [
    wrapper,
    true,
  ]);
  call("fee router approve MEV hook BPT settlement", feeSettlementRouter, feeRouterAbi, "setProtectedBptSettlementHook", [
    mevVolumeHook,
    true,
  ]);
  call(
    "fee router approve StableSurge hook BPT settlement",
    feeSettlementRouter,
    feeRouterAbi,
    "setProtectedBptSettlementHook",
    [stableSurgeVolumeHook, true],
  );
  call("swap adapter authorize permanent vault", balancerV3SwapAdapter, swapAdapterAbi, "setAuthorizedCaller", [
    permanentLiquidityVault,
    true,
  ]);
  call("wrapper set creation fee", wrapper, wrapperAbi, "setPoolCreationFeeConfig", [
    DAO,
    POOL_CREATION_FEE_WEI,
  ]);

  for (const [label, factory] of [
    ["weighted", weightedFactory],
    ["stable", stableFactory],
    ["stable surge", stableSurgeFactory],
    ["reclamm", reClammFactory],
  ]) {
    call(`factory allow wrapper ${label}`, factory, factoryAllowlistAbi, "setAllowedPoolCreator", [
      wrapper,
      true,
    ]);
  }

  const HookKind = { WEIGHTED: 1, STABLE: 2, STABLE_SURGE: 3 };
  for (const [label, factory, kind] of [
    ["weighted", weightedFactory, HookKind.WEIGHTED],
    ["stable", stableFactory, HookKind.STABLE],
    ["stable surge", stableSurgeFactory, HookKind.STABLE_SURGE],
  ]) {
    call(`hook config factory kind ${label}`, hookConfigController, hookConfigAbi, "setFactoryPoolKind", [
      factory,
      kind,
    ]);
  }
  call("hook config approve MEV hook", hookConfigController, hookConfigAbi, "setApprovedHook", [
    mevVolumeHook,
    true,
  ]);
  call("hook config approve StableSurge hook", hookConfigController, hookConfigAbi, "setApprovedHook", [
    stableSurgeVolumeHook,
    true,
  ]);
  call("hook config approve fee router settlement", hookConfigController, hookConfigAbi, "setSettlementRouter", [
    feeSettlementRouter,
    true,
  ]);
  call("hook config set global combined fee cap", hookConfigController, hookConfigAbi, "setGlobalCombinedFeeCap", [
    GLOBAL_COMBINED_FEE_CAP,
  ]);
  for (const [label, hook] of [
    ["MEV", mevVolumeHook],
    ["StableSurge", stableSurgeVolumeHook],
  ]) {
    call(`observation approve ${label} hook`, observationController, observationAbi, "setApprovedHook", [
      hook,
      true,
    ]);
    call(`volume approve ${label} hook`, volumeFeeController, volumeFeeAbi, "setApprovedHook", [
      hook,
      true,
    ]);
  }

  for (const [name, address] of [
    ["PoolFeePolicyRegistry", poolFeePolicyRegistry],
    ["RouteRegistry", routeRegistry],
    ["PermanentLiquidityVaultV2", permanentLiquidityVault],
    ["FeeSettlementRouter", feeSettlementRouter],
    ["BalancerV3SwapAdapter", balancerV3SwapAdapter],
    ["CurveYieldWeightedPoolFactory", weightedFactory],
    ["CurveYieldStablePoolFactory", stableFactory],
    ["CurveYieldStableSurgePoolFactory", stableSurgeFactory],
    ["CurveYieldReClammPoolFactory", reClammFactory],
    ["CurveYieldPoolFactoryWrapper", wrapper],
  ]) {
    call(`transfer ownership ${name} to DAO`, address, ownableAbi, "transferOwnership", [DAO]);
  }

  console.log(`Built ${calls.length} stateful simulation calls.`);
  const simulation = await simulateCalls(calls);
  report.simulation = summarizeSimulation(simulation);
  saveReport();

  console.log(`Simulation status: ${report.simulation.success ? "success" : "failed"}`);
  console.log(`Total gas used: ${report.simulation.totalGasUsed}`);
  console.log(`Cost at gas cap: ${report.simulation.costAtGasCapEth} ETH / $${report.simulation.costAtGasCapUsd}`);
  console.log(`Cost at simulated base fee: ${report.simulation.costAtSimulatedBaseFeeEth} ETH / $${report.simulation.costAtSimulatedBaseFeeUsd}`);
  console.log(`Report: ${REPORT_PATH}`);
  if (!report.simulation.success) process.exitCode = 1;

  function pushCall({ label, from, to, data, nonce }) {
    calls.push({
      from,
      to,
      input: data,
      nonce: toHex(BigInt(nonce)),
      value: "0x0",
      maxFeePerGas: toHex(MAX_FEE_PER_GAS),
      maxPriorityFeePerGas: toHex(MAX_PRIORITY_FEE_PER_GAS),
    });
    report.calls.push({ label, from, to: to || null, nonce, dataLength: data.length });
  }
}

function compileAll() {
  const groups = [
    [
      coreEntries,
      [
        "CurveYieldBootstrapAuthorizer",
        "TimelockAuthorizer",
        "ProtocolFeeController",
        "VaultAdmin",
        "VaultExtension",
        "Vault",
      ],
    ],
    [
      routerEntries,
      ["Router", "BatchRouter", "CompositeLiquidityRouter", "BalancerContractRegistry", "ProtocolFeeSweeper"],
    ],
    [
      supportEntries,
      [
        "ReClammPoolHelper",
        "AdminFeeSplitter",
        "FeeSettlementKeeper",
        "FeeSettlementRouter",
        "PermanentLiquidityVaultV2",
        "PoolFeePolicyRegistry",
        "RouteRegistry",
        "BalancerV3SwapAdapter",
      ],
    ],
    [
      hooksEntries,
      [
        "CurveYieldHookConfigController",
        "ObservationQueryProcessor",
        "CurveYieldObservationController",
        "CurveYieldVolumeFeeController",
        "StableSurgeQueryProcessor",
        "CurveYieldMevVolumeHookV14",
        "CurveYieldStableSurgeVolumeHookV14",
      ],
    ],
    [
      factoryEntries,
      [
        "CurveYieldPoolFactoryWrapper",
        "CurveYieldReClammPoolFactory",
        "CurveYieldStablePoolFactory",
        "CurveYieldStableSurgePoolFactory",
        "CurveYieldWeightedPoolFactory",
      ],
    ],
  ];
  const merged = {};
  for (const [entries, names] of groups) {
    const startedAt = Date.now();
    const { compiled } = compileContracts(entries, names);
    Object.assign(merged, compiled);
    console.log(`Compiled group in ${((Date.now() - startedAt) / 1000).toFixed(1)}s: ${names.join(", ")}`);
  }
  return merged;
}

function linkBytecode(artifact, libraries) {
  let linked = artifact.bytecode.replace(/^0x/, "");
  for (const refsBySource of Object.values(artifact.linkReferences || {})) {
    for (const [libraryName, refs] of Object.entries(refsBySource)) {
      const libraryAddress = libraries[libraryName];
      if (!libraryAddress) throw new Error(`Missing library deployment for ${artifact.contractName}:${libraryName}`);
      const replacement = libraryAddress.replace(/^0x/, "").toLowerCase();
      for (const ref of refs) {
        const start = ref.start * 2;
        const length = ref.length * 2;
        linked = `${linked.slice(0, start)}${replacement.padStart(length, "0")}${linked.slice(start + length)}`;
      }
    }
  }
  if (linked.includes("__$")) throw new Error(`Unlinked library placeholder remains in ${artifact.contractName}`);
  return `0x${linked}`;
}

function computeActionId(target, signature) {
  const disambiguator = padHex(target, { size: 32 });
  const selector = toFunctionSelector(signature);
  return keccak256(concat([disambiguator, selector]));
}

async function simulateCalls(calls) {
  return await publicClient.request({
    method: "eth_simulateV1",
    params: [
      {
        validation: true,
        blockStateCalls: calls.map((call) => ({ calls: [call] })),
      },
      "latest",
    ],
  });
}

function summarizeSimulation(simulation) {
  const blocks = simulation || [];
  const calls = blocks.flatMap((block) => block?.calls || []);
  const totalGasUsed = calls.reduce((sum, call) => sum + BigInt(call.gasUsed || "0x0"), 0n);
  const blockGasUsed = blocks.reduce((sum, block) => sum + BigInt(block?.gasUsed || "0x0"), 0n);
  const effectiveGasUsed = totalGasUsed > 0n ? totalGasUsed : blockGasUsed;
  const baseFee = BigInt(blocks.at(-1)?.baseFeePerGas || blocks[0]?.baseFeePerGas || "0x0");
  const failedCalls = calls
    .map((call, index) => ({ call, index }))
    .filter(({ call }) => call.status && call.status !== "0x1");
  const capWei = effectiveGasUsed * MAX_FEE_PER_GAS;
  const baseWei = effectiveGasUsed * (baseFee + MAX_PRIORITY_FEE_PER_GAS);
  return {
    success: failedCalls.length === 0,
    blockCount: blocks.length,
    firstBlockNumber: blocks[0]?.number,
    lastBlockNumber: blocks.at(-1)?.number,
    lastBlockHash: blocks.at(-1)?.hash,
    simulatedBaseFeePerGasWei: baseFee.toString(),
    totalGasUsed: effectiveGasUsed.toString(),
    callCount: calls.length,
    failedCalls: failedCalls.map(({ call, index }) => ({
      index,
      label: report.calls[index]?.label,
      status: call.status,
      error: call.error || null,
      gasUsed: call.gasUsed || null,
    })),
    costAtGasCapWei: capWei.toString(),
    costAtGasCapEth: formatEth(capWei),
    costAtGasCapUsd: formatUsd(capWei),
    costAtSimulatedBaseFeeWei: baseWei.toString(),
    costAtSimulatedBaseFeeEth: formatEth(baseWei),
    costAtSimulatedBaseFeeUsd: formatUsd(baseWei),
  };
}

function formatEth(wei) {
  return (Number(wei) / 1e18).toFixed(8);
}

function formatUsd(wei) {
  return ((Number(wei) / 1e18) * ETH_USD).toFixed(2);
}

function toHex(value) {
  return `0x${value.toString(16)}`;
}

function loadPrivateKey() {
  const raw =
    process.env.DEPLOYER_PRIVATE_KEY ||
    process.env.PRIVATE_KEY ||
    process.env.BASE_DEPLOYER_PRIVATE_KEY;
  if (!raw) throw new Error("DEPLOYER_PRIVATE_KEY is not set in this process.");
  const key = raw.startsWith("0x") ? raw : `0x${raw}`;
  if (!/^0x[0-9a-fA-F]{64}$/.test(key)) {
    throw new Error("DEPLOYER_PRIVATE_KEY is present but not a 32-byte hex private key.");
  }
  return key;
}

function envBigInt(name, fallback) {
  const value = process.env[name];
  if (value === undefined || value === "") return fallback;
  return BigInt(value);
}

function envAddress(name, fallback) {
  const value = process.env[name] || fallback;
  if (!/^0x[0-9a-fA-F]{40}$/.test(value)) throw new Error(`${name} is not a valid address: ${value}`);
  return value;
}

function saveReport() {
  fs.mkdirSync(path.dirname(REPORT_PATH), { recursive: true });
  fs.writeFileSync(REPORT_PATH, `${JSON.stringify(report, null, 2)}\n`);
}

main().catch((error) => {
  report.failedAt = new Date().toISOString();
  report.error = error?.stack || String(error);
  saveReport();
  console.error(error);
  process.exitCode = 1;
});
