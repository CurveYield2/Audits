import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { compileContracts } from '../lib/compileSolc.mjs';
import { workspaceRoot } from '../lib/paths.mjs';

const dexRoot = 'contracts';

function read(path) {
  return fs.readFileSync(path, 'utf8');
}

function listSolidityFiles(root) {
  const files = [];
  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    const fullPath = path.join(root, entry.name);
    if (entry.isDirectory()) {
      files.push(...listSolidityFiles(fullPath));
    } else if (entry.isFile() && entry.name.endsWith('.sol')) {
      files.push(fullPath.replaceAll('\\', '/'));
    }
  }
  return files;
}

describe('CurveYield DEX source cleanup', () => {
  it('does not keep the stale undefined creator splitter constructor call', () => {
    const source = read(`${dexRoot}/CurveYieldPoolFactoryWrapper.sol`);

    expect(source).not.toContain('CreatorFeeSplitter(creatorFeeSplitter).syncCreatorSwapFee();');
  });

  it('synchronizes Balancer creator fee percentage during pool registration', () => {
    const source = read(`${dexRoot}/CurveYieldPoolFactoryWrapper.sol`);

    expect(source).toContain('CreatorFeeSplitter(splitter).syncCreatorSwapFee();');
  });

  it('rejects ReClamm policies that require BPT-producing settlement paths', () => {
    const source = read(`${dexRoot}/CurveYieldPoolFactoryWrapper.sol`);

    expect(source).toContain('_validatePolicyInput(policy, PoolFeePolicyRegistry.PoolType.ReClamm)');
    expect(source).toContain('ReClammBptSettlementUnsupported');
    expect(source).toContain('policy.creatorPayoutToken == policy.expectedPool');
    expect(source).toContain('creatorPermanentLiquidityBps != 0');
  });

  it('keeps old balYIELD and polYIELD namespaces out of the CurveYield DEX source tree', () => {
    for (const file of listSolidityFiles(dexRoot)) {
      const source = read(file);
      expect(source, file).not.toMatch(/BalYield|balYield|balYIELD|balyield|polYIELD|polUSD|polGOV|src\/balyield|src\/polyield/);
    }
  });

  it('compiles the CurveYield DEX support contracts without Forge', () => {
    const { compiled } = compileContracts(
      [
        `${dexRoot}/PoolFeePolicyRegistry.sol`,
        `${dexRoot}/AdminFeeSplitter.sol`,
        `${dexRoot}/CreatorFeeSplitter.sol`,
        `${dexRoot}/FeeSettlementRouter.sol`,
        `${dexRoot}/FeeSettlementKeeper.sol`,
        `${dexRoot}/PermanentLiquidityVaultV2.sol`,
        `${dexRoot}/RouteRegistry.sol`,
        `${dexRoot}/adapters/BalancerV3SwapAdapter.sol`,
        `${dexRoot}/CurveYieldPoolFactoryWrapper.sol`,
      ],
      [
        'PoolFeePolicyRegistry',
        'AdminFeeSplitter',
        'CreatorFeeSplitter',
        'FeeSettlementRouter',
        'FeeSettlementKeeper',
        'PermanentLiquidityVaultV2',
        'RouteRegistry',
        'BalancerV3SwapAdapter',
        'CurveYieldPoolFactoryWrapper',
      ]
    );

    expect(compiled.PoolFeePolicyRegistry).toBeTruthy();
    expect(compiled.AdminFeeSplitter).toBeTruthy();
    expect(compiled.CreatorFeeSplitter).toBeTruthy();
    expect(compiled.FeeSettlementRouter).toBeTruthy();
    expect(compiled.FeeSettlementKeeper).toBeTruthy();
    expect(compiled.PermanentLiquidityVaultV2).toBeTruthy();
    expect(compiled.RouteRegistry).toBeTruthy();
    expect(compiled.BalancerV3SwapAdapter).toBeTruthy();
    expect(compiled.CurveYieldPoolFactoryWrapper).toBeTruthy();
  }, 180_000);

  it('exposes current CurveYield token and DAO address keys in ops constants', () => {
    const source = read(path.join(workspaceRoot, 'scripts/ops/lib/constants.mjs'));

    expect(source).toContain('crvYield:');
    expect(source).toContain('cyUsd:');
    expect(source).toContain('cyGov:');
    expect(source).toContain('crvYieldDao:');
    expect(source).toContain('upstreamBalancerRouter:');
    expect(source).toContain('upstreamBalancerVault:');
    expect(source).not.toContain('polYield:');
    expect(source).not.toContain('polGov:');
    expect(source).not.toContain('polUsd:');
    expect(source).not.toContain('polYieldDao:');
  });
});
