import { describe, expect, it } from 'vitest';

const WAD = 10n ** 18n;
const MAX_UINT128 = (1n << 128n) - 1n;

function ceilDiv(numerator, denominator) {
  if (denominator === 0n) throw new Error('division by zero');
  return numerator === 0n ? 0n : ((numerator - 1n) / denominator) + 1n;
}

function mulDivDown(a, b, denominator) {
  if (denominator === 0n) throw new Error('division by zero');
  return (a * b) / denominator;
}

function mulDivUp(a, b, denominator) {
  return ceilDiv(a * b, denominator);
}

function weightedTurnover(amountGivenScaled18, selectedWeight, selectedBalanceScaled18) {
  return mulDivUp(amountGivenScaled18, selectedWeight, selectedBalanceScaled18);
}

function stableTurnover(amountGivenScaled18, balancesScaled18) {
  const totalBalance = balancesScaled18.reduce((sum, balance) => sum + balance, 0n);
  return mulDivUp(amountGivenScaled18, WAD, totalBalance);
}

function selectedWeightedTurnover({
  amountGivenScaled18,
  balancesScaled18,
  weights,
  tokenInIndex,
  tokenOutIndex,
  exactIn,
}) {
  const selectedIndex = exactIn ? tokenInIndex : tokenOutIndex;
  return weightedTurnover(
    amountGivenScaled18,
    weights[selectedIndex],
    balancesScaled18[selectedIndex],
  );
}

function sensitivity(reactiveness) {
  if (reactiveness < 1n || reactiveness > 100n) throw new Error('invalid reactiveness');
  return WAD + mulDivDown(19n * WAD, reactiveness - 1n, 99n);
}

function weightedBaseThreshold(halfLifeHours) {
  if (halfLifeHours < 1n || halfLifeHours > 48n) throw new Error('invalid half-life');
  if (halfLifeHours <= 12n) return halfLifeHours * (WAD / 10n);
  if (halfLifeHours <= 24n) {
    return (120n * WAD) / 100n + mulDivDown(halfLifeHours - 12n, (80n * WAD) / 100n, 12n);
  }
  return mulDivDown(2n * WAD, halfLifeHours, 24n);
}

function effectiveThreshold(kind, reactiveness, halfLifeHours) {
  const base = weightedBaseThreshold(halfLifeHours);
  const kindBase = kind === 'WEIGHTED' ? base : 4n * base;
  return mulDivDown(kindBase, WAD, sensitivity(reactiveness));
}

function smoothstepSurcharge(activity, thresholdValue, maximumSurcharge) {
  if (thresholdValue === 0n) throw new Error('zero threshold');
  const t = [mulDivUp(activity, WAD, thresholdValue), WAD].reduce((a, b) => (a < b ? a : b));
  const t2 = mulDivUp(t, t, WAD);
  const t3 = mulDivDown(t2, t, WAD);
  const factor = [3n * t2 - 2n * t3, WAD].reduce((a, b) => (a < b ? a : b));
  const surcharge = mulDivUp(maximumSurcharge, factor, WAD);
  return surcharge < maximumSurcharge ? surcharge : maximumSurcharge;
}

function sqrtFloor(value) {
  if (value < 0n) throw new Error('negative square root');
  if (value < 2n) return value;

  let x = 1n << BigInt((value.toString(2).length + 1) >> 1);
  let next = (x + value / x) >> 1n;
  while (next < x) {
    x = next;
    next = (x + value / x) >> 1n;
  }
  return x;
}

function halfPowerDown(exponentWad) {
  const whole = exponentWad / WAD;
  if (whole >= 256n) return 0n;

  let result = WAD;
  let remainder = exponentWad % WAD;
  let fractionalFactor = WAD / 2n;

  for (let bit = 0; bit < 80 && remainder !== 0n; bit += 1) {
    fractionalFactor = sqrtFloor(fractionalFactor * WAD);
    remainder *= 2n;
    if (remainder >= WAD) {
      result = mulDivDown(result, fractionalFactor, WAD);
      remainder -= WAD;
    }
  }

  return result / (1n << whole);
}

function decayActivity(previousActivity, elapsedSeconds, halfLifeSeconds) {
  if (halfLifeSeconds === 0n) throw new Error('zero half-life');
  const exponent = mulDivDown(elapsedSeconds, WAD, halfLifeSeconds);
  const whole = exponent / WAD;
  if (previousActivity === 0n) return 0n;
  if (whole >= 128n) return 0n;

  const afterWholeHalfLives = ceilDiv(previousActivity, 1n << whole);
  const fractionalExponent = exponent % WAD;
  if (fractionalExponent === 0n) return afterWholeHalfLives;
  return mulDivUp(afterWholeHalfLives, halfPowerDown(fractionalExponent), WAD);
}

function nextActivity(previousActivity, turnover, elapsedSeconds, halfLifeSeconds) {
  const decayed = decayActivity(previousActivity, elapsedSeconds, halfLifeSeconds);
  const sum = decayed + turnover;
  return sum < MAX_UINT128 ? sum : MAX_UINT128;
}

function seededRandom(seed) {
  let state = BigInt(seed) & ((1n << 64n) - 1n);
  return () => {
    state ^= state << 13n;
    state ^= state >> 7n;
    state ^= state << 17n;
    state &= (1n << 64n) - 1n;
    return state;
  };
}

describe('CurveYield volume-adaptive fee reference model', () => {
  it('counts one selected side for weighted exact-in and exact-out swaps', () => {
    const balancesScaled18 = [1_000n * WAD, 500n * WAD];
    const weights = [(60n * WAD) / 100n, (40n * WAD) / 100n];

    expect(
      selectedWeightedTurnover({
        amountGivenScaled18: 100n * WAD,
        balancesScaled18,
        weights,
        tokenInIndex: 0,
        tokenOutIndex: 1,
        exactIn: true,
      }),
    ).toBe((6n * WAD) / 100n);

    expect(
      selectedWeightedTurnover({
        amountGivenScaled18: 50n * WAD,
        balancesScaled18,
        weights,
        tokenInIndex: 0,
        tokenOutIndex: 1,
        exactIn: false,
      }),
    ).toBe((4n * WAD) / 100n);
  });

  it('uses total live rate-adjusted balances for stable turnover', () => {
    expect(stableTurnover(100n * WAD, [1_000n * WAD, 500n * WAD, 1_000n * WAD])).toBe(
      (4n * WAD) / 100n,
    );
  });

  it('matches every approved sensitivity and threshold endpoint', () => {
    expect(sensitivity(1n)).toBe(WAD);
    expect(sensitivity(100n)).toBe(20n * WAD);
    expect(weightedBaseThreshold(6n)).toBe((60n * WAD) / 100n);
    expect(weightedBaseThreshold(12n)).toBe((120n * WAD) / 100n);
    expect(weightedBaseThreshold(24n)).toBe(2n * WAD);
    expect(weightedBaseThreshold(48n)).toBe(4n * WAD);

    for (const reactiveness of [1n, 20n, 100n]) {
      for (const hours of [1n, 8n, 12n, 24n, 48n]) {
        const weighted = effectiveThreshold('WEIGHTED', reactiveness, hours);
        const stable = effectiveThreshold('STABLE', reactiveness, hours);
        expect(stable).toBe(
          mulDivDown(4n * weightedBaseThreshold(hours), WAD, sensitivity(reactiveness)),
        );
        expect(stable).toBeGreaterThanOrEqual(4n * weighted);
        expect(stable - 4n * weighted).toBeLessThanOrEqual(3n);
      }
    }
  });

  it('keeps surcharge at zero while activity accounting continues', () => {
    const activity = nextActivity(2n * WAD, WAD / 5n, 1_800n, 3_600n);
    expect(activity).toBeGreaterThan(0n);
    expect(smoothstepSurcharge(activity, WAD, 0n)).toBe(0n);
  });

  it('has exact smoothstep endpoints and is monotonic', () => {
    const thresholdValue = 2n * WAD;
    const maximumSurcharge = (5n * WAD) / 100n;
    expect(smoothstepSurcharge(0n, thresholdValue, maximumSurcharge)).toBe(0n);
    expect(smoothstepSurcharge(thresholdValue, thresholdValue, maximumSurcharge)).toBe(
      maximumSurcharge,
    );
    expect(smoothstepSurcharge(10n * thresholdValue, thresholdValue, maximumSurcharge)).toBe(
      maximumSurcharge,
    );

    let previous = 0n;
    for (let i = 0n; i <= 1_000n; i += 1n) {
      const current = smoothstepSurcharge(
        mulDivDown(thresholdValue, i, 1_000n),
        thresholdValue,
        maximumSurcharge,
      );
      expect(current).toBeGreaterThanOrEqual(previous);
      previous = current;
    }
  });

  it('decays during inactivity and while new volume continues', () => {
    expect(decayActivity(WAD, 3_600n, 3_600n)).toBe(WAD / 2n);
    expect(decayActivity(WAD, 36_000n, 3_600n)).toBe(ceilDiv(WAD, 1_024n));
    expect(decayActivity(WAD, 128n * 3_600n, 3_600n)).toBe(0n);

    const first = nextActivity(WAD, WAD / 10n, 3_600n, 3_600n);
    const second = nextActivity(first, WAD / 10n, 3_600n, 3_600n);
    expect(first).toBe((6n * WAD) / 10n);
    expect(second).toBe((4n * WAD) / 10n);
  });

  it('saturates at uint128 without reverting', () => {
    expect(nextActivity(MAX_UINT128, MAX_UINT128, 0n, 3_600n)).toBe(MAX_UINT128);
    expect(nextActivity(MAX_UINT128, 1n, 1n, 3_600n)).toBeLessThanOrEqual(MAX_UINT128);
  });

  it('passes deterministic 2-to-8-token boundary and rounding cases', () => {
    const random = seededRandom(0x43555256455949454cn);

    for (let vector = 0; vector < 5_000; vector += 1) {
      const tokenCount = Number((random() % 7n) + 2n);
      const balances = Array.from(
        { length: tokenCount },
        () => ((random() % 1_000_000n) + 1n) * 10n ** 12n,
      );
      const rawWeights = Array.from({ length: tokenCount }, () => (random() % 10_000n) + 1n);
      const totalRawWeight = rawWeights.reduce((sum, weight) => sum + weight, 0n);
      const weights = rawWeights.map((weight) => mulDivDown(weight, WAD, totalRawWeight));
      weights[weights.length - 1] += WAD - weights.reduce((sum, weight) => sum + weight, 0n);

      const tokenInIndex = Number(random() % BigInt(tokenCount));
      let tokenOutIndex = Number(random() % BigInt(tokenCount - 1));
      if (tokenOutIndex >= tokenInIndex) tokenOutIndex += 1;
      const exactIn = (random() & 1n) === 1n;
      const selectedIndex = exactIn ? tokenInIndex : tokenOutIndex;
      const amount = (random() % balances[selectedIndex]) + 1n;

      const weighted = selectedWeightedTurnover({
        amountGivenScaled18: amount,
        balancesScaled18: balances,
        weights,
        tokenInIndex,
        tokenOutIndex,
        exactIn,
      });
      const stable = stableTurnover(amount, balances);
      expect(weighted).toBeGreaterThan(0n);
      expect(stable).toBeGreaterThan(0n);

      const reactiveness = (random() % 100n) + 1n;
      const halfLifeHours = (random() % 48n) + 1n;
      const thresholdValue = effectiveThreshold(
        vector % 2 === 0 ? 'WEIGHTED' : 'STABLE',
        reactiveness,
        halfLifeHours,
      );
      const maximumSurcharge = vector % 2 === 0 ? (5n * WAD) / 100n : (2n * WAD) / 100n;
      expect(smoothstepSurcharge(thresholdValue, thresholdValue, maximumSurcharge)).toBe(
        maximumSurcharge,
      );
    }
  });
});
