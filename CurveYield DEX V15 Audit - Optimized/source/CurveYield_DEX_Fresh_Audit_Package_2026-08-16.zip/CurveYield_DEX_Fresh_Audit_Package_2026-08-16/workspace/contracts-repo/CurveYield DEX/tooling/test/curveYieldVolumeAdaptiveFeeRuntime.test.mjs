import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  createPublicClient,
  createWalletClient,
  decodeFunctionResult,
  encodeFunctionData,
  getContract,
  http,
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { compileContracts } from '../lib/compileSolc.mjs';

const WAD = 10n ** 18n;
const MAX_UINT128 = (1n << 128n) - 1n;
const rpcUrl = 'http://127.0.0.1:8634';
const chain = {
  id: 31337,
  name: 'anvil',
  nativeCurrency: { name: 'ETH', symbol: 'ETH', decimals: 18 },
  rpcUrls: {},
};
const owner = privateKeyToAccount(
  '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80',
);

function ceilDiv(numerator, denominator) {
  if (denominator === 0n) throw new Error('division by zero');
  return numerator === 0n ? 0n : ((numerator - 1n) / denominator) + 1n;
}

function mulDivDown(a, b, denominator) {
  return (a * b) / denominator;
}

function mulDivUp(a, b, denominator) {
  return ceilDiv(a * b, denominator);
}

function sqrtFloor(value) {
  if (value < 2n) return value;
  let x = 1n << BigInt((value.toString(2).length + 1) >> 1);
  let next = (x + value / x) >> 1n;
  while (next < x) {
    x = next;
    next = (x + value / x) >> 1n;
  }
  return x;
}

function halfPowerDown(exponentWad) {
  const whole = exponentWad / WAD;
  if (whole >= 256n) return 0n;
  let result = WAD;
  let remainder = exponentWad % WAD;
  let factor = WAD / 2n;
  for (let bit = 0; bit < 80 && remainder !== 0n; bit += 1) {
    factor = sqrtFloor(factor * WAD);
    remainder *= 2n;
    if (remainder >= WAD) {
      result = mulDivDown(result, factor, WAD);
      remainder -= WAD;
    }
  }
  return result / (1n << whole);
}

function modelDecay(previousActivity, elapsedSeconds, halfLifeSeconds) {
  const exponent = mulDivDown(elapsedSeconds, WAD, halfLifeSeconds);
  const whole = exponent / WAD;
  if (previousActivity === 0n) return 0n;
  if (whole >= 128n) return 1n;

  const afterWholeHalfLives = ceilDiv(previousActivity, 1n << whole);
  const fractionalExponent = exponent % WAD;
  if (fractionalExponent === 0n) return afterWholeHalfLives;
  return mulDivUp(afterWholeHalfLives, halfPowerDown(fractionalExponent), WAD);
}

function modelThreshold(kind, reactiveness, halfLifeHours) {
  const sensitivity = WAD + mulDivDown(19n * WAD, reactiveness - 1n, 99n);
  let weightedBase;
  if (halfLifeHours <= 12n) {
    weightedBase = halfLifeHours * (WAD / 10n);
  } else if (halfLifeHours <= 24n) {
    weightedBase =
      (120n * WAD) / 100n + mulDivDown(halfLifeHours - 12n, (80n * WAD) / 100n, 12n);
  } else {
    weightedBase = mulDivDown(2n * WAD, halfLifeHours, 24n);
  }
  const poolKindBase = kind === 1n ? weightedBase : 4n * weightedBase;
  return mulDivDown(poolKindBase, WAD, sensitivity);
}

function modelSurcharge(activity, thresholdValue, maximumSurcharge) {
  const t = [mulDivUp(activity, WAD, thresholdValue), WAD].reduce((a, b) => (a < b ? a : b));
  const t2 = mulDivUp(t, t, WAD);
  const t3 = mulDivDown(t2, t, WAD);
  const factor = [3n * t2 - 2n * t3, WAD].reduce((a, b) => (a < b ? a : b));
  const result = mulDivUp(maximumSurcharge, factor, WAD);
  return result < maximumSurcharge ? result : maximumSurcharge;
}

function nextRandom(state) {
  return (state * 6_364_136_223_846_793_005n + 1_442_695_040_888_963_407n) &
    ((1n << 64n) - 1n);
}

async function waitForAnvil() {
  const startedAt = Date.now();
  while (Date.now() - startedAt < 15_000) {
    try {
      const response = await fetch(rpcUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_blockNumber', params: [] }),
      });
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  throw new Error('Timed out waiting for bounded local Anvil');
}

async function deploy(walletClient, publicClient, artifact) {
  const hash = await walletClient.deployContract({
    abi: artifact.abi,
    bytecode: artifact.bytecode,
    account: walletClient.account,
  });
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  expect(receipt.status).toBe('success');
  return getContract({
    address: receipt.contractAddress,
    abi: artifact.abi,
    client: { public: publicClient },
  });
}

async function batchEthCall(address, abi, calls, batchSize = 200) {
  const decoded = [];
  for (let offset = 0; offset < calls.length; offset += batchSize) {
    const chunk = calls.slice(offset, offset + batchSize);
    const payload = chunk.map((call, index) => ({
      jsonrpc: '2.0',
      id: offset + index + 1,
      method: 'eth_call',
      params: [
        {
          to: address,
          data: encodeFunctionData({
            abi,
            functionName: call.functionName,
            args: call.args,
          }),
        },
        'latest',
      ],
    }));
    const response = await fetch(rpcUrl, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!response.ok) throw new Error(`JSON-RPC batch failed with HTTP ${response.status}`);
    const body = await response.json();
    const ordered = new Map(body.map((item) => [item.id, item]));
    for (let index = 0; index < chunk.length; index += 1) {
      const item = ordered.get(offset + index + 1);
      if (item?.error) throw new Error(JSON.stringify(item.error));
      decoded.push(
        decodeFunctionResult({
          abi,
          functionName: chunk[index].functionName,
          data: item.result,
        }),
      );
    }
  }
  return decoded;
}

describe('CurveYield VolumeAdaptiveFee Solidity runtime', () => {
  let anvil;
  let shutdownTimer;
  let publicClient;
  let walletClient;
  let harness;

  beforeAll(async () => {
    const { compiled } = compileContracts(
      [
        'contracts/hooks/VolumeAdaptiveFee.sol',
        'tooling/test/contracts/CurveYieldHookMathHarness.sol',
      ],
      ['CurveYieldHookMathHarness'],
    );

    const anvilPath = process.env.ANVIL_PATH || 'C:\\Users\\user\\.foundry\\bin\\anvil.exe';
    if (!fs.existsSync(anvilPath)) throw new Error(`Anvil not found at ${anvilPath}`);
    anvil = spawn(anvilPath, ['--port', '8634', '--silent'], {
      cwd: process.cwd(),
      stdio: 'ignore',
      windowsHide: true,
    });
    shutdownTimer = setTimeout(() => {
      if (anvil && !anvil.killed) anvil.kill();
    }, 5 * 60_000);
    shutdownTimer.unref();
    await waitForAnvil();

    publicClient = createPublicClient({ chain, transport: http(rpcUrl) });
    walletClient = createWalletClient({ account: owner, chain, transport: http(rpcUrl) });
    harness = await deploy(walletClient, publicClient, compiled.CurveYieldHookMathHarness);
  }, 180_000);

  afterAll(() => {
    if (shutdownTimer) clearTimeout(shutdownTimer);
    if (anvil && !anvil.killed) anvil.kill();
  });

  it('matches all deterministic endpoint vectors and conservative rounding rules', async () => {
    expect(await harness.read.weightedTurnover([100n * WAD, (60n * WAD) / 100n, 1_000n * WAD]))
      .toBe((6n * WAD) / 100n);
    expect(await harness.read.stableTurnover([100n * WAD, [1_000n * WAD, 500n * WAD, 1_000n * WAD]]))
      .toBe((4n * WAD) / 100n);
    expect(await harness.read.threshold([1, 1, 24])).toBe(2n * WAD);
    expect(await harness.read.threshold([1, 100, 24])).toBe(WAD / 10n);
    expect(await harness.read.threshold([2, 100, 24])).toBe((4n * WAD) / 10n);
    expect(await harness.read.volumeSurcharge([0n, WAD, (5n * WAD) / 100n])).toBe(0n);
    expect(await harness.read.volumeSurcharge([WAD, WAD, (5n * WAD) / 100n]))
      .toBe((5n * WAD) / 100n);
  });

  it('rejects invalid parameters and zero denominators', async () => {
    await expect(harness.read.weightedTurnover([WAD, WAD, 0n])).rejects.toThrow();
    await expect(harness.read.stableTurnover([WAD, [0n, 0n]])).rejects.toThrow();
    await expect(harness.read.threshold([0, 20, 8])).rejects.toThrow();
    await expect(harness.read.threshold([1, 0, 8])).rejects.toThrow();
    await expect(harness.read.threshold([1, 101, 8])).rejects.toThrow();
    await expect(harness.read.threshold([1, 20, 0])).rejects.toThrow();
    await expect(harness.read.threshold([1, 20, 49])).rejects.toThrow();
    await expect(harness.read.volumeSurcharge([WAD, 0n, WAD])).rejects.toThrow();
    await expect(harness.read.validateConfig([1, (5n * WAD) / 100n + 1n, 20, 8]))
      .rejects.toThrow();
    await expect(harness.read.validateConfig([2, (2n * WAD) / 100n + 1n, 20, 8]))
      .rejects.toThrow();
    await expect(harness.read.validateConfig([3, (2n * WAD) / 100n + 1n, 20, 8]))
      .rejects.toThrow();
  });

  it('saturates activity at uint128 and handles long inactivity without reverting', async () => {
    expect(await harness.read.nextActivity([MAX_UINT128, MAX_UINT128, 0n, 3_600n]))
      .toBe(MAX_UINT128);
    expect(await harness.read.decayActivity([MAX_UINT128, 200n * 3_600n, 3_600n]))
      .toBeLessThanOrEqual(1n);
    expect(await harness.read.nextActivity([MAX_UINT128, 1n, 200n * 3_600n, 3_600n]))
      .toBe(2n);
  });

  it('cross-checks 10,000 seeded 2-to-8-token vectors against the independent model', async () => {
    const calls = [];
    const expected = [];
    let state = 0x4355525645594945n;

    for (let vector = 0; vector < 10_000; vector += 1) {
      state = nextRandom(state);
      const tokenCount = Number((state % 7n) + 2n);
      const balances = [];
      for (let token = 0; token < tokenCount; token += 1) {
        state = nextRandom(state);
        balances.push(((state % 1_000_000n) + 1n) * 10n ** 12n);
      }
      state = nextRandom(state);
      const selectedBalance = balances[Number(state % BigInt(tokenCount))];
      state = nextRandom(state);
      const selectedWeight = ((state % 99_000n) + 1_000n) * 10n ** 13n;
      state = nextRandom(state);
      const amount = (state % selectedBalance) + 1n;
      state = nextRandom(state);
      const previousActivity = vector % 997 === 0
        ? MAX_UINT128
        : state % (10n ** 30n);
      state = nextRandom(state);
      const elapsedSeconds = state % (60n * 48n * 3_600n);
      state = nextRandom(state);
      const halfLifeHours = (state % 48n) + 1n;
      const halfLifeSeconds = halfLifeHours * 3_600n;
      state = nextRandom(state);
      const reactiveness = (state % 100n) + 1n;
      const kind = vector % 3 === 0 ? 1n : vector % 3 === 1 ? 2n : 3n;
      const thresholdValue = modelThreshold(kind, reactiveness, halfLifeHours);
      state = nextRandom(state);
      const activity = state % (2n * thresholdValue + 1n);
      const maximumSurcharge = kind === 1n ? (5n * WAD) / 100n : (2n * WAD) / 100n;
      const turnover = kind === 1n
        ? mulDivUp(amount, selectedWeight, selectedBalance)
        : mulDivUp(amount, WAD, balances.reduce((sum, balance) => sum + balance, 0n));

      calls.push({
        functionName: 'evaluateVector',
        args: [
          kind,
          amount,
          selectedWeight,
          selectedBalance,
          balances,
          previousActivity,
          turnover,
          elapsedSeconds,
          halfLifeSeconds,
          reactiveness,
          halfLifeHours,
          activity,
          maximumSurcharge,
        ],
      });
      expected.push({
        weighted: mulDivUp(amount, selectedWeight, selectedBalance),
        stable: mulDivUp(amount, WAD, balances.reduce((sum, balance) => sum + balance, 0n)),
        decay: modelDecay(previousActivity, elapsedSeconds, halfLifeSeconds),
        threshold: thresholdValue,
        surcharge: modelSurcharge(activity, thresholdValue, maximumSurcharge),
        previousActivity,
        elapsedSeconds,
      });
    }

    const results = await batchEthCall(harness.address, harness.abi, calls);
    expect(results).toHaveLength(10_000);

    for (let index = 0; index < results.length; index += 1) {
      const [weighted, stable, decay, thresholdValue, surcharge] = results[index];
      expect(weighted, `weighted vector ${index}`).toBe(expected[index].weighted);
      expect(stable, `stable vector ${index}`).toBe(expected[index].stable);
      expect(thresholdValue, `threshold vector ${index}`).toBe(expected[index].threshold);
      expect(surcharge, `surcharge vector ${index}`).toBe(expected[index].surcharge);
      expect(decay + 1n, `decay lower bound vector ${index}`).toBeGreaterThanOrEqual(
        expected[index].decay,
      );
      expect(decay, `decay monotonic vector ${index}`).toBeLessThanOrEqual(
        expected[index].previousActivity,
      );
    }
  }, 180_000);
});
