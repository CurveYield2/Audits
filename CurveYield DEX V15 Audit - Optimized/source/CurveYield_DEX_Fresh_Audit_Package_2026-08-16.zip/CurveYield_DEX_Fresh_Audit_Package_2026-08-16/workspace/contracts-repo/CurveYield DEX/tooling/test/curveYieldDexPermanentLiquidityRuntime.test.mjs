import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  createPublicClient,
  createTestClient,
  createWalletClient,
  encodeAbiParameters,
  getContract,
  http,
  keccak256,
  parseEther,
} from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { compileContracts } from '../lib/compileSolc.mjs';

const rpcUrl = 'http://127.0.0.1:8629';
const chain = {
  id: 31337,
  name: 'anvil',
  nativeCurrency: { name: 'ETH', symbol: 'ETH', decimals: 18 },
  rpcUrls: {},
};
const owner = privateKeyToAccount('0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80');
const alice = privateKeyToAccount('0x1111111111111111111111111111111111111111111111111111111111111111');
const bob = privateKeyToAccount('0x2222222222222222222222222222222222222222222222222222222222222222');

async function waitForAnvil() {
  const startedAt = Date.now();
  while (Date.now() - startedAt < 15_000) {
    try {
      const response = await fetch(rpcUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_blockNumber', params: [] }),
      });
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  throw new Error('Timed out waiting for bounded local Anvil');
}

async function deploy(walletClient, publicClient, artifact, args = []) {
  const hash = await walletClient.deployContract({
    abi: artifact.abi,
    bytecode: artifact.bytecode,
    args,
    account: walletClient.account,
  });
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  expect(receipt.status).toBe('success');
  return getContract({
    address: receipt.contractAddress,
    abi: artifact.abi,
    client: { public: publicClient },
  });
}

async function write(publicClient, walletClient, contract, functionName, args = []) {
  const hash = await walletClient.writeContract({
    address: contract.address,
    abi: contract.abi,
    functionName,
    args,
    account: walletClient.account,
  });
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  expect(receipt.status).toBe('success');
}

async function expectRevert(publicClient, walletClient, contract, functionName, args = []) {
  await expect(
    publicClient.simulateContract({
      address: contract.address,
      abi: contract.abi,
      functionName,
      args,
      account: walletClient.account,
    }),
  ).rejects.toThrow();
}

function tokenSetHash(tokens) {
  return keccak256(encodeAbiParameters([{ type: 'address[]' }], [tokens]));
}

describe('CurveYield permanent-liquidity typed migration', () => {
  let anvil;
  let shutdownTimer;
  let publicClient;
  let testClient;
  let ownerClient;
  let aliceClient;
  let bobClient;
  let artifacts;
  let tokenA;
  let tokenB;
  let sourceBpt;
  let targetBpt;
  let unrelatedToken;
  let vault;
  let permit2;
  let migrationRouter;
  let routes;
  let permanentVault;
  let plan;

  beforeAll(async () => {
    ({ compiled: artifacts } = compileContracts(
      [
        'contracts/PermanentLiquidityVaultV2.sol',
        'contracts/RouteRegistry.sol',
        'tooling/test/contracts/CurveYieldDexAuditMocks.sol',
      ],
      [
        'PermanentLiquidityVaultV2',
        'RouteRegistry',
        'MockDexERC20',
        'MockDexVault',
        'MockDexPermit2',
        'MockDexMigrationRouter',
      ],
    ));

    const anvilPath = process.env.ANVIL_PATH || 'C:\\Users\\user\\.foundry\\bin\\anvil.exe';
    if (!fs.existsSync(anvilPath)) throw new Error(`Anvil not found at ${anvilPath}`);
    anvil = spawn(anvilPath, ['--port', '8629', '--silent'], {
      cwd: process.cwd(),
      stdio: 'ignore',
      windowsHide: true,
    });
    shutdownTimer = setTimeout(() => {
      if (anvil && !anvil.killed) anvil.kill();
    }, 5 * 60_000);
    shutdownTimer.unref();
    await waitForAnvil();

    publicClient = createPublicClient({ chain, transport: http(rpcUrl) });
    testClient = createTestClient({ chain, mode: 'anvil', transport: http(rpcUrl) });
    ownerClient = createWalletClient({ account: owner, chain, transport: http(rpcUrl) });
    aliceClient = createWalletClient({ account: alice, chain, transport: http(rpcUrl) });
    bobClient = createWalletClient({ account: bob, chain, transport: http(rpcUrl) });
    await testClient.setBalance({ address: alice.address, value: parseEther('10') });
    await testClient.setBalance({ address: bob.address, value: parseEther('10') });

    tokenA = await deploy(ownerClient, publicClient, artifacts.MockDexERC20, ['Token A', 'A']);
    tokenB = await deploy(ownerClient, publicClient, artifacts.MockDexERC20, ['Token B', 'B']);
    sourceBpt = await deploy(ownerClient, publicClient, artifacts.MockDexERC20, ['Source BPT', 'SBPT']);
    targetBpt = await deploy(ownerClient, publicClient, artifacts.MockDexERC20, ['Target BPT', 'TBPT']);
    unrelatedToken = await deploy(ownerClient, publicClient, artifacts.MockDexERC20, [
      'Unrelated',
      'OTHER',
    ]);
    vault = await deploy(ownerClient, publicClient, artifacts.MockDexVault);
    permit2 = await deploy(ownerClient, publicClient, artifacts.MockDexPermit2);
    migrationRouter = await deploy(ownerClient, publicClient, artifacts.MockDexMigrationRouter, [
      permit2.address,
      vault.address,
    ]);
    routes = await deploy(ownerClient, publicClient, artifacts.RouteRegistry, [owner.address]);
    permanentVault = await deploy(ownerClient, publicClient, artifacts.PermanentLiquidityVaultV2, [
      owner.address,
      migrationRouter.address,
      vault.address,
      routes.address,
      permit2.address,
    ]);

    const poolTokens = [tokenA.address, tokenB.address];
    await write(publicClient, ownerClient, vault, 'setPoolTokens', [sourceBpt.address, poolTokens]);
    await write(publicClient, ownerClient, vault, 'setPoolTokens', [targetBpt.address, poolTokens]);
    await write(publicClient, ownerClient, migrationRouter, 'setExitAmounts', [
      sourceBpt.address,
      [60n, 40n],
    ]);
    await write(publicClient, ownerClient, migrationRouter, 'setJoinBptOut', [targetBpt.address, 95n]);
    await write(publicClient, ownerClient, tokenA, 'mint', [migrationRouter.address, 60n]);
    await write(publicClient, ownerClient, tokenB, 'mint', [migrationRouter.address, 40n]);
    await write(publicClient, ownerClient, sourceBpt, 'mint', [permanentVault.address, 100n]);
    await write(publicClient, ownerClient, unrelatedToken, 'mint', [permanentVault.address, 500n]);
    await write(publicClient, ownerClient, permanentVault, 'setSettlementRouter', [owner.address]);
    await write(publicClient, ownerClient, permanentVault, 'approveMigrationTarget', [
      targetBpt.address,
      true,
    ]);
    await write(publicClient, ownerClient, permanentVault, 'recordPermanentLiquidity', [
      sourceBpt.address,
      sourceBpt.address,
      sourceBpt.address,
      100n,
      0,
      alice.address,
      alice.address,
    ]);

    const block = await publicClient.getBlock();
    plan = {
      lotId: 1n,
      targetPool: targetBpt.address,
      sourceBptAmount: 100n,
      sourceTokenSetHash: tokenSetHash(poolTokens),
      targetTokenSetHash: tokenSetHash(poolTokens),
      minSourceAmountsOut: [60n, 40n],
      swaps: [],
      minTargetBptOut: 90n,
      expiry: block.timestamp + 3_600n,
    };
  }, 180_000);

  afterAll(async () => {
    if (shutdownTimer) clearTimeout(shutdownTimer);
    if (anvil && !anvil.killed) anvil.kill();
  });

  it('requires the creator request and exact DAO-approved plan', async () => {
    await expectRevert(publicClient, ownerClient, permanentVault, 'migrateAdminLot', [plan, []]);
    await write(publicClient, aliceClient, permanentVault, 'requestCreatorMigration', [plan]);
    await expectRevert(publicClient, bobClient, permanentVault, 'executeCreatorMigration', [
      1n,
      plan,
      [],
    ]);
    await write(publicClient, ownerClient, permanentVault, 'approveCreatorMigration', [1n]);
    await expectRevert(publicClient, bobClient, permanentVault, 'executeCreatorMigration', [
      1n,
      { ...plan, minTargetBptOut: 91n },
      [],
    ]);
  });

  it('lets any account execute the exact approved atomic migration without touching unrelated balances', async () => {
    await write(publicClient, bobClient, permanentVault, 'executeCreatorMigration', [1n, plan, []]);

    expect(await sourceBpt.read.balanceOf([permanentVault.address])).toBe(0n);
    expect(await targetBpt.read.balanceOf([permanentVault.address])).toBe(95n);
    expect(await unrelatedToken.read.balanceOf([permanentVault.address])).toBe(500n);
    expect(await permanentVault.read.totalBpt([sourceBpt.address])).toBe(0n);
    expect(await permanentVault.read.totalBpt([targetBpt.address])).toBe(95n);
    expect(
      await permanentVault.read.recordedPermanentLiquidity([
        sourceBpt.address,
        sourceBpt.address,
        sourceBpt.address,
      ]),
    ).toBe(0n);
    expect(
      await permanentVault.read.recordedPermanentLiquidity([
        sourceBpt.address,
        targetBpt.address,
        targetBpt.address,
      ]),
    ).toBe(95n);

    const sourceLot = await permanentVault.read.liquidityLots([1n]);
    const targetLot = await permanentVault.read.liquidityLots([2n]);
    expect(sourceLot[3]).toBe(0n);
    expect(targetLot[1].toLowerCase()).toBe(targetBpt.address.toLowerCase());
    expect(targetLot[3]).toBe(95n);
  });
});
