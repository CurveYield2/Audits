// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract supports a CurveYield implementation derived from Balancer's smart contracts.
 * Balancer's gracious use of open-source GPL licensing allows CurveYield to use it for the good of all.
 */

library CurveYieldHookConstants {
    uint48 internal constant CREATOR_CONFIG_DELAY = 24 hours;
    uint64 internal constant IMMUTABLE_COMBINED_FEE_HARD_MAX = 0.20e18;
    uint16 internal constant MAX_OBSERVATIONS = 512;
    uint32 internal constant MIN_OBSERVATION_SPACING = 120 seconds;
    uint32 internal constant OBSERVATION_WARM_UP = 30 minutes;
    uint32 internal constant MIN_SETTLEMENT_WINDOW = 10 minutes;
    uint32 internal constant MAX_SETTLEMENT_WINDOW = 12 hours;
}

enum CurveYieldPoolKind {
    NONE,
    WEIGHTED,
    STABLE,
    STABLE_SURGE
}

struct VolumeFeeConfig {
    uint64 maxVolumeSurcharge;
    uint8 reactiveness;
    uint8 halfLifeHours;
    bool creatorChangesFrozen;
}

struct PendingVolumeFeeConfig {
    uint64 maxVolumeSurcharge;
    uint8 reactiveness;
    uint8 halfLifeHours;
    uint48 executableAt;
    bool exists;
}

struct ActivityState {
    uint128 activity;
    uint48 lastUpdated;
}

struct ObservationState {
    uint16 index;
    uint16 cardinality;
    uint48 initializedAt;
    uint48 lastTimestamp;
    uint48 lastSampleTimestamp;
    bool initialized;
    int128[8] cumulativeLogs;
    int128[8] instantLogs;
}

struct Observation {
    uint48 timestamp;
    int128[8] cumulativeLogs;
}

error FactoryNotApproved(address factory);
error InvalidPoolKind(CurveYieldPoolKind kind);
error PoolNotRegistered(address pool);
error PoolAlreadyRegistered(address pool);
error PoolFactoryMismatch(address pool, address factory);
error InvalidTokenCount(uint256 tokenCount);
error InvalidVolumeSurcharge(uint256 maxVolumeSurcharge);
error InvalidReactiveness(uint256 reactiveness);
error InvalidHalfLife(uint256 halfLifeHours);
error CreatorChangesAreFrozen(address pool);
error CallerIsNotCreatorController(address pool, address caller);
error PendingCreatorConfigNotFound(address pool);
error CreatorConfigDelayNotElapsed(address pool, uint48 executableAt);
error InvalidCombinedFeeCap(uint256 combinedFeeCap);
error InvalidSettlementWindow(uint256 settlementWindow);
error InvalidSettlementSlippage(uint256 settlementSlippageBps);
error SettlementRouterNotApproved(address settlementRouter);
error ProtectedSettlementIsPaused();
error ObservationNotInitialized(address pool);
error ObservationNotWarm(address pool);
error InsufficientObservationHistory(address pool, uint32 secondsAgo);
error InvalidObservationArrayLength(uint256 supplied, uint256 expected);
error OracleQuoteTotalSupplyIsZero(address pool);
error ProtectedBptMinimumTooLow(
    address pool,
    uint256 suppliedMinimum,
    uint256 requiredMinimum
);
