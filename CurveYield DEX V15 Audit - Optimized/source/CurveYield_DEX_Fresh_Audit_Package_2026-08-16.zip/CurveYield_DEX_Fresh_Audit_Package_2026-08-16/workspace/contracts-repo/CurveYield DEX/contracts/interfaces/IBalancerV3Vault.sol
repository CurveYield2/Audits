// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

import { HooksConfig } from "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";

interface IBalancerV3Vault {
    struct PoolRoleAccounts {
        address pauseManager;
        address swapFeeManager;
        address poolCreator;
    }

    function getPoolTokens(address pool) external view returns (address[] memory tokens);
    function getHooksConfig(address pool) external view returns (HooksConfig memory hooksConfig);
    function getPoolRoleAccounts(address pool) external view returns (PoolRoleAccounts memory roleAccounts);
}
