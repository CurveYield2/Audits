// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract is derived from Balancer's time-weighted oracle query architecture.
 * Balancer's gracious use of open-source GPL licensing allows CurveYield to use it for the good of all.
 */

import { IERC20 } from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import { Math } from "@openzeppelin/contracts/utils/math/Math.sol";

import { IBasePool } from "@balancer-labs/v3-interfaces/contracts/vault/IBasePool.sol";
import { IVault } from "@balancer-labs/v3-interfaces/contracts/vault/IVault.sol";
import {
    PoolData,
    PoolSwapParams,
    SwapKind
} from "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";
import { FixedPoint } from "@balancer-labs/v3-solidity-utils/contracts/math/FixedPoint.sol";
import { LogExpMath } from "@balancer-labs/v3-solidity-utils/contracts/math/LogExpMath.sol";
import {
    ScalingHelpers
} from "@balancer-labs/v3-solidity-utils/contracts/helpers/ScalingHelpers.sol";
import { BasePoolMath } from "@balancer-labs/v3-vault/contracts/BasePoolMath.sol";

import {
    InsufficientObservationHistory,
    InvalidObservationArrayLength,
    OracleQuoteTotalSupplyIsZero,
    Observation,
    ObservationNotInitialized,
    ObservationState
} from "./CurveYieldHookTypes.sol";

interface IReadOnlySwapPool {
    function onSwap(PoolSwapParams memory params) external view returns (uint256 amountCalculatedScaled18);
}

library ObservationQueryProcessor {
    using FixedPoint for uint256;
    using ScalingHelpers for uint256;
    using ScalingHelpers for uint256[];

    uint256 private constant _MAX_OBSERVATIONS = 512;

    error InvalidObservationWindow();
    error ObservationTimestampInFuture(uint48 supplied, uint48 currentTimestamp);
    error ObservationTimestampRegression(uint48 supplied, uint48 lastTimestamp);
    error InvalidObservationCardinality(uint16 cardinality);
    error InvalidExponentialResult(int256 result);
    error InvalidObservationSwapTokens(address tokenIn, address tokenOut);

    function getTimeWeightedBalancesPerBptAt(
        Observation[512] storage observations,
        ObservationState storage state,
        uint8 tokenCount,
        address pool,
        uint48 currentTimestamp,
        uint32 secondsAgo
    ) external view returns (uint256[] memory balancesPerBpt) {
        return _getTimeWeightedBalancesPerBptAt(
            observations,
            state,
            tokenCount,
            pool,
            currentTimestamp,
            secondsAgo
        );
    }

    function quoteOracleProtectedBptOutAt(
        Observation[512] storage observations,
        ObservationState storage state,
        uint8 tokenCount,
        address pool,
        IVault vault,
        uint48 currentTimestamp,
        uint32 secondsAgo,
        uint16 slippageBps,
        uint256[] memory exactAmountsInRaw
    ) external view returns (uint256 expectedBptOut, uint256 minBptOut) {
        PoolData memory data = vault.getPoolData(pool);
        uint256[] memory exactAmountsInScaled18 = exactAmountsInRaw
            .copyToScaled18ApplyRateRoundDownArray(
                data.decimalScalingFactors,
                data.tokenRates
            );
        return _quoteOracleProtectedBptOutScaled18At(
            observations,
            state,
            tokenCount,
            pool,
            vault,
            currentTimestamp,
            secondsAgo,
            slippageBps,
            exactAmountsInScaled18
        );
    }

    function quoteOracleProtectedBptOutScaled18At(
        Observation[512] storage observations,
        ObservationState storage state,
        uint8 tokenCount,
        address pool,
        IVault vault,
        uint48 currentTimestamp,
        uint32 secondsAgo,
        uint16 slippageBps,
        uint256[] memory exactAmountsInScaled18
    ) external view returns (uint256 expectedBptOut, uint256 minBptOut) {
        return _quoteOracleProtectedBptOutScaled18At(
            observations,
            state,
            tokenCount,
            pool,
            vault,
            currentTimestamp,
            secondsAgo,
            slippageBps,
            exactAmountsInScaled18
        );
    }

    function quoteOracleProtectedSwapOutAt(
        Observation[512] storage observations,
        ObservationState storage state,
        uint8 tokenCount,
        address pool,
        IVault vault,
        uint48 currentTimestamp,
        uint32 secondsAgo,
        uint16 slippageBps,
        address tokenIn,
        address tokenOut,
        uint256 amountInRaw,
        uint256 swapFeePercentage
    ) external view returns (uint256 expectedAmountOutRaw, uint256 minAmountOutRaw) {
        PoolData memory data = vault.getPoolData(pool);
        (uint256 indexIn, uint256 indexOut) = _findSwapTokenIndexes(data, tokenCount, tokenIn, tokenOut);

        uint256[] memory balancesPerBpt = _getTimeWeightedBalancesPerBptAt(
            observations,
            state,
            tokenCount,
            pool,
            currentTimestamp,
            secondsAgo
        );
        uint256 currentSupply = IERC20(pool).totalSupply();
        if (currentSupply == 0) revert OracleQuoteTotalSupplyIsZero(pool);

        uint256[] memory oracleBalances = new uint256[](tokenCount);
        for (uint256 i = 0; i < tokenCount; ++i) {
            oracleBalances[i] = balancesPerBpt[i].mulDown(currentSupply);
        }

        uint256 amountInScaled18 = amountInRaw.toScaled18ApplyRateRoundDown(
            data.decimalScalingFactors[indexIn],
            data.tokenRates[indexIn]
        );
        uint256 amountInAfterFeeScaled18 = amountInScaled18.mulDown(
            swapFeePercentage.complement()
        );
        uint256 amountOutScaled18 = IReadOnlySwapPool(pool).onSwap(
            PoolSwapParams({
                kind: SwapKind.EXACT_IN,
                amountGivenScaled18: amountInAfterFeeScaled18,
                balancesScaled18: oracleBalances,
                indexIn: indexIn,
                indexOut: indexOut,
                router: address(this),
                userData: ""
            })
        );
        expectedAmountOutRaw = amountOutScaled18.toRawUndoRateRoundDown(
            data.decimalScalingFactors[indexOut],
            data.tokenRates[indexOut]
        );
        minAmountOutRaw = Math.mulDiv(
            expectedAmountOutRaw,
            10_000 - slippageBps,
            10_000
        );
    }

    function _quoteOracleProtectedBptOutScaled18At(
        Observation[512] storage observations,
        ObservationState storage state,
        uint8 tokenCount,
        address pool,
        IVault vault,
        uint48 currentTimestamp,
        uint32 secondsAgo,
        uint16 slippageBps,
        uint256[] memory exactAmountsInScaled18
    ) private view returns (uint256 expectedBptOut, uint256 minBptOut) {
        if (exactAmountsInScaled18.length != tokenCount) {
            revert InvalidObservationArrayLength(
                exactAmountsInScaled18.length,
                tokenCount
            );
        }

        uint256[] memory balancesPerBpt = _getTimeWeightedBalancesPerBptAt(
            observations,
            state,
            tokenCount,
            pool,
            currentTimestamp,
            secondsAgo
        );
        uint256 currentSupply = IERC20(pool).totalSupply();
        if (currentSupply == 0) revert OracleQuoteTotalSupplyIsZero(pool);

        uint256[] memory oracleBalances = new uint256[](tokenCount);
        for (uint256 i = 0; i < tokenCount; ++i) {
            oracleBalances[i] = balancesPerBpt[i].mulDown(currentSupply);
        }

        (expectedBptOut, ) = BasePoolMath.computeAddLiquidityUnbalanced(
            oracleBalances,
            exactAmountsInScaled18,
            currentSupply,
            vault.getStaticSwapFeePercentage(pool),
            IBasePool(pool)
        );
        minBptOut = Math.mulDiv(
            expectedBptOut,
            10_000 - slippageBps,
            10_000
        );
    }

    function _findSwapTokenIndexes(
        PoolData memory data,
        uint8 tokenCount,
        address tokenIn,
        address tokenOut
    ) private pure returns (uint256 indexIn, uint256 indexOut) {
        bool foundIn;
        bool foundOut;
        for (uint256 i = 0; i < tokenCount; ++i) {
            address token = address(data.tokens[i]);
            if (token == tokenIn) {
                indexIn = i;
                foundIn = true;
            }
            if (token == tokenOut) {
                indexOut = i;
                foundOut = true;
            }
        }
        if (!foundIn || !foundOut || indexIn == indexOut) {
            revert InvalidObservationSwapTokens(tokenIn, tokenOut);
        }
    }

    function _getTimeWeightedBalancesPerBptAt(
        Observation[512] storage observations,
        ObservationState storage state,
        uint8 tokenCount,
        address pool,
        uint48 currentTimestamp,
        uint32 secondsAgo
    ) private view returns (uint256[] memory balancesPerBpt) {
        if (!state.initialized) revert ObservationNotInitialized(pool);
        if (secondsAgo == 0) revert InvalidObservationWindow();
        if (currentTimestamp < state.lastTimestamp) {
            revert ObservationTimestampRegression(currentTimestamp, state.lastTimestamp);
        }
        if (secondsAgo > currentTimestamp) {
            revert InsufficientObservationHistory(pool, secondsAgo);
        }

        uint48 targetTimestamp = currentTimestamp - uint48(secondsAgo);
        Observation storage oldest = observations[_physicalIndex(state, 0)];
        if (targetTimestamp < oldest.timestamp) {
            revert InsufficientObservationHistory(pool, secondsAgo);
        }

        int256[8] memory endCumulative = _extrapolate(
            state.cumulativeLogs,
            state.instantLogs,
            state.lastTimestamp,
            currentTimestamp
        );
        int256[8] memory beginCumulative = _cumulativeAt(
            observations,
            state,
            targetTimestamp
        );

        balancesPerBpt = new uint256[](tokenCount);
        int256 divisor = int256(uint256(secondsAgo));
        for (uint256 i = 0; i < tokenCount; ++i) {
            int256 averageLog = (endCumulative[i] - beginCumulative[i]) / divisor;
            int256 balancePerBpt = LogExpMath.exp(averageLog);
            if (balancePerBpt <= 0) revert InvalidExponentialResult(balancePerBpt);
            balancesPerBpt[i] = uint256(balancePerBpt);
        }
    }

    function _cumulativeAt(
        Observation[512] storage observations,
        ObservationState storage state,
        uint48 targetTimestamp
    ) private view returns (int256[8] memory cumulativeLogs) {
        if (targetTimestamp >= state.lastTimestamp) {
            return _extrapolate(
                state.cumulativeLogs,
                state.instantLogs,
                state.lastTimestamp,
                targetTimestamp
            );
        }

        uint256 low;
        uint256 high = state.cardinality - 1;
        while (low <= high) {
            uint256 middle = (low + high) >> 1;
            Observation storage sample = observations[_physicalIndex(state, middle)];
            if (sample.timestamp == targetTimestamp) {
                return _copy(sample.cumulativeLogs);
            }
            if (sample.timestamp < targetTimestamp) {
                low = middle + 1;
            } else {
                if (middle == 0) break;
                high = middle - 1;
            }
        }

        Observation storage beforeSample = observations[_physicalIndex(state, high)];
        if (low < state.cardinality) {
            Observation storage afterSample = observations[_physicalIndex(state, low)];
            return _interpolate(
                beforeSample,
                afterSample.timestamp,
                afterSample.cumulativeLogs,
                targetTimestamp
            );
        }

        return _interpolate(
            beforeSample,
            state.lastTimestamp,
            state.cumulativeLogs,
            targetTimestamp
        );
    }

    function _interpolate(
        Observation storage beforeSample,
        uint48 afterTimestamp,
        int128[8] storage afterCumulative,
        uint48 targetTimestamp
    ) private view returns (int256[8] memory cumulativeLogs) {
        if (targetTimestamp > afterTimestamp) {
            revert ObservationTimestampInFuture(targetTimestamp, afterTimestamp);
        }

        uint256 elapsed = targetTimestamp - beforeSample.timestamp;
        uint256 duration = afterTimestamp - beforeSample.timestamp;
        if (duration == 0) return _copy(beforeSample.cumulativeLogs);

        for (uint256 i = 0; i < 8; ++i) {
            int256 beforeValue = int256(beforeSample.cumulativeLogs[i]);
            int256 delta = int256(afterCumulative[i]) - beforeValue;
            cumulativeLogs[i] = beforeValue + (delta * int256(elapsed)) / int256(duration);
        }
    }

    function _extrapolate(
        int128[8] storage cumulative,
        int128[8] storage instant,
        uint48 fromTimestamp,
        uint48 toTimestamp
    ) private view returns (int256[8] memory extrapolated) {
        if (toTimestamp < fromTimestamp) {
            revert ObservationTimestampRegression(toTimestamp, fromTimestamp);
        }

        int256 elapsed = int256(uint256(toTimestamp - fromTimestamp));
        for (uint256 i = 0; i < 8; ++i) {
            extrapolated[i] = int256(cumulative[i]) + int256(instant[i]) * elapsed;
        }
    }

    function _copy(
        int128[8] storage values
    ) private view returns (int256[8] memory copied) {
        for (uint256 i = 0; i < 8; ++i) {
            copied[i] = int256(values[i]);
        }
    }

    function _physicalIndex(
        ObservationState storage state,
        uint256 logicalIndex
    ) private view returns (uint256) {
        uint256 cardinality = state.cardinality;
        if (cardinality == 0 || cardinality > _MAX_OBSERVATIONS) {
            revert InvalidObservationCardinality(state.cardinality);
        }

        uint256 oldest = cardinality == _MAX_OBSERVATIONS
            ? (uint256(state.index) + 1) % _MAX_OBSERVATIONS
            : 0;
        return (oldest + logicalIndex) % _MAX_OBSERVATIONS;
    }
}
