// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

interface IProtocolFeeController {
    function collectAggregateFees(address pool) external;
    function getProtocolFeeAmounts(address pool) external view returns (uint256[] memory feeAmounts);
    function getPoolCreatorFeeAmounts(address pool) external view returns (uint256[] memory feeAmounts);
    function withdrawProtocolFees(address pool, address recipient) external;
    function withdrawPoolCreatorFees(address pool, address recipient) external;
    function setPoolCreatorSwapFeePercentage(address pool, uint256 poolCreatorSwapFeePercentage) external;
    function getPoolCreatorSwapFeePercentage(address pool) external view returns (uint256);
    function setProtocolSwapFeePercentage(address pool, uint256 newProtocolSwapFeePercentage) external;
    function getPoolProtocolSwapFeeInfo(address pool) external view returns (uint256 feePercentage, bool isOverride);
}
