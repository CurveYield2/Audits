// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

library CurveYieldFeeMath {
    uint256 internal constant BPS = 10_000;
    uint256 internal constant CREATOR_PERSONAL_MAX_BPS = 2_000;
    uint256 internal constant CREATOR_PL_MAX_BPS = 5_000;
    uint256 internal constant CREATOR_PARTNER_MAX_BPS = 2_000;
    uint256 internal constant CREATOR_TOTAL_MAX_BPS = 9_000;

    error CreatorPersonalTooHigh();
    error CreatorPermanentLiquidityTooHigh();
    error CreatorPartnerTooHigh();
    error CreatorTotalTooHigh();

    function creatorTotalBps(uint256 personalBps, uint256 permanentLiquidityBps, uint256 partnerBps)
        internal
        pure
        returns (uint256)
    {
        return personalBps + permanentLiquidityBps + partnerBps;
    }

    function validateCreatorBps(uint256 personalBps, uint256 permanentLiquidityBps, uint256 partnerBps)
        internal
        pure
    {
        if (personalBps > CREATOR_PERSONAL_MAX_BPS) revert CreatorPersonalTooHigh();
        if (permanentLiquidityBps > CREATOR_PL_MAX_BPS) revert CreatorPermanentLiquidityTooHigh();
        if (partnerBps > CREATOR_PARTNER_MAX_BPS) revert CreatorPartnerTooHigh();
        if (creatorTotalBps(personalBps, permanentLiquidityBps, partnerBps) > CREATOR_TOTAL_MAX_BPS) {
            revert CreatorTotalTooHigh();
        }
    }

    function splitWithAdminCut(uint256 amount) internal pure returns (uint256 receiverAmount, uint256 adminAmount) {
        adminAmount = (amount * 3300) / BPS;
        receiverAmount = amount - adminAmount;
    }

}
