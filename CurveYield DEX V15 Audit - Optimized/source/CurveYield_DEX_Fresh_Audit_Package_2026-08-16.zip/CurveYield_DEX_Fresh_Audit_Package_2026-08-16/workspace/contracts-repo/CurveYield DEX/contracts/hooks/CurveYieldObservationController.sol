// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract exports CurveYield's observation and oracle-protected settlement logic into a
 * separate deployed component so V14 hook wrappers can stay below EIP-170. It is derived from
 * CurveYield's Balancer-inspired `PoolObservation` module without editing the original module.
 */

import { IVault } from "@balancer-labs/v3-interfaces/contracts/vault/IVault.sol";
import { TokenConfig } from "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";
import {
    SingletonAuthentication
} from "@balancer-labs/v3-vault/contracts/SingletonAuthentication.sol";

import { CurveYieldPoolKind } from "./CurveYieldHookTypes.sol";
import { PoolObservation } from "./PoolObservation.sol";

contract CurveYieldObservationController is PoolObservation, SingletonAuthentication {
    mapping(address hook => bool approved) public isApprovedHook;

    error ZeroAddress();
    error UnauthorizedHook(address hook);

    event ApprovedHookSet(address indexed hook, bool approved);

    modifier onlyApprovedHook() {
        if (!isApprovedHook[msg.sender]) revert UnauthorizedHook(msg.sender);
        _;
    }

    constructor(IVault vault) PoolObservation(vault) SingletonAuthentication(vault) {}

    function setApprovedHook(address hook, bool approved) external authenticate {
        if (hook == address(0)) revert ZeroAddress();
        isApprovedHook[hook] = approved;
        emit ApprovedHookSet(hook, approved);
    }

    function registerObservationPool(
        address factory,
        address pool,
        TokenConfig[] memory tokenConfig,
        CurveYieldPoolKind kind
    ) external onlyApprovedHook {
        _registerObservationPool(factory, pool, tokenConfig, kind);
    }

    function observe(
        address pool,
        uint256[] memory balancesScaled18
    ) external onlyApprovedHook {
        _observeAt(pool, balancesScaled18, _totalSupply(pool), _currentTimestampExternal());
    }

    function initializeObservation(address pool) external {
        _initializeObservation(pool);
    }

    function checkpoint(address pool) external {
        _checkpoint(pool);
    }

    function isObservationWarm(address pool) external view returns (bool) {
        return _isObservationWarm(pool);
    }

    function registeredPoolKind(address pool) external view returns (CurveYieldPoolKind) {
        return _observationPoolKinds[pool];
    }

    function normalizedWeight(address pool, uint256 tokenIndex) external view returns (uint64) {
        return _observationNormalizedWeights[pool][tokenIndex];
    }

    function getTimeWeightedBalancesPerBpt(
        address pool,
        uint32 secondsAgo
    ) external view returns (uint256[] memory balancesPerBpt) {
        return _getTimeWeightedBalancesPerBpt(pool, secondsAgo);
    }

    function quoteOracleProtectedBptOut(
        address pool,
        uint256[] calldata exactAmountsInRaw,
        uint32 window,
        uint16 slippageBps
    ) external view returns (uint256 oracleExpectedBptOut, uint256 oracleMinBptOut) {
        return _quoteOracleProtectedBptOut(pool, exactAmountsInRaw, window, slippageBps);
    }

    function quoteOracleProtectedBptOutScaled18(
        address pool,
        uint256[] calldata exactAmountsInScaled18,
        uint32 window,
        uint16 slippageBps
    ) external view returns (uint256 oracleExpectedBptOut, uint256 oracleMinBptOut) {
        return _quoteOracleProtectedBptOutScaled18(pool, exactAmountsInScaled18, window, slippageBps);
    }

    function quoteOracleProtectedSwapOut(
        address pool,
        address tokenIn,
        address tokenOut,
        uint256 amountInRaw,
        uint32 window,
        uint16 slippageBps,
        uint256 swapFeePercentage
    ) external view returns (uint256 oracleExpectedAmountOut, uint256 oracleMinAmountOut) {
        return _quoteOracleProtectedSwapOut(
            pool,
            tokenIn,
            tokenOut,
            amountInRaw,
            window,
            slippageBps,
            swapFeePercentage
        );
    }

    function _totalSupply(address pool) private view returns (uint256) {
        return IERC20Like(pool).totalSupply();
    }

    function _currentTimestampExternal() private view returns (uint48) {
        return uint48(block.timestamp);
    }
}

interface IERC20Like {
    function totalSupply() external view returns (uint256);
}
