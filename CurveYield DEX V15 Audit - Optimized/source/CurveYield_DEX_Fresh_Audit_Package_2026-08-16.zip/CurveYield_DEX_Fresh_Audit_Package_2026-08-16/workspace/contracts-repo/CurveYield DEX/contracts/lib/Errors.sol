// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

library Errors {
    error ZeroAddress();
    error Unauthorized();
    error AlreadyRegistered();
    error NotRegistered();
    error UnsupportedPoolType();
    error InvalidConfiguration();
}
