// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import { AragonOwned } from "./access/AragonOwned.sol";
import { IBalancerV3Router } from "./interfaces/IBalancerV3Router.sol";
import { IBalancerV3Vault } from "./interfaces/IBalancerV3Vault.sol";
import { ISwapAdapter } from "./interfaces/ISwapAdapter.sol";
import { RouteRegistry } from "./RouteRegistry.sol";
import { SafeERC20Transfer } from "./utils/SafeERC20Transfer.sol";
import { ReentrancyGuard } from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

interface IERC20VaultMigration {
    function balanceOf(address account) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
}

interface IPermit2VaultApprove {
    function approve(address token, address spender, uint160 amount, uint48 expiration) external;
}

contract PermanentLiquidityVaultV2 is AragonOwned, ReentrancyGuard {
    enum LiquidityOrigin {
        CreatorPermanentLiquidity,
        AdminPermanentLiquidity,
        PartnerPoL
    }

    struct LiquidityLot {
        address sourcePool;
        address targetPool;
        address bpt;
        uint256 remainingBpt;
        LiquidityOrigin origin;
        address creatorController;
        address creatorPayoutReceiver;
    }

    struct MigrationSwap {
        address tokenIn;
        address tokenOut;
        address adapter;
        uint256 amountIn;
        uint256 minAmountOut;
        bytes32 routeDataHash;
    }

    struct MigrationPlan {
        uint256 lotId;
        address targetPool;
        uint256 sourceBptAmount;
        bytes32 sourceTokenSetHash;
        bytes32 targetTokenSetHash;
        uint256[] minSourceAmountsOut;
        MigrationSwap[] swaps;
        uint256 minTargetBptOut;
        uint48 expiry;
    }

    struct CreatorMigrationRequest {
        uint256 lotId;
        address requester;
        bytes32 planHash;
        bool approved;
        bool executed;
        bool cancelled;
    }

    address public settlementRouter;
    IBalancerV3Router public immutable liquidityRouter;
    IBalancerV3Vault public immutable vault;
    RouteRegistry public immutable routeRegistry;
    address public immutable permit2;

    mapping(address => bool) public isMigrationTargetApproved;
    mapping(address => uint256) public totalBpt;
    mapping(uint256 => LiquidityLot) public liquidityLots;
    mapping(uint256 => CreatorMigrationRequest) public creatorMigrationRequests;
    mapping(bytes32 => uint256) private _recordedPermanentLiquidity;
    uint256 public nextLotId = 1;
    uint256 public nextCreatorMigrationRequestId = 1;

    error NotSettlementRouter();
    error MigrationTargetNotApproved();
    error TargetBptNotReceived();
    error ApprovalFailed();
    error NotCreatorMigrationApprover();
    error CreatorMigrationNotApproved();
    error CreatorMigrationAlreadyExecuted();
    error CreatorMigrationCancelled();
    error InvalidLot();
    error InvalidMigrationAmount();
    error InvalidMigrationPlan();
    error MigrationPlanExpired();
    error MigrationPlanHashMismatch();
    error CreatorLotRequiresDualApproval();
    error TokenSetHashMismatch();
    error InvalidSwapRoute();
    error InsufficientMigrationBalance();
    error UnrelatedBalanceDecreased();
    error Permit2AmountOverflow();
    error BptAccountingInvariant();

    event SettlementRouterUpdated(address indexed previousRouter, address indexed newRouter);
    event MigrationTargetApprovalUpdated(address indexed pool, bool approved);
    event PermanentLiquidityRecorded(
        address indexed sourcePool,
        address indexed targetPool,
        address indexed bpt,
        uint256 amount,
        LiquidityOrigin origin,
        uint256 lotId
    );
    event PermanentLiquidityMigrated(
        uint256 indexed sourceLotId,
        uint256 indexed targetLotId,
        address indexed sourceBpt,
        address targetBpt,
        uint256 sourceBptSpent,
        uint256 targetBptReceived
    );
    event CreatorMigrationRequested(
        uint256 indexed requestId,
        uint256 indexed lotId,
        address indexed requester,
        bytes32 planHash
    );
    event CreatorMigrationApproved(uint256 indexed requestId, address indexed approver);
    event CreatorMigrationRequestCancelled(uint256 indexed requestId, address indexed caller);
    event CreatorMigrationExecuted(uint256 indexed requestId, uint256 indexed targetLotId);

    constructor(
        address initialOwner,
        address liquidityRouter_,
        address vault_,
        address routeRegistry_,
        address permit2_
    ) AragonOwned(initialOwner) {
        if (
            liquidityRouter_ == address(0) || vault_ == address(0) || routeRegistry_ == address(0)
                || permit2_ == address(0)
        ) {
            revert ZeroAddress();
        }
        liquidityRouter = IBalancerV3Router(liquidityRouter_);
        vault = IBalancerV3Vault(vault_);
        routeRegistry = RouteRegistry(routeRegistry_);
        permit2 = permit2_;
    }

    function setSettlementRouter(address newRouter) external onlyOwner {
        if (newRouter == address(0)) revert ZeroAddress();
        address previousRouter = settlementRouter;
        settlementRouter = newRouter;
        emit SettlementRouterUpdated(previousRouter, newRouter);
    }

    function recordPermanentLiquidity(
        address sourcePool,
        address targetPool,
        address bpt,
        uint256 amount,
        LiquidityOrigin origin,
        address creatorController,
        address creatorPayoutReceiver
    ) external nonReentrant returns (uint256 lotId) {
        if (msg.sender != settlementRouter) revert NotSettlementRouter();
        if (sourcePool == address(0) || targetPool == address(0) || bpt == address(0)) revert ZeroAddress();
        if (amount == 0) revert InvalidMigrationAmount();
        if (origin == LiquidityOrigin.CreatorPermanentLiquidity) {
            if (creatorController == address(0) || creatorPayoutReceiver == address(0)) revert ZeroAddress();
        } else {
            creatorController = address(0);
            creatorPayoutReceiver = address(0);
        }

        _recordedPermanentLiquidity[_recordKey(sourcePool, targetPool, bpt)] += amount;
        totalBpt[bpt] += amount;
        if (IERC20VaultMigration(bpt).balanceOf(address(this)) < totalBpt[bpt]) {
            revert BptAccountingInvariant();
        }
        lotId = _createLot(
            sourcePool,
            targetPool,
            bpt,
            amount,
            origin,
            creatorController,
            creatorPayoutReceiver
        );

        emit PermanentLiquidityRecorded(sourcePool, targetPool, bpt, amount, origin, lotId);
    }

    function approveMigrationTarget(address pool, bool approved) external onlyOwner {
        if (pool == address(0)) revert ZeroAddress();
        isMigrationTargetApproved[pool] = approved;
        emit MigrationTargetApprovalUpdated(pool, approved);
    }

    function hashMigrationPlan(MigrationPlan calldata plan) public pure returns (bytes32) {
        return keccak256(abi.encode(plan));
    }

    function requestCreatorMigration(MigrationPlan calldata plan)
        external
        nonReentrant
        returns (uint256 requestId)
    {
        LiquidityLot storage lot = liquidityLots[plan.lotId];
        _validatePlan(lot, plan);
        if (lot.origin != LiquidityOrigin.CreatorPermanentLiquidity) revert InvalidLot();
        if (msg.sender != lot.creatorController && msg.sender != lot.creatorPayoutReceiver) {
            revert NotCreatorMigrationApprover();
        }

        bytes32 planHash = hashMigrationPlan(plan);
        requestId = nextCreatorMigrationRequestId++;
        creatorMigrationRequests[requestId] = CreatorMigrationRequest({
            lotId: plan.lotId,
            requester: msg.sender,
            planHash: planHash,
            approved: false,
            executed: false,
            cancelled: false
        });

        emit CreatorMigrationRequested(requestId, plan.lotId, msg.sender, planHash);
    }

    function approveCreatorMigration(uint256 requestId) external onlyOwner nonReentrant {
        CreatorMigrationRequest storage request = creatorMigrationRequests[requestId];
        _validateOpenRequest(request);
        request.approved = true;
        emit CreatorMigrationApproved(requestId, msg.sender);
    }

    function cancelCreatorMigration(uint256 requestId) external nonReentrant {
        CreatorMigrationRequest storage request = creatorMigrationRequests[requestId];
        _validateOpenRequest(request);
        if (msg.sender != owner && msg.sender != request.requester) revert NotCreatorMigrationApprover();
        request.cancelled = true;
        emit CreatorMigrationRequestCancelled(requestId, msg.sender);
    }

    function executeCreatorMigration(
        uint256 requestId,
        MigrationPlan calldata plan,
        bytes[] calldata routeData
    ) external nonReentrant returns (uint256 targetLotId) {
        CreatorMigrationRequest storage request = creatorMigrationRequests[requestId];
        _validateOpenRequest(request);
        if (!request.approved) revert CreatorMigrationNotApproved();
        if (request.planHash != hashMigrationPlan(plan)) revert MigrationPlanHashMismatch();

        LiquidityLot storage lot = liquidityLots[request.lotId];
        targetLotId = _executeMigration(lot, plan, routeData);
        request.executed = true;
        emit CreatorMigrationExecuted(requestId, targetLotId);
    }

    function migrateAdminLot(MigrationPlan calldata plan, bytes[] calldata routeData)
        external
        onlyOwner
        nonReentrant
        returns (uint256 targetLotId)
    {
        LiquidityLot storage lot = liquidityLots[plan.lotId];
        if (lot.origin == LiquidityOrigin.CreatorPermanentLiquidity) revert CreatorLotRequiresDualApproval();
        targetLotId = _executeMigration(lot, plan, routeData);
    }

    function recordedPermanentLiquidity(address sourcePool, address targetPool, address bpt)
        external
        view
        returns (uint256)
    {
        return _recordedPermanentLiquidity[_recordKey(sourcePool, targetPool, bpt)];
    }

    function _executeMigration(
        LiquidityLot storage lot,
        MigrationPlan calldata plan,
        bytes[] calldata routeData
    ) private returns (uint256 targetLotId) {
        _validatePlan(lot, plan);
        if (routeData.length != plan.swaps.length) revert InvalidMigrationPlan();

        address sourcePool = lot.bpt;
        address targetPool = plan.targetPool;
        address[] memory sourceTokens = vault.getPoolTokens(sourcePool);
        address[] memory targetTokens = vault.getPoolTokens(targetPool);
        if (keccak256(abi.encode(sourceTokens)) != plan.sourceTokenSetHash) revert TokenSetHashMismatch();
        if (keccak256(abi.encode(targetTokens)) != plan.targetTokenSetHash) revert TokenSetHashMismatch();
        if (plan.minSourceAmountsOut.length != sourceTokens.length) revert InvalidMigrationPlan();
        for (uint256 i = 0; i < plan.minSourceAmountsOut.length; ++i) {
            if (plan.minSourceAmountsOut[i] == 0) revert InvalidMigrationPlan();
        }

        uint256[] memory sourceStartingBalances = _balances(sourceTokens);
        uint256[] memory targetStartingBalances = _balances(targetTokens);
        uint256 sourceBptBefore = IERC20VaultMigration(sourcePool).balanceOf(address(this));
        uint256 targetBptBefore = IERC20VaultMigration(targetPool).balanceOf(address(this));

        _approveRouterToken(sourcePool, plan.sourceBptAmount);
        liquidityRouter.removeLiquidityProportional(
            sourcePool,
            plan.sourceBptAmount,
            plan.minSourceAmountsOut,
            false,
            ""
        );
        _clearRouterTokenApproval(sourcePool);

        uint256 sourceBptAfter = IERC20VaultMigration(sourcePool).balanceOf(address(this));
        if (sourceBptBefore - sourceBptAfter != plan.sourceBptAmount) revert InvalidMigrationAmount();

        for (uint256 i = 0; i < plan.swaps.length; ++i) {
            _executeSwap(
                sourceTokens,
                targetTokens,
                sourceStartingBalances,
                targetStartingBalances,
                plan.swaps[i],
                routeData[i]
            );
        }

        uint256[] memory exactTargetAmountsIn = new uint256[](targetTokens.length);
        for (uint256 i = 0; i < targetTokens.length; ++i) {
            uint256 currentBalance = IERC20VaultMigration(targetTokens[i]).balanceOf(address(this));
            if (currentBalance < targetStartingBalances[i]) revert UnrelatedBalanceDecreased();
            exactTargetAmountsIn[i] = currentBalance - targetStartingBalances[i];
            if (exactTargetAmountsIn[i] > 0) {
                _approveRouterToken(targetTokens[i], exactTargetAmountsIn[i]);
            }
        }

        for (uint256 i = 0; i < sourceTokens.length; ++i) {
            if (_contains(targetTokens, sourceTokens[i])) continue;
            if (IERC20VaultMigration(sourceTokens[i]).balanceOf(address(this)) != sourceStartingBalances[i]) {
                revert InsufficientMigrationBalance();
            }
        }

        uint256 targetBptReceived = liquidityRouter.addLiquidityUnbalanced(
            targetPool,
            exactTargetAmountsIn,
            plan.minTargetBptOut,
            false,
            ""
        );
        for (uint256 i = 0; i < targetTokens.length; ++i) {
            if (exactTargetAmountsIn[i] > 0) _clearRouterTokenApproval(targetTokens[i]);
            if (IERC20VaultMigration(targetTokens[i]).balanceOf(address(this)) != targetStartingBalances[i]) {
                revert UnrelatedBalanceDecreased();
            }
        }

        uint256 targetBptDelta =
            IERC20VaultMigration(targetPool).balanceOf(address(this)) - targetBptBefore;
        if (targetBptReceived == 0 || targetBptDelta != targetBptReceived) revert TargetBptNotReceived();

        uint256 sourceBptAmount = plan.sourceBptAmount;
        lot.remainingBpt -= sourceBptAmount;
        totalBpt[sourcePool] -= sourceBptAmount;
        totalBpt[targetPool] += targetBptReceived;
        _recordedPermanentLiquidity[_recordKey(lot.sourcePool, lot.targetPool, lot.bpt)] -= sourceBptAmount;
        _recordedPermanentLiquidity[_recordKey(lot.sourcePool, targetPool, targetPool)] += targetBptReceived;
        if (
            IERC20VaultMigration(sourcePool).balanceOf(address(this)) < totalBpt[sourcePool]
                || IERC20VaultMigration(targetPool).balanceOf(address(this)) < totalBpt[targetPool]
        ) {
            revert BptAccountingInvariant();
        }

        targetLotId = _createLot(
            lot.sourcePool,
            targetPool,
            targetPool,
            targetBptReceived,
            lot.origin,
            lot.creatorController,
            lot.creatorPayoutReceiver
        );

        emit PermanentLiquidityMigrated(
            plan.lotId,
            targetLotId,
            sourcePool,
            targetPool,
            sourceBptAmount,
            targetBptReceived
        );
    }

    function _executeSwap(
        address[] memory sourceTokens,
        address[] memory targetTokens,
        uint256[] memory sourceStartingBalances,
        uint256[] memory targetStartingBalances,
        MigrationSwap calldata swapPlan,
        bytes calldata routeData
    ) private {
        (bool sourceFound, uint256 sourceIndex) = _indexOf(sourceTokens, swapPlan.tokenIn);
        (bool targetFound,) = _indexOf(targetTokens, swapPlan.tokenOut);
        if (!sourceFound || !targetFound || swapPlan.tokenIn == swapPlan.tokenOut) revert InvalidMigrationPlan();
        if (swapPlan.amountIn == 0 || swapPlan.minAmountOut == 0) revert InvalidMigrationPlan();
        if (keccak256(routeData) != swapPlan.routeDataHash) revert MigrationPlanHashMismatch();

        (address adapter, bytes memory registeredRouteData) =
            routeRegistry.getExecutableRoute(swapPlan.tokenIn, swapPlan.tokenOut);
        if (
            adapter != swapPlan.adapter || keccak256(registeredRouteData) != swapPlan.routeDataHash
                || keccak256(registeredRouteData) != keccak256(routeData)
        ) {
            revert InvalidSwapRoute();
        }

        uint256 tokenInBalance = IERC20VaultMigration(swapPlan.tokenIn).balanceOf(address(this));
        uint256 tokenInStartingBalance = sourceStartingBalances[sourceIndex];
        if (_contains(targetTokens, swapPlan.tokenIn)) {
            (, uint256 overlappingTargetIndex) = _indexOf(targetTokens, swapPlan.tokenIn);
            tokenInStartingBalance =
                _max(tokenInStartingBalance, targetStartingBalances[overlappingTargetIndex]);
        }
        if (tokenInBalance < tokenInStartingBalance + swapPlan.amountIn) {
            revert InsufficientMigrationBalance();
        }

        uint256 adapterBalanceBefore = IERC20VaultMigration(swapPlan.tokenIn).balanceOf(adapter);
        uint256 tokenOutBalanceBefore = IERC20VaultMigration(swapPlan.tokenOut).balanceOf(address(this));
        SafeERC20Transfer.safeTransfer(swapPlan.tokenIn, adapter, swapPlan.amountIn);
        uint256 actualAmountIn =
            IERC20VaultMigration(swapPlan.tokenIn).balanceOf(adapter) - adapterBalanceBefore;
        ISwapAdapter(adapter).swap(
            swapPlan.tokenIn,
            swapPlan.tokenOut,
            actualAmountIn,
            swapPlan.minAmountOut,
            routeData
        );
        uint256 actualAmountOut =
            IERC20VaultMigration(swapPlan.tokenOut).balanceOf(address(this)) - tokenOutBalanceBefore;
        if (actualAmountOut < swapPlan.minAmountOut) revert InvalidSwapRoute();
    }

    function _validatePlan(LiquidityLot storage lot, MigrationPlan calldata plan) private view {
        if (lot.bpt == address(0) || plan.lotId == 0) revert InvalidLot();
        if (!isMigrationTargetApproved[plan.targetPool]) revert MigrationTargetNotApproved();
        if (plan.targetPool == address(0) || plan.targetPool == lot.bpt) revert InvalidMigrationPlan();
        if (plan.sourceBptAmount == 0 || plan.sourceBptAmount > lot.remainingBpt) {
            revert InvalidMigrationAmount();
        }
        if (
            plan.sourceTokenSetHash == bytes32(0) || plan.targetTokenSetHash == bytes32(0)
                || plan.minTargetBptOut == 0
        ) {
            revert InvalidMigrationPlan();
        }
        if (plan.expiry < block.timestamp) revert MigrationPlanExpired();
    }

    function _validateOpenRequest(CreatorMigrationRequest storage request) private view {
        if (request.lotId == 0) revert InvalidLot();
        if (request.executed) revert CreatorMigrationAlreadyExecuted();
        if (request.cancelled) revert CreatorMigrationCancelled();
    }

    function _createLot(
        address sourcePool,
        address targetPool,
        address bpt,
        uint256 amount,
        LiquidityOrigin origin,
        address creatorController,
        address creatorPayoutReceiver
    ) private returns (uint256 lotId) {
        lotId = nextLotId++;
        liquidityLots[lotId] = LiquidityLot({
            sourcePool: sourcePool,
            targetPool: targetPool,
            bpt: bpt,
            remainingBpt: amount,
            origin: origin,
            creatorController: creatorController,
            creatorPayoutReceiver: creatorPayoutReceiver
        });
    }

    function _approveRouterToken(address token, uint256 amount) private {
        if (amount > type(uint160).max) revert Permit2AmountOverflow();
        _safeApprove(token, permit2, amount);
        IPermit2VaultApprove(permit2).approve(
            token,
            address(liquidityRouter),
            uint160(amount),
            uint48(block.timestamp)
        );
    }

    function _clearRouterTokenApproval(address token) private {
        IPermit2VaultApprove(permit2).approve(token, address(liquidityRouter), 0, 0);
        _safeApprove(token, permit2, 0);
    }

    function _safeApprove(address token, address spender, uint256 amount) private {
        (bool zeroOk, bytes memory zeroData) =
            token.call(abi.encodeWithSelector(IERC20VaultMigration.approve.selector, spender, 0));
        if (!zeroOk || (zeroData.length != 0 && !abi.decode(zeroData, (bool)))) revert ApprovalFailed();
        if (amount == 0) return;
        (bool ok, bytes memory data) =
            token.call(abi.encodeWithSelector(IERC20VaultMigration.approve.selector, spender, amount));
        if (!ok || (data.length != 0 && !abi.decode(data, (bool)))) revert ApprovalFailed();
    }

    function _balances(address[] memory tokens) private view returns (uint256[] memory balances) {
        balances = new uint256[](tokens.length);
        for (uint256 i = 0; i < tokens.length; ++i) {
            balances[i] = IERC20VaultMigration(tokens[i]).balanceOf(address(this));
        }
    }

    function _indexOf(address[] memory tokens, address token) private pure returns (bool found, uint256 index) {
        for (uint256 i = 0; i < tokens.length; ++i) {
            if (tokens[i] == token) return (true, i);
        }
    }

    function _contains(address[] memory tokens, address token) private pure returns (bool) {
        (bool found,) = _indexOf(tokens, token);
        return found;
    }

    function _max(uint256 a, uint256 b) private pure returns (uint256) {
        return a > b ? a : b;
    }

    function _recordKey(address sourcePool, address targetPool, address bpt) private pure returns (bytes32) {
        return keccak256(abi.encode(sourcePool, targetPool, bpt));
    }
}
