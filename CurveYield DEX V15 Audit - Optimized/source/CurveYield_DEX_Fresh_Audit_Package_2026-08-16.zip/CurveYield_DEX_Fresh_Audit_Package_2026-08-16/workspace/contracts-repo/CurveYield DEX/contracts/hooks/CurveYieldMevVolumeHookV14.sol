// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract is a fork of Balancer's MevCaptureHook combined with CurveYield volume and oracle logic.
 * Balancer's gracious use of open-source GPL licensing allows CurveYield to use it for the good of all.
 */

import { Math } from "@openzeppelin/contracts/utils/math/Math.sol";

import {
    IBalancerContractRegistry
} from "@balancer-labs/v3-interfaces/contracts/standalone-utils/IBalancerContractRegistry.sol";
import { IMevCaptureHook } from "@balancer-labs/v3-interfaces/contracts/pool-hooks/IMevCaptureHook.sol";
import { ISenderGuard } from "@balancer-labs/v3-interfaces/contracts/vault/ISenderGuard.sol";
import { IVault } from "@balancer-labs/v3-interfaces/contracts/vault/IVault.sol";
import {
    AddLiquidityKind,
    AfterSwapParams,
    HookFlags,
    HooksConfig,
    LiquidityManagement,
    MAX_FEE_PERCENTAGE,
    PoolSwapParams,
    RemoveLiquidityKind,
    SwapKind,
    TokenConfig
} from "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";

import { PoolFeePolicyRegistry } from "../PoolFeePolicyRegistry.sol";
import { CurveYieldCompositeHookBaseV14 } from "./CurveYieldCompositeHookBaseV14.sol";
import { CurveYieldHookConfigController } from "./CurveYieldHookConfigController.sol";
import {
    CurveYieldObservationController
} from "./CurveYieldObservationController.sol";
import {
    CurveYieldVolumeFeeController
} from "./CurveYieldVolumeFeeController.sol";
import { CurveYieldPoolKind } from "./CurveYieldHookTypes.sol";

contract CurveYieldMevVolumeHookV14 is CurveYieldCompositeHookBaseV14, IMevCaptureHook {
    uint256 private constant _MEV_MAX_FEE_PERCENTAGE = MAX_FEE_PERCENTAGE;

    bool internal _mevTaxEnabled;
    uint256 internal _defaultMevTaxThreshold;
    uint256 internal _defaultMevTaxMultiplier;
    uint256 internal _maxMevSwapFeePercentage;

    mapping(address sender => bool exempt) internal _isMevTaxExemptSender;
    mapping(address pool => uint256 threshold) internal _poolMevTaxThresholds;
    mapping(address pool => uint256 multiplier) internal _poolMevTaxMultipliers;

    modifier withMevTaxEnabledPool(address pool) {
        HooksConfig memory hooksConfig = _vault.getHooksConfig(pool);
        if (hooksConfig.hooksContract != address(this)) {
            revert MevCaptureHookNotRegisteredInPool(pool);
        }
        _;
    }

    constructor(
        IVault vault,
        IBalancerContractRegistry registry,
        PoolFeePolicyRegistry poolFeePolicyRegistry,
        CurveYieldHookConfigController hookConfigController,
        CurveYieldObservationController observationController,
        CurveYieldVolumeFeeController volumeFeeController,
        uint256 defaultMevTaxMultiplier,
        uint256 defaultMevTaxThreshold
    )
        CurveYieldCompositeHookBaseV14(
            vault,
            registry,
            poolFeePolicyRegistry,
            hookConfigController,
            observationController,
            volumeFeeController
        )
    {
        _setMevTaxEnabled(true);
        _setDefaultMevTaxMultiplier(defaultMevTaxMultiplier);
        _setDefaultMevTaxThreshold(defaultMevTaxThreshold);
        _setMaxMevSwapFeePercentage(_MEV_MAX_FEE_PERCENTAGE);
    }

    function onRegister(
        address factory,
        address pool,
        TokenConfig[] memory tokenConfig,
        LiquidityManagement calldata liquidityManagement
    ) public override returns (bool) {
        bool registered = super.onRegister(
            factory,
            pool,
            tokenConfig,
            liquidityManagement
        );
        _poolMevTaxMultipliers[pool] = _defaultMevTaxMultiplier;
        _poolMevTaxThresholds[pool] = _defaultMevTaxThreshold;
        return registered;
    }

    function getHookFlags() public pure override returns (HookFlags memory hookFlags) {
        hookFlags.shouldCallComputeDynamicSwapFee = true;
        hookFlags.shouldCallBeforeSwap = true;
        hookFlags.shouldCallAfterSwap = true;
        hookFlags.shouldCallBeforeAddLiquidity = true;
        hookFlags.shouldCallAfterAddLiquidity = true;
        hookFlags.shouldCallBeforeRemoveLiquidity = true;
        hookFlags.shouldCallAfterRemoveLiquidity = true;
    }

    function onBeforeSwap(
        PoolSwapParams calldata params,
        address pool
    ) public override onlyVault returns (bool) {
        _observe(pool, params.balancesScaled18);
        uint256 selectedTokenIndex = params.kind == SwapKind.EXACT_IN
            ? params.indexIn
            : params.indexOut;
        _recordSwapActivity(
            pool,
            params.amountGivenScaled18,
            selectedTokenIndex,
            params.balancesScaled18
        );
        return true;
    }

    function onAfterSwap(
        AfterSwapParams calldata params
    ) public override onlyVault returns (bool, uint256) {
        _observe(params.pool, _vault.getCurrentLiveBalances(params.pool));
        return (true, params.amountCalculatedRaw);
    }

    function onComputeDynamicSwapFeePercentage(
        PoolSwapParams calldata params,
        address pool,
        uint256 staticSwapFeePercentage
    ) public view override returns (bool, uint256) {
        uint256 upstreamDynamic = staticSwapFeePercentage;
        if (_mevTaxEnabled && !_isExemptRouterSender(params.router)) {
            upstreamDynamic = _calculateSwapFeePercentage(
                staticSwapFeePercentage,
                _poolMevTaxMultipliers[pool],
                _poolMevTaxThresholds[pool]
            );
        }

        uint256 mevSurcharge = upstreamDynamic > staticSwapFeePercentage
            ? upstreamDynamic - staticSwapFeePercentage
            : 0;
        uint256 volumeSurcharge = _currentVolumeSurcharge(pool);
        uint256 combined = staticSwapFeePercentage + mevSurcharge + volumeSurcharge;
        uint256 capped = Math.min(combined, _hookConfigController.effectiveCombinedFeeCap(pool));
        return (true, Math.max(staticSwapFeePercentage, capped));
    }

    function _computeSettlementSwapFeePercentage(
        PoolSwapParams memory params,
        address pool,
        uint256 staticSwapFeePercentage,
        address settlementCaller
    ) internal view override returns (uint256) {
        uint256 upstreamDynamic = staticSwapFeePercentage;
        if (_mevTaxEnabled && !_isMevTaxExemptSender[settlementCaller]) {
            upstreamDynamic = _calculateSwapFeePercentage(
                staticSwapFeePercentage,
                _poolMevTaxMultipliers[pool],
                _poolMevTaxThresholds[pool]
            );
        }

        uint256 mevSurcharge = upstreamDynamic > staticSwapFeePercentage
            ? upstreamDynamic - staticSwapFeePercentage
            : 0;
        uint256 selectedTokenIndex = params.kind == SwapKind.EXACT_IN
            ? params.indexIn
            : params.indexOut;
        uint256 volumeSurcharge = _previewVolumeSurcharge(
            pool,
            params.amountGivenScaled18,
            selectedTokenIndex,
            params.balancesScaled18
        );
        uint256 combined = staticSwapFeePercentage + mevSurcharge + volumeSurcharge;
        uint256 capped = Math.min(combined, _hookConfigController.effectiveCombinedFeeCap(pool));
        return Math.max(staticSwapFeePercentage, capped);
    }

    function onBeforeAddLiquidity(
        address router,
        address pool,
        AddLiquidityKind kind,
        uint256[] memory maxAmountsInScaled18,
        uint256 minBptAmountOut,
        uint256[] memory balancesScaled18,
        bytes memory
    ) public override onlyVault returns (bool success) {
        _observe(pool, balancesScaled18);
        bool protectedSettlementCaller = _isProtectedSettlementCaller(router);
        _validateProtectedSettlementAdd(
            router,
            pool,
            kind,
            maxAmountsInScaled18,
            minBptAmountOut
        );
        if (protectedSettlementCaller && kind == AddLiquidityKind.UNBALANCED) {
            return true;
        }
        return _isMevLiquidityOperationAllowed(
            kind == AddLiquidityKind.PROPORTIONAL,
            pool
        );
    }

    function onAfterAddLiquidity(
        address,
        address pool,
        AddLiquidityKind,
        uint256[] memory,
        uint256[] memory amountsInRaw,
        uint256,
        uint256[] memory balancesScaled18,
        bytes memory
    ) public override onlyVault returns (bool, uint256[] memory) {
        _observe(pool, balancesScaled18);
        return (true, amountsInRaw);
    }

    function onBeforeRemoveLiquidity(
        address,
        address pool,
        RemoveLiquidityKind kind,
        uint256,
        uint256[] memory,
        uint256[] memory balancesScaled18,
        bytes memory
    ) public override onlyVault returns (bool success) {
        _observe(pool, balancesScaled18);
        return _isMevLiquidityOperationAllowed(
            kind == RemoveLiquidityKind.PROPORTIONAL,
            pool
        );
    }

    function onAfterRemoveLiquidity(
        address,
        address pool,
        RemoveLiquidityKind,
        uint256,
        uint256[] memory,
        uint256[] memory amountsOutRaw,
        uint256[] memory balancesScaled18,
        bytes memory
    ) public override onlyVault returns (bool, uint256[] memory) {
        _observe(pool, balancesScaled18);
        return (true, amountsOutRaw);
    }

    function getBalancerContractRegistry()
        external
        view
        override(CurveYieldCompositeHookBaseV14, IMevCaptureHook)
        returns (IBalancerContractRegistry)
    {
        return _balancerContractRegistry;
    }

    function isMevTaxEnabled() external view returns (bool) {
        return _mevTaxEnabled;
    }

    function disableMevTax() external authenticate {
        _setMevTaxEnabled(false);
    }

    function enableMevTax() external authenticate {
        _setMevTaxEnabled(true);
    }

    function getMaxMevSwapFeePercentage() external view returns (uint256) {
        return _maxMevSwapFeePercentage;
    }

    function setMaxMevSwapFeePercentage(
        uint256 maxMevSwapFeePercentage
    ) external authenticate {
        _setMaxMevSwapFeePercentage(maxMevSwapFeePercentage);
    }

    function getDefaultMevTaxMultiplier() external view returns (uint256) {
        return _defaultMevTaxMultiplier;
    }

    function setDefaultMevTaxMultiplier(
        uint256 newDefaultMevTaxMultiplier
    ) external authenticate {
        _setDefaultMevTaxMultiplier(newDefaultMevTaxMultiplier);
    }

    function getPoolMevTaxMultiplier(
        address pool
    ) external view withMevTaxEnabledPool(pool) returns (uint256) {
        return _poolMevTaxMultipliers[pool];
    }

    function setPoolMevTaxMultiplier(
        address pool,
        uint256 newPoolMevTaxMultiplier
    ) external withMevTaxEnabledPool(pool) onlySwapFeeManagerOrGovernance(pool) {
        _setPoolMevTaxMultiplier(pool, newPoolMevTaxMultiplier);
    }

    function getDefaultMevTaxThreshold() external view returns (uint256) {
        return _defaultMevTaxThreshold;
    }

    function setDefaultMevTaxThreshold(
        uint256 newDefaultMevTaxThreshold
    ) external authenticate {
        _setDefaultMevTaxThreshold(newDefaultMevTaxThreshold);
    }

    function getPoolMevTaxThreshold(
        address pool
    ) external view withMevTaxEnabledPool(pool) returns (uint256) {
        return _poolMevTaxThresholds[pool];
    }

    function setPoolMevTaxThreshold(
        address pool,
        uint256 newPoolMevTaxThreshold
    ) external withMevTaxEnabledPool(pool) onlySwapFeeManagerOrGovernance(pool) {
        _setPoolMevTaxThreshold(pool, newPoolMevTaxThreshold);
    }

    function isMevTaxExemptSender(address sender) external view returns (bool) {
        return _isMevTaxExemptSender[sender];
    }

    function addMevTaxExemptSenders(address[] memory senders) external authenticate {
        uint256 numSenders = senders.length;
        for (uint256 i = 0; i < numSenders; ++i) {
            _addMevTaxExemptSender(senders[i]);
        }
    }

    function removeMevTaxExemptSenders(address[] memory senders) external authenticate {
        uint256 numSenders = senders.length;
        for (uint256 i = 0; i < numSenders; ++i) {
            _removeMevTaxExemptSender(senders[i]);
        }
    }

    function _supportsPoolKind(
        CurveYieldPoolKind kind
    ) internal pure override returns (bool) {
        return kind == CurveYieldPoolKind.WEIGHTED || kind == CurveYieldPoolKind.STABLE;
    }

    function _calculateSwapFeePercentage(
        uint256 staticSwapFeePercentage,
        uint256 multiplier,
        uint256 threshold
    ) internal view returns (uint256) {
        uint256 priorityGasPrice = _getPriorityGasPrice();
        uint256 maxMevSwapFeePercentage = _maxMevSwapFeePercentage;

        if (
            priorityGasPrice <= threshold ||
            maxMevSwapFeePercentage <= staticSwapFeePercentage
        ) {
            return staticSwapFeePercentage;
        }

        (bool success, uint256 feeIncrement) = Math.tryMul(
            priorityGasPrice - threshold,
            multiplier
        );
        if (!success) return maxMevSwapFeePercentage;

        feeIncrement = feeIncrement / 1e18;
        uint256 mevSwapFeePercentage = staticSwapFeePercentage + feeIncrement;
        return Math.min(mevSwapFeePercentage, maxMevSwapFeePercentage);
    }

    function _isMevLiquidityOperationAllowed(
        bool proportional,
        address pool
    ) private view returns (bool) {
        if (!_mevTaxEnabled) return true;
        return proportional || _getPriorityGasPrice() <= _poolMevTaxThresholds[pool];
    }

    function _isExemptRouterSender(address router) private view returns (bool) {
        if (!_balancerContractRegistry.isTrustedRouter(router)) return false;
        return _isMevTaxExemptSender[ISenderGuard(router).getSender()];
    }

    function _setMevTaxEnabled(bool value) private {
        _mevTaxEnabled = value;
        emit MevTaxEnabledSet(value);
    }

    function _setMaxMevSwapFeePercentage(uint256 maxMevSwapFeePercentage) internal {
        if (maxMevSwapFeePercentage > _MEV_MAX_FEE_PERCENTAGE) {
            revert MevSwapFeePercentageAboveMax(
                maxMevSwapFeePercentage,
                _MEV_MAX_FEE_PERCENTAGE
            );
        }
        _maxMevSwapFeePercentage = maxMevSwapFeePercentage;
        emit MaxMevSwapFeePercentageSet(maxMevSwapFeePercentage);
    }

    function _setDefaultMevTaxMultiplier(uint256 newDefaultMevTaxMultiplier) private {
        _defaultMevTaxMultiplier = newDefaultMevTaxMultiplier;
        emit DefaultMevTaxMultiplierSet(newDefaultMevTaxMultiplier);
    }

    function _setPoolMevTaxMultiplier(
        address pool,
        uint256 newPoolMevTaxMultiplier
    ) private {
        _poolMevTaxMultipliers[pool] = newPoolMevTaxMultiplier;
        emit PoolMevTaxMultiplierSet(pool, newPoolMevTaxMultiplier);
    }

    function _setDefaultMevTaxThreshold(uint256 newDefaultMevTaxThreshold) private {
        _defaultMevTaxThreshold = newDefaultMevTaxThreshold;
        emit DefaultMevTaxThresholdSet(newDefaultMevTaxThreshold);
    }

    function _setPoolMevTaxThreshold(
        address pool,
        uint256 newPoolMevTaxThreshold
    ) private {
        _poolMevTaxThresholds[pool] = newPoolMevTaxThreshold;
        emit PoolMevTaxThresholdSet(pool, newPoolMevTaxThreshold);
    }

    function _getPriorityGasPrice() internal view returns (uint256) {
        return tx.gasprice - block.basefee;
    }

    function _addMevTaxExemptSender(address sender) internal {
        if (_isMevTaxExemptSender[sender]) {
            revert MevTaxExemptSenderAlreadyAdded(sender);
        }
        _isMevTaxExemptSender[sender] = true;
        emit MevTaxExemptSenderAdded(sender);
    }

    function _removeMevTaxExemptSender(address sender) internal {
        if (!_isMevTaxExemptSender[sender]) {
            revert SenderNotRegisteredAsMevTaxExempt(sender);
        }
        _isMevTaxExemptSender[sender] = false;
        emit MevTaxExemptSenderRemoved(sender);
    }
}
