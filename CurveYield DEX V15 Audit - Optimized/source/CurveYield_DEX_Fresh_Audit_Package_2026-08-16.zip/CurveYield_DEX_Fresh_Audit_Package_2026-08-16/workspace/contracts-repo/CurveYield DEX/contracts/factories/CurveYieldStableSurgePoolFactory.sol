// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract is a fork of one of Balancer's smart contracts. Balancer's gracious use of open-source GPL licensing allows CurveYield to use it for the good of all.
 */

import { IPoolVersion } from "@balancer-labs/v3-interfaces/contracts/solidity-utils/helpers/IPoolVersion.sol";
import { IVaultErrors } from "@balancer-labs/v3-interfaces/contracts/vault/IVaultErrors.sol";
import "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";

import { SingletonAuthentication } from "@balancer-labs/v3-vault/contracts/SingletonAuthentication.sol";
import { BasePoolFactory } from "@balancer-labs/v3-pool-utils/contracts/BasePoolFactory.sol";
import { StableMath } from "@balancer-labs/v3-solidity-utils/contracts/math/StableMath.sol";
import { Version } from "@balancer-labs/v3-solidity-utils/contracts/helpers/Version.sol";
import { StablePool } from "@balancer-labs/v3-pool-stable/contracts/StablePool.sol";

import { CurveYieldFactoryAllowlist } from "./CurveYieldFactoryAllowlist.sol";

/**
 * @notice CurveYield allowlisted fork of Balancer's StableSurge Pool factory.
 * @dev Only approved creator contracts can call create; the CurveYield wrapper is intended to be the only approval.
 */
contract CurveYieldStableSurgePoolFactory is IPoolVersion, BasePoolFactory, Version, CurveYieldFactoryAllowlist {
    address private immutable _stableSurgeHook;

    string private _poolVersion;

    constructor(
        address stableSurgeHook,
        uint32 pauseWindowDuration,
        string memory factoryVersion,
        string memory poolVersion,
        address initialOwner
    )
        BasePoolFactory(
            SingletonAuthentication(stableSurgeHook).getVault(),
            pauseWindowDuration,
            type(StablePool).creationCode
        )
        Version(factoryVersion)
        CurveYieldFactoryAllowlist(initialOwner)
    {
        _stableSurgeHook = stableSurgeHook;
        _poolVersion = poolVersion;
    }

    /// @inheritdoc IPoolVersion
    function getPoolVersion() external view returns (string memory) {
        return _poolVersion;
    }

    function getStableSurgeHook() external view returns (address) {
        return _stableSurgeHook;
    }

    function create(
        string memory name,
        string memory symbol,
        TokenConfig[] memory tokens,
        uint256 amplificationParameter,
        PoolRoleAccounts memory roleAccounts,
        uint256 swapFeePercentage,
        bool enableDonation,
        bytes32 salt
    ) external onlyAllowedPoolCreator returns (address pool) {
        if (tokens.length > StableMath.MAX_STABLE_TOKENS) {
            revert IVaultErrors.MaxTokens();
        }

        LiquidityManagement memory liquidityManagement = getDefaultLiquidityManagement();
        liquidityManagement.enableDonation = enableDonation;

        pool = _create(
            abi.encode(
                StablePool.NewPoolParams({
                    name: name,
                    symbol: symbol,
                    amplificationParameter: amplificationParameter,
                    version: _poolVersion
                }),
                getVault()
            ),
            salt
        );

        _registerPoolWithVault(
            pool,
            tokens,
            swapFeePercentage,
            false,
            roleAccounts,
            address(_stableSurgeHook),
            liquidityManagement
        );
    }
}
