// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract exports CurveYield hook configuration state into a separate deployed component so
 * V14 hook wrappers can stay below EIP-170 while original hook/reference files remain unchanged.
 */

import { IVault } from "@balancer-labs/v3-interfaces/contracts/vault/IVault.sol";
import {
    SingletonAuthentication
} from "@balancer-labs/v3-vault/contracts/SingletonAuthentication.sol";

import {
    CurveYieldHookConstants,
    CurveYieldPoolKind,
    InvalidCombinedFeeCap,
    InvalidSettlementSlippage,
    InvalidSettlementWindow,
    PoolNotRegistered
} from "./CurveYieldHookTypes.sol";

contract CurveYieldHookConfigController is SingletonAuthentication {
    uint64 internal constant _DEFAULT_COMBINED_FEE_CAP = 0.15e18;
    uint32 internal constant _DEFAULT_SETTLEMENT_WINDOW = 30 minutes;
    uint16 internal constant _DEFAULT_SETTLEMENT_SLIPPAGE_BPS = 100;

    mapping(address hook => bool approved) public isApprovedHook;
    mapping(address factory => CurveYieldPoolKind kind) public factoryPoolKind;
    mapping(address pool => CurveYieldPoolKind kind) public registeredPoolKind;
    mapping(address settlementRouter => bool approved) public isSettlementRouter;
    mapping(address pool => uint32 window) public settlementOracleWindow;
    mapping(address pool => uint16 slippageBps) public settlementSlippageBps;
    mapping(address pool => bool enabled) public poolCombinedFeeCapEnabled;
    mapping(address pool => uint64 cap) public poolCombinedFeeCap;

    uint64 public globalCombinedFeeCap;
    bool public protectedSettlementPaused;

    error ZeroAddress();
    error UnauthorizedHook(address hook);

    event ApprovedHookSet(address indexed hook, bool approved);
    event FactoryPoolKindSet(
        address indexed factory,
        CurveYieldPoolKind previousKind,
        CurveYieldPoolKind newKind
    );
    event PoolRegistered(address indexed pool, CurveYieldPoolKind indexed kind);
    event SettlementRouterSet(address indexed settlementRouter, bool approved);
    event GlobalCombinedFeeCapSet(uint256 previousCap, uint256 newCap);
    event PoolCombinedFeeCapSet(address indexed pool, bool enabled, uint256 cap);
    event SettlementOracleConfigSet(address indexed pool, uint32 window, uint16 slippageBps);
    event ProtectedSettlementPauseSet(bool paused);

    modifier onlyApprovedHook() {
        if (!isApprovedHook[msg.sender]) revert UnauthorizedHook(msg.sender);
        _;
    }

    constructor(IVault vault) SingletonAuthentication(vault) {
        globalCombinedFeeCap = _DEFAULT_COMBINED_FEE_CAP;
    }

    function setApprovedHook(address hook, bool approved) external authenticate {
        if (hook == address(0)) revert ZeroAddress();
        isApprovedHook[hook] = approved;
        emit ApprovedHookSet(hook, approved);
    }

    function registerPool(address pool, CurveYieldPoolKind kind) external onlyApprovedHook {
        if (pool == address(0)) revert ZeroAddress();
        registeredPoolKind[pool] = kind;
        settlementOracleWindow[pool] = _DEFAULT_SETTLEMENT_WINDOW;
        settlementSlippageBps[pool] = _DEFAULT_SETTLEMENT_SLIPPAGE_BPS;
        emit PoolRegistered(pool, kind);
    }

    function setFactoryPoolKind(address factory, CurveYieldPoolKind kind) external authenticate {
        if (factory == address(0)) revert ZeroAddress();
        CurveYieldPoolKind previousKind = factoryPoolKind[factory];
        factoryPoolKind[factory] = kind;
        emit FactoryPoolKindSet(factory, previousKind, kind);
    }

    function setSettlementRouter(address settlementRouter, bool approved) external authenticate {
        if (settlementRouter == address(0)) revert ZeroAddress();
        isSettlementRouter[settlementRouter] = approved;
        emit SettlementRouterSet(settlementRouter, approved);
    }

    function setGlobalCombinedFeeCap(uint256 newCap) external authenticate {
        _validateCombinedFeeCap(newCap);
        uint256 previousCap = globalCombinedFeeCap;
        globalCombinedFeeCap = uint64(newCap);
        emit GlobalCombinedFeeCapSet(previousCap, newCap);
    }

    function setPoolCombinedFeeCap(
        address pool,
        bool enabled,
        uint256 newCap
    ) external authenticate {
        _requirePool(pool);
        if (enabled) _validateCombinedFeeCap(newCap);
        poolCombinedFeeCapEnabled[pool] = enabled;
        poolCombinedFeeCap[pool] = uint64(newCap);
        emit PoolCombinedFeeCapSet(pool, enabled, newCap);
    }

    function setSettlementOracleConfig(
        address pool,
        uint32 window,
        uint16 slippageBps
    ) external authenticate {
        _requirePool(pool);
        if (
            window < CurveYieldHookConstants.MIN_SETTLEMENT_WINDOW ||
            window > CurveYieldHookConstants.MAX_SETTLEMENT_WINDOW
        ) {
            revert InvalidSettlementWindow(window);
        }
        if (slippageBps >= 10_000) revert InvalidSettlementSlippage(slippageBps);
        settlementOracleWindow[pool] = window;
        settlementSlippageBps[pool] = slippageBps;
        emit SettlementOracleConfigSet(pool, window, slippageBps);
    }

    function setProtectedSettlementPaused(bool paused) external authenticate {
        protectedSettlementPaused = paused;
        emit ProtectedSettlementPauseSet(paused);
    }

    function effectiveCombinedFeeCap(address pool) external view returns (uint256) {
        return poolCombinedFeeCapEnabled[pool] ? poolCombinedFeeCap[pool] : globalCombinedFeeCap;
    }

    function settlementOracleConfig(address pool) external view returns (uint32 window, uint16 slippageBps) {
        return (settlementOracleWindow[pool], settlementSlippageBps[pool]);
    }

    function _requirePool(address pool) private view {
        if (registeredPoolKind[pool] == CurveYieldPoolKind.NONE) revert PoolNotRegistered(pool);
    }

    function _validateCombinedFeeCap(uint256 cap) private pure {
        if (cap > CurveYieldHookConstants.IMMUTABLE_COMBINED_FEE_HARD_MAX) {
            revert InvalidCombinedFeeCap(cap);
        }
    }
}
