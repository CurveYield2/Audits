// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract supports a CurveYield implementation derived from Balancer's smart contracts.
 * Balancer's gracious use of open-source GPL licensing allows CurveYield to use it for the good of all.
 */

import { CurveYieldPoolKind } from "../hooks/CurveYieldHookTypes.sol";
import { ICurveYieldPoolObservation } from "./ICurveYieldPoolObservation.sol";

interface ICurveYieldCompositeHook is ICurveYieldPoolObservation {
    function setFactoryPoolKind(address factory, CurveYieldPoolKind kind) external;

    function setSettlementRouter(address settlementRouter, bool approved) external;

    function setGlobalCombinedFeeCap(uint256 newCap) external;

    function setPoolCombinedFeeCap(address pool, bool enabled, uint256 newCap) external;

    function setSettlementOracleConfig(address pool, uint32 window, uint16 slippageBps) external;

    function setProtectedSettlementPaused(bool paused) external;

    function queueCreatorVolumeFeeConfig(
        address pool,
        uint256 maxVolumeSurcharge,
        uint8 reactiveness,
        uint8 halfLifeHours
    ) external;

    function cancelCreatorVolumeFeeConfig(address pool) external;

    function executeCreatorVolumeFeeConfig(address pool) external;

    function setPoolVolumeFeeConfigImmediately(
        address pool,
        uint256 maxVolumeSurcharge,
        uint8 reactiveness,
        uint8 halfLifeHours
    ) external;

    function cancelPendingCreatorVolumeFeeConfig(address pool) external;

    function freezeCreatorVolumeFeeConfig(address pool, bool frozen) external;
}
