// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

interface IERC20TransferLike {
    function approve(address spender, uint256 amount) external returns (bool);
    function transfer(address recipient, uint256 amount) external returns (bool);
    function transferFrom(address owner, address recipient, uint256 amount) external returns (bool);
}

library SafeERC20Transfer {
    error SafeERC20CallFailed();
    error SafeERC20CallToNonContract();

    function safeApprove(address token, address spender, uint256 amount) internal {
        _callOptionalReturn(token, abi.encodeCall(IERC20TransferLike.approve, (spender, amount)));
    }

    function safeTransfer(address token, address recipient, uint256 amount) internal {
        _callOptionalReturn(token, abi.encodeCall(IERC20TransferLike.transfer, (recipient, amount)));
    }

    function safeTransferFrom(address token, address owner, address recipient, uint256 amount) internal {
        _callOptionalReturn(token, abi.encodeCall(IERC20TransferLike.transferFrom, (owner, recipient, amount)));
    }

    function _callOptionalReturn(address token, bytes memory data) private {
        if (token.code.length == 0) revert SafeERC20CallToNonContract();

        (bool success, bytes memory returndata) = token.call(data);
        if (!success) {
            assembly {
                revert(add(returndata, 32), mload(returndata))
            }
        }

        if (returndata.length != 0 && !abi.decode(returndata, (bool))) revert SafeERC20CallFailed();
    }
}
