// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import { PoolFeePolicyRegistry } from "./PoolFeePolicyRegistry.sol";
import { Math } from "@openzeppelin/contracts/utils/math/Math.sol";

contract AdminFeeSplitter {
    uint256 private constant BPS = 10_000;

    PoolFeePolicyRegistry public immutable registry;

    error ZeroAddress();
    error AdminFixedObligationsTooHigh();

    constructor(address registry_) {
        if (registry_ == address(0)) revert ZeroAddress();
        registry = PoolFeePolicyRegistry(registry_);
    }

    function quoteAdminAllocation(address pool, uint256[] calldata protocolFeeAmounts)
        external
        view
        returns (
            uint256[] memory adminCreatorPermanentLiquidity,
            uint256[] memory adminExtraPermanentPoL,
            uint256[] memory partnerRevenue,
            uint256[] memory treasury
        )
    {
        PoolFeePolicyRegistry.AdminFeeConfig memory adminConfig = registry.getAdminFeeConfig(pool);
        uint256 length = protocolFeeAmounts.length;

        adminCreatorPermanentLiquidity = new uint256[](length);
        adminExtraPermanentPoL = new uint256[](length);
        partnerRevenue = new uint256[](length);
        treasury = new uint256[](length);

        uint256 fixedObligations = uint256(adminConfig.adminCreatorPermanentLiquidityBps)
            + adminConfig.adminExtraPermanentPoLBps + adminConfig.adminPartnerRevenueBps;
        if (fixedObligations > BPS) {
            revert AdminFixedObligationsTooHigh();
        }

        for (uint256 i = 0; i < length; ++i) {
            (
                adminCreatorPermanentLiquidity[i],
                adminExtraPermanentPoL[i],
                partnerRevenue[i],
                treasury[i]
            ) = _quoteAmount(
                protocolFeeAmounts[i],
                adminConfig.adminCreatorPermanentLiquidityBps,
                adminConfig.adminExtraPermanentPoLBps,
                adminConfig.adminPartnerRevenueBps
            );
        }
    }

    function _quoteAmount(
        uint256 protocolFeeAmount,
        uint256 adminCreatorPermanentLiquidityBps,
        uint256 adminExtraPermanentPoLBps,
        uint256 adminPartnerRevenueBps
    )
        private
        pure
        returns (
            uint256 adminCreatorPermanentLiquidity,
            uint256 adminExtraPermanentPoL,
            uint256 partnerRevenue,
            uint256 treasury
        )
    {
        adminCreatorPermanentLiquidity = Math.mulDiv(
            protocolFeeAmount,
            adminCreatorPermanentLiquidityBps,
            BPS
        );
        adminExtraPermanentPoL = Math.mulDiv(
            protocolFeeAmount,
            adminExtraPermanentPoLBps,
            BPS
        );
        partnerRevenue = Math.mulDiv(
            protocolFeeAmount,
            adminPartnerRevenueBps,
            BPS
        );
        treasury =
            protocolFeeAmount - adminCreatorPermanentLiquidity - adminExtraPermanentPoL - partnerRevenue;
    }
}
