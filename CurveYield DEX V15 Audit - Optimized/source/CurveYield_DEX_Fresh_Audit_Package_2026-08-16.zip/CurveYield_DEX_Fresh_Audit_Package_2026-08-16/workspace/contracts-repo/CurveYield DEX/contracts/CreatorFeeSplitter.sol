// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import { AragonOwned } from "./access/AragonOwned.sol";
import { CurveYieldFeeMath } from "./lib/CurveYieldFeeMath.sol";
import { PoolFeePolicyRegistry } from "./PoolFeePolicyRegistry.sol";
import { IProtocolFeeController } from "./interfaces/IProtocolFeeController.sol";

contract CreatorFeeSplitter is AragonOwned {
    uint256 private constant WAD = 1e18;

    PoolFeePolicyRegistry public immutable registry;
    IProtocolFeeController public immutable protocolFeeController;
    address public immutable pool;
    address public immutable feeSettlementRouter;

    error NotCreatorController();
    error NotFeeSettlementRouter();

    event CreatorSwapFeeSynced(address indexed pool, uint256 creatorSwapFeePercentage);
    event CreatorFeesWithdrawnToSettlementRouter(address indexed pool, address indexed settlementRouter);

    constructor(
        address initialOwner,
        address registry_,
        address protocolFeeController_,
        address feeSettlementRouter_,
        address pool_
    ) AragonOwned(initialOwner) {
        if (
            registry_ == address(0) || protocolFeeController_ == address(0) || feeSettlementRouter_ == address(0)
                || pool_ == address(0)
        ) {
            revert ZeroAddress();
        }

        registry = PoolFeePolicyRegistry(registry_);
        protocolFeeController = IProtocolFeeController(protocolFeeController_);
        feeSettlementRouter = feeSettlementRouter_;
        pool = pool_;
    }

    function setCreatorPayoutReceiver(address newReceiver) external {
        if (msg.sender != registry.creatorControllerOf(pool)) revert NotCreatorController();
        registry.setCreatorPayoutReceiverFromSplitter(pool, msg.sender, newReceiver);
    }

    function creatorController() external view returns (address) {
        return registry.creatorControllerOf(pool);
    }

    function creatorPayoutReceiver() external view returns (address) {
        return registry.creatorPayoutReceiverOf(pool);
    }

    function syncCreatorSwapFee() external {
        uint256 totalBps = _creatorTotalBps();
        uint256 creatorSwapFeePercentage = (totalBps * WAD) / CurveYieldFeeMath.BPS;
        protocolFeeController.setPoolCreatorSwapFeePercentage(pool, creatorSwapFeePercentage);
        emit CreatorSwapFeeSynced(pool, creatorSwapFeePercentage);
    }

    function withdrawCreatorFeesToSettlementRouter() external {
        if (msg.sender != feeSettlementRouter) revert NotFeeSettlementRouter();
        protocolFeeController.withdrawPoolCreatorFees(pool, feeSettlementRouter);
        emit CreatorFeesWithdrawnToSettlementRouter(pool, feeSettlementRouter);
    }

    function quoteCreatorAllocation(uint256[] calldata feeAmounts)
        external
        view
        returns (
            uint256[] memory creatorPayout,
            uint256[] memory adminCut,
            uint256[] memory permanentLiquidity,
            uint256[] memory partnerPayout,
            uint256[] memory partnerAdminCut
        )
    {
        PoolFeePolicyRegistry.CreatorFeeConfig memory config = registry.getCreatorFeeConfig(pool);
        uint256 totalBps = CurveYieldFeeMath.creatorTotalBps(
            config.creatorPersonalBps,
            config.creatorPermanentLiquidityBps,
            config.creatorPartnerRevenueBps
        );

        uint256 length = feeAmounts.length;
        creatorPayout = new uint256[](length);
        adminCut = new uint256[](length);
        permanentLiquidity = new uint256[](length);
        partnerPayout = new uint256[](length);
        partnerAdminCut = new uint256[](length);

        if (totalBps == 0) {
            return (creatorPayout, adminCut, permanentLiquidity, partnerPayout, partnerAdminCut);
        }

        for (uint256 i = 0; i < length; ++i) {
            uint256 personalAmount = (feeAmounts[i] * config.creatorPersonalBps) / totalBps;
            uint256 partnerAmount = (feeAmounts[i] * config.creatorPartnerRevenueBps) / totalBps;

            (creatorPayout[i], adminCut[i]) = CurveYieldFeeMath.splitWithAdminCut(personalAmount);
            permanentLiquidity[i] = (feeAmounts[i] * config.creatorPermanentLiquidityBps) / totalBps;
            (partnerPayout[i], partnerAdminCut[i]) = CurveYieldFeeMath.splitWithAdminCut(partnerAmount);
        }
    }

    function _creatorTotalBps() private view returns (uint256) {
        PoolFeePolicyRegistry.CreatorFeeConfig memory config = registry.getCreatorFeeConfig(pool);
        return CurveYieldFeeMath.creatorTotalBps(
            config.creatorPersonalBps,
            config.creatorPermanentLiquidityBps,
            config.creatorPartnerRevenueBps
        );
    }
}
