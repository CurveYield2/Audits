// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import { IAuthorizer } from "@balancer-labs/v3-interfaces/contracts/vault/IAuthorizer.sol";

/**
 * @notice Minimal deployment-only Balancer V3 authorizer.
 * @dev This is used only to bootstrap a fresh Vault so the real TimelockAuthorizer can be deployed
 * after the Vault exists. It grants every action to a single immutable bootstrap root and should be
 * replaced by TimelockAuthorizer during the same deployment/configuration run.
 */
contract CurveYieldBootstrapAuthorizer is IAuthorizer {
    address public immutable bootstrapRoot;

    error ZeroAddress();

    constructor(address bootstrapRoot_) {
        if (bootstrapRoot_ == address(0)) revert ZeroAddress();
        bootstrapRoot = bootstrapRoot_;
    }

    function canPerform(bytes32, address account, address) external view returns (bool) {
        return account == bootstrapRoot;
    }
}
