// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract is derived from Balancer's pool and time-weighted oracle architecture.
 * Balancer's gracious use of open-source GPL licensing allows CurveYield to use it for the good of all.
 */

import { IERC20 } from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

import { IWeightedPool } from "@balancer-labs/v3-interfaces/contracts/pool-weighted/IWeightedPool.sol";
import { IVault } from "@balancer-labs/v3-interfaces/contracts/vault/IVault.sol";
import { TokenConfig } from "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";
import { FixedPoint } from "@balancer-labs/v3-solidity-utils/contracts/math/FixedPoint.sol";
import { LogExpMath } from "@balancer-labs/v3-solidity-utils/contracts/math/LogExpMath.sol";
import { VaultGuard } from "@balancer-labs/v3-vault/contracts/VaultGuard.sol";

import {
    CurveYieldHookConstants,
    CurveYieldPoolKind,
    InvalidObservationArrayLength,
    InvalidPoolKind,
    InvalidSettlementSlippage,
    InvalidSettlementWindow,
    InvalidTokenCount,
    Observation,
    ObservationNotInitialized,
    ObservationNotWarm,
    ObservationState,
    PoolAlreadyRegistered,
    PoolNotRegistered
} from "./CurveYieldHookTypes.sol";
import { ObservationQueryProcessor } from "./ObservationQueryProcessor.sol";

abstract contract PoolObservation is VaultGuard {
    uint256 private constant _MAX_OBSERVATIONS = 512;

    mapping(address pool => ObservationState state) internal _observationStates;
    mapping(address pool => Observation[512] observations) internal _poolObservations;
    mapping(address pool => CurveYieldPoolKind kind) internal _observationPoolKinds;
    mapping(address pool => uint8 tokenCount) internal _observationTokenCounts;
    mapping(address pool => address[8] tokens) internal _observationTokens;
    mapping(address pool => uint64[8] normalizedWeights) internal _observationNormalizedWeights;
    mapping(address pool => address factory) internal _observationFactories;

    error ObservationAlreadyInitialized(address pool);
    error ObservationPoolIsNotInitialized(address pool);
    error ObservationTimestampRegression(uint48 supplied, uint48 lastTimestamp);
    error ObservationValueDoesNotFitInt128(int256 value);
    error ObservationValueDoesNotFitInt256(uint256 value);
    error ObservationTotalSupplyIsZero(address pool);
    error ObservationBalancePerBptIsZero(address pool, uint256 tokenIndex);
    error InvalidNormalizedWeight(address pool, uint256 tokenIndex, uint256 weight);
    error InvalidNormalizedWeightSum(address pool, uint256 sum);

    constructor(IVault vault) VaultGuard(vault) {}

    function _registerObservationPool(
        address factory,
        address pool,
        TokenConfig[] memory tokenConfig,
        CurveYieldPoolKind kind
    ) internal {
        if (_observationTokenCounts[pool] != 0) revert PoolAlreadyRegistered(pool);
        if (
            kind != CurveYieldPoolKind.WEIGHTED &&
            kind != CurveYieldPoolKind.STABLE &&
            kind != CurveYieldPoolKind.STABLE_SURGE
        ) {
            revert InvalidPoolKind(kind);
        }

        uint256 tokenCount = tokenConfig.length;
        if (tokenCount < 2 || tokenCount > 8) revert InvalidTokenCount(tokenCount);

        _observationFactories[pool] = factory;
        _observationPoolKinds[pool] = kind;
        _observationTokenCounts[pool] = uint8(tokenCount);
        for (uint256 i = 0; i < tokenCount; ++i) {
            _observationTokens[pool][i] = address(tokenConfig[i].token);
        }

        if (kind == CurveYieldPoolKind.WEIGHTED) {
            uint256[] memory normalizedWeights = IWeightedPool(pool).getNormalizedWeights();
            if (normalizedWeights.length != tokenCount) {
                revert InvalidObservationArrayLength(normalizedWeights.length, tokenCount);
            }

            uint256 totalWeight;
            for (uint256 i = 0; i < tokenCount; ++i) {
                uint256 weight = normalizedWeights[i];
                if (weight > type(uint64).max) revert InvalidNormalizedWeight(pool, i, weight);
                _observationNormalizedWeights[pool][i] = uint64(weight);
                totalWeight += weight;
            }
            if (totalWeight != 1e18) revert InvalidNormalizedWeightSum(pool, totalWeight);
        }
    }

    function _initializeObservation(address pool) internal {
        _ensurePoolRegistered(pool);
        if (!_vault.isPoolInitialized(pool)) revert ObservationPoolIsNotInitialized(pool);

        _initializeObservationAt(
            pool,
            _vault.getCurrentLiveBalances(pool),
            IERC20(pool).totalSupply(),
            _currentTimestamp()
        );
    }

    function _initializeObservationAt(
        address pool,
        uint256[] memory balancesScaled18,
        uint256 totalBptSupply,
        uint48 timestamp
    ) internal {
        uint8 tokenCount = _ensurePoolRegistered(pool);
        ObservationState storage state = _observationStates[pool];
        if (state.initialized) revert ObservationAlreadyInitialized(pool);

        int128[8] memory instantLogs = _computeInstantLogs(
            pool,
            balancesScaled18,
            totalBptSupply,
            tokenCount
        );

        state.index = 0;
        state.cardinality = 1;
        state.initializedAt = timestamp;
        state.lastTimestamp = timestamp;
        state.lastSampleTimestamp = timestamp;
        state.initialized = true;
        state.instantLogs = instantLogs;

        Observation storage initialObservation = _poolObservations[pool][0];
        initialObservation.timestamp = timestamp;
        initialObservation.cumulativeLogs = state.cumulativeLogs;
    }

    function _observeBefore(address pool, uint256[] memory balancesScaled18) internal {
        _observeAt(pool, balancesScaled18, IERC20(pool).totalSupply(), _currentTimestamp());
    }

    function _observeAfter(address pool, uint256[] memory balancesScaled18) internal {
        _observeAt(pool, balancesScaled18, IERC20(pool).totalSupply(), _currentTimestamp());
    }

    function _observeAt(
        address pool,
        uint256[] memory balancesScaled18,
        uint256 totalBptSupply,
        uint48 timestamp
    ) internal {
        if (_observationStates[pool].initialized) {
            _installObservationAt(pool, balancesScaled18, totalBptSupply, timestamp);
        } else {
            _initializeObservationAt(pool, balancesScaled18, totalBptSupply, timestamp);
        }
    }

    function _installObservationAt(
        address pool,
        uint256[] memory balancesScaled18,
        uint256 totalBptSupply,
        uint48 timestamp
    ) internal {
        uint8 tokenCount = _ensurePoolRegistered(pool);
        ObservationState storage state = _observationStates[pool];
        if (!state.initialized) revert ObservationNotInitialized(pool);
        if (timestamp < state.lastTimestamp) {
            revert ObservationTimestampRegression(timestamp, state.lastTimestamp);
        }

        int128[8] memory nextInstantLogs = _computeInstantLogs(
            pool,
            balancesScaled18,
            totalBptSupply,
            tokenCount
        );
        _accrue(state, tokenCount, timestamp);
        state.instantLogs = nextInstantLogs;

        if (timestamp - state.lastSampleTimestamp >= CurveYieldHookConstants.MIN_OBSERVATION_SPACING) {
            _storeObservation(pool, state, timestamp);
        }
    }

    function _checkpoint(address pool) internal {
        _ensurePoolRegistered(pool);
        if (!_vault.isPoolInitialized(pool)) revert ObservationPoolIsNotInitialized(pool);

        _installObservationAt(
            pool,
            _vault.getCurrentLiveBalances(pool),
            IERC20(pool).totalSupply(),
            _currentTimestamp()
        );
    }

    function _checkpointAt(
        address pool,
        uint256[] memory balancesScaled18,
        uint256 totalBptSupply,
        uint48 timestamp
    ) internal {
        _installObservationAt(pool, balancesScaled18, totalBptSupply, timestamp);
    }

    function _getTimeWeightedBalancesPerBpt(
        address pool,
        uint32 secondsAgo
    ) internal view returns (uint256[] memory balancesPerBpt) {
        return _getTimeWeightedBalancesPerBptAt(pool, _currentTimestamp(), secondsAgo);
    }

    function _getTimeWeightedBalancesPerBptAt(
        address pool,
        uint48 currentTimestamp,
        uint32 secondsAgo
    ) internal view returns (uint256[] memory balancesPerBpt) {
        uint8 tokenCount = _ensurePoolRegistered(pool);
        return ObservationQueryProcessor.getTimeWeightedBalancesPerBptAt(
            _poolObservations[pool],
            _observationStates[pool],
            tokenCount,
            pool,
            currentTimestamp,
            secondsAgo
        );
    }

    function _isObservationWarm(address pool) internal view returns (bool) {
        ObservationState storage state = _observationStates[pool];
        return
            state.initialized &&
            block.timestamp >= uint256(state.initializedAt) + CurveYieldHookConstants.OBSERVATION_WARM_UP;
    }

    function _quoteOracleProtectedBptOut(
        address pool,
        uint256[] memory exactAmountsInRaw,
        uint32 window,
        uint16 slippageBps
    ) internal view returns (uint256 expectedBptOut, uint256 minBptOut) {
        uint8 tokenCount = _validateOracleQuote(
            pool,
            exactAmountsInRaw.length,
            window,
            slippageBps
        );
        return ObservationQueryProcessor.quoteOracleProtectedBptOutAt(
            _poolObservations[pool],
            _observationStates[pool],
            tokenCount,
            pool,
            _vault,
            _currentTimestamp(),
            window,
            slippageBps,
            exactAmountsInRaw
        );
    }

    function _quoteOracleProtectedBptOutScaled18(
        address pool,
        uint256[] memory exactAmountsInScaled18,
        uint32 window,
        uint16 slippageBps
    ) internal view returns (uint256 expectedBptOut, uint256 minBptOut) {
        uint8 tokenCount = _validateOracleQuote(
            pool,
            exactAmountsInScaled18.length,
            window,
            slippageBps
        );
        return ObservationQueryProcessor.quoteOracleProtectedBptOutScaled18At(
            _poolObservations[pool],
            _observationStates[pool],
            tokenCount,
            pool,
            _vault,
            _currentTimestamp(),
            window,
            slippageBps,
            exactAmountsInScaled18
        );
    }

    function _quoteOracleProtectedSwapOut(
        address pool,
        address tokenIn,
        address tokenOut,
        uint256 amountInRaw,
        uint32 window,
        uint16 slippageBps,
        uint256 swapFeePercentage
    ) internal view returns (uint256 expectedAmountOut, uint256 minAmountOut) {
        uint8 tokenCount = _ensurePoolRegistered(pool);
        _validateOracleQuote(
            pool,
            tokenCount,
            window,
            slippageBps
        );
        return ObservationQueryProcessor.quoteOracleProtectedSwapOutAt(
            _poolObservations[pool],
            _observationStates[pool],
            tokenCount,
            pool,
            _vault,
            _currentTimestamp(),
            window,
            slippageBps,
            tokenIn,
            tokenOut,
            amountInRaw,
            swapFeePercentage
        );
    }

    function _validateOracleQuote(
        address pool,
        uint256 amountCount,
        uint32 window,
        uint16 slippageBps
    ) private view returns (uint8 tokenCount) {
        tokenCount = _ensurePoolRegistered(pool);
        if (amountCount != tokenCount) {
            revert InvalidObservationArrayLength(amountCount, tokenCount);
        }

        ObservationState storage state = _observationStates[pool];
        if (!state.initialized) revert ObservationNotInitialized(pool);
        if (!_isObservationWarm(pool)) revert ObservationNotWarm(pool);
        if (
            window < CurveYieldHookConstants.MIN_SETTLEMENT_WINDOW ||
            window > CurveYieldHookConstants.MAX_SETTLEMENT_WINDOW
        ) {
            revert InvalidSettlementWindow(window);
        }
        if (slippageBps >= 10_000) {
            revert InvalidSettlementSlippage(slippageBps);
        }
    }

    function _computeInstantLogs(
        address pool,
        uint256[] memory balancesScaled18,
        uint256 totalBptSupply,
        uint8 tokenCount
    ) private pure returns (int128[8] memory instantLogs) {
        if (balancesScaled18.length != tokenCount) {
            revert InvalidObservationArrayLength(balancesScaled18.length, tokenCount);
        }
        if (totalBptSupply == 0) revert ObservationTotalSupplyIsZero(pool);

        for (uint256 i = 0; i < tokenCount; ++i) {
            uint256 balancePerBpt = FixedPoint.divDown(balancesScaled18[i], totalBptSupply);
            if (balancePerBpt == 0) revert ObservationBalancePerBptIsZero(pool, i);
            if (balancePerBpt > uint256(type(int256).max)) {
                revert ObservationValueDoesNotFitInt256(balancePerBpt);
            }
            instantLogs[i] = _toInt128(LogExpMath.ln(int256(balancePerBpt)));
        }
    }

    function _accrue(
        ObservationState storage state,
        uint8 tokenCount,
        uint48 timestamp
    ) private {
        uint48 elapsed = timestamp - state.lastTimestamp;
        for (uint256 i = 0; i < tokenCount; ++i) {
            int256 cumulative = int256(state.cumulativeLogs[i]) +
                int256(state.instantLogs[i]) *
                int256(uint256(elapsed));
            state.cumulativeLogs[i] = _toInt128(cumulative);
        }
        state.lastTimestamp = timestamp;
    }

    function _storeObservation(
        address pool,
        ObservationState storage state,
        uint48 timestamp
    ) private {
        uint16 nextIndex = uint16((uint256(state.index) + 1) % _MAX_OBSERVATIONS);
        state.index = nextIndex;
        if (state.cardinality < _MAX_OBSERVATIONS) {
            ++state.cardinality;
        }
        state.lastSampleTimestamp = timestamp;

        Observation storage sample = _poolObservations[pool][nextIndex];
        sample.timestamp = timestamp;
        sample.cumulativeLogs = state.cumulativeLogs;
    }

    function _ensurePoolRegistered(address pool) private view returns (uint8 tokenCount) {
        tokenCount = _observationTokenCounts[pool];
        if (tokenCount == 0) revert PoolNotRegistered(pool);
    }

    function _toInt128(int256 value) private pure returns (int128) {
        if (value < type(int128).min || value > type(int128).max) {
            revert ObservationValueDoesNotFitInt128(value);
        }
        return int128(value);
    }

    function _currentTimestamp() private view returns (uint48) {
        return uint48(block.timestamp);
    }
}
