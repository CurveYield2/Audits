// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract is a fork of Balancer's StableSurgeHook and SurgeHookCommon combined with CurveYield
 * volume and oracle logic. Balancer's gracious use of open-source GPL licensing allows CurveYield to
 * use it for the good of all.
 */

import { Math } from "@openzeppelin/contracts/utils/math/Math.sol";
import { SafeCast } from "@openzeppelin/contracts/utils/math/SafeCast.sol";

import {
    IBalancerContractRegistry
} from "@balancer-labs/v3-interfaces/contracts/standalone-utils/IBalancerContractRegistry.sol";
import {
    ISurgeHookCommon
} from "@balancer-labs/v3-interfaces/contracts/pool-hooks/ISurgeHookCommon.sol";
import { IVault } from "@balancer-labs/v3-interfaces/contracts/vault/IVault.sol";
import {
    AddLiquidityKind,
    AfterSwapParams,
    HookFlags,
    LiquidityManagement,
    PoolSwapParams,
    RemoveLiquidityKind,
    SwapKind,
    TokenConfig
} from "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";

import {
    ScalingHelpers
} from "@balancer-labs/v3-solidity-utils/contracts/helpers/ScalingHelpers.sol";
import { Version } from "@balancer-labs/v3-solidity-utils/contracts/helpers/Version.sol";
import { FixedPoint } from "@balancer-labs/v3-solidity-utils/contracts/math/FixedPoint.sol";

import { PoolFeePolicyRegistry } from "../PoolFeePolicyRegistry.sol";
import { CurveYieldCompositeHookBaseV14 } from "./CurveYieldCompositeHookBaseV14.sol";
import { CurveYieldHookConfigController } from "./CurveYieldHookConfigController.sol";
import {
    CurveYieldObservationController
} from "./CurveYieldObservationController.sol";
import {
    CurveYieldVolumeFeeController
} from "./CurveYieldVolumeFeeController.sol";
import { CurveYieldPoolKind } from "./CurveYieldHookTypes.sol";
import { StableSurgeQueryProcessor } from "./StableSurgeQueryProcessor.sol";

contract CurveYieldStableSurgeVolumeHookV14 is
    CurveYieldCompositeHookBaseV14,
    ISurgeHookCommon,
    Version
{
    using SafeCast for *;

    uint256 private immutable _defaultMaxSurgeFeePercentage;
    uint256 private immutable _defaultSurgeThresholdPercentage;

    mapping(address pool => SurgeFeeData data) internal _surgeFeePoolData;
    mapping(address pool => bool inProgress) private _protectedSettlementAddInProgress;

    event StableSurgeHookRegistered(address indexed pool, address indexed factory);

    modifier withValidPercentage(uint256 percentageValue) {
        _ensureValidPercentage(percentageValue);
        _;
    }

    constructor(
        IVault vault,
        IBalancerContractRegistry registry,
        PoolFeePolicyRegistry poolFeePolicyRegistry,
        CurveYieldHookConfigController hookConfigController,
        CurveYieldObservationController observationController,
        CurveYieldVolumeFeeController volumeFeeController,
        uint256 defaultMaxSurgeFeePercentage,
        uint256 defaultSurgeThresholdPercentage,
        string memory version
    )
        CurveYieldCompositeHookBaseV14(
            vault,
            registry,
            poolFeePolicyRegistry,
            hookConfigController,
            observationController,
            volumeFeeController
        )
        Version(version)
    {
        _ensureValidPercentage(defaultMaxSurgeFeePercentage);
        _ensureValidPercentage(defaultSurgeThresholdPercentage);
        _defaultMaxSurgeFeePercentage = defaultMaxSurgeFeePercentage;
        _defaultSurgeThresholdPercentage = defaultSurgeThresholdPercentage;
    }

    function onRegister(
        address factory,
        address pool,
        TokenConfig[] memory tokenConfig,
        LiquidityManagement calldata liquidityManagement
    ) public override returns (bool) {
        bool registered = super.onRegister(
            factory,
            pool,
            tokenConfig,
            liquidityManagement
        );
        _setMaxSurgeFeePercentage(pool, _defaultMaxSurgeFeePercentage);
        _setSurgeThresholdPercentage(pool, _defaultSurgeThresholdPercentage);
        emit StableSurgeHookRegistered(pool, factory);
        return registered;
    }

    function getHookFlags() public pure override returns (HookFlags memory hookFlags) {
        hookFlags.shouldCallComputeDynamicSwapFee = true;
        hookFlags.shouldCallBeforeSwap = true;
        hookFlags.shouldCallAfterSwap = true;
        hookFlags.shouldCallBeforeAddLiquidity = true;
        hookFlags.shouldCallAfterAddLiquidity = true;
        hookFlags.shouldCallBeforeRemoveLiquidity = true;
        hookFlags.shouldCallAfterRemoveLiquidity = true;
    }

    function onBeforeSwap(
        PoolSwapParams calldata params,
        address pool
    ) public override onlyVault returns (bool) {
        _observe(pool, params.balancesScaled18);
        uint256 selectedTokenIndex = params.kind == SwapKind.EXACT_IN
            ? params.indexIn
            : params.indexOut;
        _recordSwapActivity(
            pool,
            params.amountGivenScaled18,
            selectedTokenIndex,
            params.balancesScaled18
        );
        return true;
    }

    function onAfterSwap(
        AfterSwapParams calldata params
    ) public override onlyVault returns (bool, uint256) {
        _observe(params.pool, _vault.getCurrentLiveBalances(params.pool));
        return (true, params.amountCalculatedRaw);
    }

    function onComputeDynamicSwapFeePercentage(
        PoolSwapParams calldata params,
        address pool,
        uint256 staticSwapFeePercentage
    ) public view override returns (bool, uint256) {
        uint256 upstreamDynamic = computeSwapSurgeFeePercentage(
            params,
            pool,
            staticSwapFeePercentage
        );
        uint256 imbalanceSurcharge = upstreamDynamic > staticSwapFeePercentage
            ? upstreamDynamic - staticSwapFeePercentage
            : 0;
        uint256 volumeSurcharge = _currentVolumeSurcharge(pool);
        uint256 combined =
            staticSwapFeePercentage + imbalanceSurcharge + volumeSurcharge;
        uint256 capped = Math.min(combined, _hookConfigController.effectiveCombinedFeeCap(pool));
        return (true, Math.max(staticSwapFeePercentage, capped));
    }

    function _computeSettlementSwapFeePercentage(
        PoolSwapParams memory params,
        address pool,
        uint256 staticSwapFeePercentage,
        address
    ) internal view override returns (uint256) {
        uint256 upstreamDynamic = StableSurgeQueryProcessor.computeSwapSurgeFeePercentageMemory(
            params,
            pool,
            staticSwapFeePercentage,
            _surgeFeePoolData[pool]
        );
        uint256 imbalanceSurcharge = upstreamDynamic > staticSwapFeePercentage
            ? upstreamDynamic - staticSwapFeePercentage
            : 0;
        uint256 selectedTokenIndex = params.kind == SwapKind.EXACT_IN
            ? params.indexIn
            : params.indexOut;
        uint256 volumeSurcharge = _previewVolumeSurcharge(
            pool,
            params.amountGivenScaled18,
            selectedTokenIndex,
            params.balancesScaled18
        );
        uint256 combined =
            staticSwapFeePercentage + imbalanceSurcharge + volumeSurcharge;
        uint256 capped = Math.min(combined, _hookConfigController.effectiveCombinedFeeCap(pool));
        return Math.max(staticSwapFeePercentage, capped);
    }

    function onBeforeAddLiquidity(
        address router,
        address pool,
        AddLiquidityKind kind,
        uint256[] memory maxAmountsInScaled18,
        uint256 minBptAmountOut,
        uint256[] memory balancesScaled18,
        bytes memory
    ) public override onlyVault returns (bool) {
        _observe(pool, balancesScaled18);
        _validateProtectedSettlementAdd(
            router,
            pool,
            kind,
            maxAmountsInScaled18,
            minBptAmountOut
        );
        if (kind == AddLiquidityKind.UNBALANCED && _isProtectedSettlementCaller(router)) {
            _protectedSettlementAddInProgress[pool] = true;
        }
        return true;
    }

    function onAfterAddLiquidity(
        address,
        address pool,
        AddLiquidityKind kind,
        uint256[] memory amountsInScaled18,
        uint256[] memory amountsInRaw,
        uint256,
        uint256[] memory balancesScaled18,
        bytes memory
    ) public override onlyVault returns (bool success, uint256[] memory) {
        if (kind == AddLiquidityKind.PROPORTIONAL) {
            _observe(pool, balancesScaled18);
            return (true, amountsInRaw);
        }
        if (_protectedSettlementAddInProgress[pool]) {
            _protectedSettlementAddInProgress[pool] = false;
            _observe(pool, balancesScaled18);
            return (true, amountsInRaw);
        }

        uint256[] memory observationBalances = _copyBalances(balancesScaled18);
        uint256[] memory oldBalancesScaled18 = new uint256[](balancesScaled18.length);
        for (uint256 i = 0; i < balancesScaled18.length; ++i) {
            oldBalancesScaled18[i] = balancesScaled18[i] - amountsInScaled18[i];
        }

        bool isSurging = _isSurgingUnbalancedLiquidity(
            pool,
            oldBalancesScaled18,
            balancesScaled18
        );
        success = !isSurging;
        if (success) _observe(pool, observationBalances);
        return (success, amountsInRaw);
    }

    function onBeforeRemoveLiquidity(
        address,
        address pool,
        RemoveLiquidityKind,
        uint256,
        uint256[] memory,
        uint256[] memory balancesScaled18,
        bytes memory
    ) public override onlyVault returns (bool) {
        _observe(pool, balancesScaled18);
        return true;
    }

    function onAfterRemoveLiquidity(
        address,
        address pool,
        RemoveLiquidityKind kind,
        uint256,
        uint256[] memory amountsOutScaled18,
        uint256[] memory amountsOutRaw,
        uint256[] memory balancesScaled18,
        bytes memory
    ) public override onlyVault returns (bool success, uint256[] memory) {
        if (kind == RemoveLiquidityKind.PROPORTIONAL) {
            _observe(pool, balancesScaled18);
            return (true, amountsOutRaw);
        }

        uint256[] memory observationBalances = _copyBalances(balancesScaled18);
        uint256[] memory oldBalancesScaled18 = new uint256[](balancesScaled18.length);
        for (uint256 i = 0; i < balancesScaled18.length; ++i) {
            oldBalancesScaled18[i] = balancesScaled18[i] + amountsOutScaled18[i];
        }

        bool isSurging = _isSurgingUnbalancedLiquidity(
            pool,
            oldBalancesScaled18,
            balancesScaled18
        );
        success = !isSurging;
        if (success) _observe(pool, observationBalances);
        return (success, amountsOutRaw);
    }

    function computeSwapSurgeFeePercentage(
        PoolSwapParams calldata params,
        address pool,
        uint256 staticSwapFeePercentage
    ) public view returns (uint256 surgeFeePercentage) {
        return StableSurgeQueryProcessor.computeSwapSurgeFeePercentage(
            params,
            pool,
            staticSwapFeePercentage,
            _surgeFeePoolData[pool]
        );
    }

    function isSurgingSwap(
        PoolSwapParams calldata params,
        address pool,
        uint256 staticSwapFeePercentage
    ) external view returns (bool isSurging) {
        return StableSurgeQueryProcessor.isSurgingSwap(
            params,
            pool,
            staticSwapFeePercentage,
            _surgeFeePoolData[pool]
        );
    }

    function getDefaultMaxSurgeFeePercentage() external view returns (uint256) {
        return _defaultMaxSurgeFeePercentage;
    }

    function getDefaultSurgeThresholdPercentage() external view returns (uint256) {
        return _defaultSurgeThresholdPercentage;
    }

    function getMaxSurgeFeePercentage(address pool) external view returns (uint256) {
        return _surgeFeePoolData[pool].maxSurgeFeePercentage;
    }

    function getSurgeThresholdPercentage(address pool) external view returns (uint256) {
        return _surgeFeePoolData[pool].thresholdPercentage;
    }

    function setMaxSurgeFeePercentage(
        address pool,
        uint256 newMaxSurgeFeePercentage
    )
        external
        withValidPercentage(newMaxSurgeFeePercentage)
        onlySwapFeeManagerOrGovernance(pool)
    {
        _setMaxSurgeFeePercentage(pool, newMaxSurgeFeePercentage);
    }

    function setSurgeThresholdPercentage(
        address pool,
        uint256 newSurgeThresholdPercentage
    )
        external
        withValidPercentage(newSurgeThresholdPercentage)
        onlySwapFeeManagerOrGovernance(pool)
    {
        _setSurgeThresholdPercentage(pool, newSurgeThresholdPercentage);
    }

    function getSurgeFeePercentage(
        PoolSwapParams calldata params,
        address pool,
        uint256 staticSwapFeePercentage
    ) public view returns (uint256 surgeFeePercentage) {
        return computeSwapSurgeFeePercentage(params, pool, staticSwapFeePercentage);
    }

    function _supportsPoolKind(
        CurveYieldPoolKind kind
    ) internal pure override returns (bool) {
        return kind == CurveYieldPoolKind.STABLE_SURGE;
    }

    function _isSurgingUnbalancedLiquidity(
        address pool,
        uint256[] memory oldBalancesScaled18,
        uint256[] memory balancesScaled18
    ) internal view returns (bool isSurging) {
        SurgeFeeData memory surgeFeeData = _surgeFeePoolData[pool];
        return StableSurgeQueryProcessor.isSurgingUnbalancedLiquidity(
            surgeFeeData.thresholdPercentage,
            oldBalancesScaled18,
            balancesScaled18
        );
    }

    function _setMaxSurgeFeePercentage(
        address pool,
        uint256 newMaxSurgeFeePercentage
    ) internal {
        _surgeFeePoolData[pool].maxSurgeFeePercentage = newMaxSurgeFeePercentage
            .toUint64();
        emit MaxSurgeFeePercentageChanged(pool, newMaxSurgeFeePercentage);
    }

    function _setSurgeThresholdPercentage(
        address pool,
        uint256 newSurgeThresholdPercentage
    ) internal {
        _surgeFeePoolData[pool].thresholdPercentage = newSurgeThresholdPercentage
            .toUint64();
        emit ThresholdSurgePercentageChanged(pool, newSurgeThresholdPercentage);
    }

    function _ensureValidPercentage(uint256 percentage) private pure {
        if (percentage > FixedPoint.ONE) revert InvalidPercentage();
    }

    function _copyBalances(
        uint256[] memory balances
    ) private pure returns (uint256[] memory copiedBalances) {
        copiedBalances = new uint256[](balances.length);
        ScalingHelpers.copyToArray(balances, copiedBalances);
    }
}
