// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import { AragonOwned } from "./access/AragonOwned.sol";
import { AdminFeeSplitter } from "./AdminFeeSplitter.sol";
import { CreatorFeeSplitter } from "./CreatorFeeSplitter.sol";
import { IBalancerV3Router } from "./interfaces/IBalancerV3Router.sol";
import { IBalancerV3Vault } from "./interfaces/IBalancerV3Vault.sol";
import { ICurveYieldPoolObservation } from "./interfaces/ICurveYieldPoolObservation.sol";
import { IProtocolFeeController } from "./interfaces/IProtocolFeeController.sol";
import { PermanentLiquidityVaultV2 } from "./PermanentLiquidityVaultV2.sol";
import { PoolFeePolicyRegistry } from "./PoolFeePolicyRegistry.sol";
import { SafeERC20Transfer } from "./utils/SafeERC20Transfer.sol";
import { HooksConfig } from "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";
import { ReentrancyGuard } from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

interface IERC20Settlement {
    function balanceOf(address account) external view returns (uint256);
}

interface IPermit2SettlementApprove {
    function approve(address token, address spender, uint160 amount, uint48 expiration) external;
}

contract FeeSettlementRouter is AragonOwned, ReentrancyGuard {
    uint8 private constant PHASE_CLAIM = 1;
    uint8 private constant PHASE_CREATOR_PERMANENT_LIQUIDITY = 2;
    uint8 private constant PHASE_PARTNER_POL = 3;
    uint8 private constant PHASE_NORMAL_PAYOUTS = 4;
    uint8 private constant PHASE_DUST = 5;
    uint8 private constant PARTNER_ROLE_CREATOR = 1;
    uint8 private constant PARTNER_ROLE_ADMIN = 2;

    IProtocolFeeController public immutable protocolFeeController;
    AdminFeeSplitter public immutable adminFeeSplitter;
    PermanentLiquidityVaultV2 public immutable permanentLiquidityVault;
    IBalancerV3Vault public immutable vault;
    IBalancerV3Router public immutable liquidityRouter;

    address public treasuryReceiver;
    address public feeConverterStorage;
    address public defaultPayoutToken;

    mapping(address => bool) public isKeeper;
    mapping(address => bool) public isCreatorFeeSplitterRegistrar;
    mapping(address => address) public creatorFeeSplitterOf;
    mapping(address => address) public creatorPayoutTokenOverride;
    mapping(address => mapping(address => address)) public payoutTokenOverride;
    mapping(address => mapping(uint8 => address)) public partnerPayoutTokenOverride;
    mapping(address => bool) public isProtectedBptSettlementHook;
    mapping(address => mapping(address => uint256)) public poolDust;
    mapping(address => uint256) public totalAccountedDust;

    error UnauthorizedCollector();
    error UnauthorizedCreatorFeeSplitterRegistrar();
    error MissingCreatorFeeSplitter();
    error PartnerPoLUnavailable();
    error MissingPayoutReceiver();
    error MissingPayoutToken();
    error Permit2AmountOverflow();
    error ZeroQuote();
    error DustAmountTooHigh();
    error AccountedDustInvariant();
    error ArrayLengthMismatch();
    error NotSelfCall();
    error InvalidPartnerRole(uint8 partnerRole);

    event KeeperUpdated(address indexed keeper, bool approved);
    event CreatorFeeSplitterRegistrarUpdated(address indexed registrar, bool approved);
    event CreatorFeeSplitterUpdated(address indexed pool, address indexed splitter);
    event TreasuryReceiverUpdated(address indexed previousReceiver, address indexed newReceiver);
    event FeeConverterStorageUpdated(address indexed previousStorage, address indexed newStorage);
    event DefaultPayoutTokenUpdated(address indexed previousToken, address indexed newToken);
    event PayoutTokenOverrideUpdated(address indexed pool, address indexed receiver, address indexed previousToken, address newToken);
    event CreatorPayoutTokenOverrideUpdated(address indexed pool, address indexed previousToken, address newToken);
    event PartnerPayoutTokenOverrideUpdated(address indexed pool, uint8 indexed partnerRole, address indexed previousToken, address newToken);
    event FeePayout(address indexed pool, address indexed receiver, address indexed payoutToken, uint256 amount);
    event DustStored(address indexed pool, address indexed token, uint256 amount, uint256 poolTotal);
    event DustReconciled(address indexed pool, address indexed token, uint256 amount, address indexed treasury);
    event UnaccountedTokenRecovered(address indexed token, address indexed receiver, uint256 amount);
    event ProtectedBptSettlementHookUpdated(address indexed hook, bool approved);
    event SettlementPhase(address indexed pool, uint8 indexed phase);
    event PermanentLiquidityJoined(address indexed sourcePool, address indexed targetPool, uint256 bptOut);
    event PermanentLiquidityFallbackToFeeConverterStorage(
        address indexed sourcePool,
        address indexed targetPool,
        address indexed token,
        uint256 amount,
        PermanentLiquidityVaultV2.LiquidityOrigin origin,
        address feeConverterStorage
    );
    event RawFeePayoutFallback(
        address indexed pool,
        address indexed intendedReceiver,
        address indexed token,
        uint256 amount,
        uint8 reason,
        address feeConverterStorage
    );
    event PartnerPoLSkipped(address indexed pool, uint8 reason);

    constructor(
        address initialOwner,
        address protocolFeeController_,
        address adminFeeSplitter_,
        address permanentLiquidityVault_,
        address vault_,
        address liquidityRouter_,
        address treasuryReceiver_,
        address defaultPayoutToken_
    ) AragonOwned(initialOwner) {
        if (
            protocolFeeController_ == address(0) || adminFeeSplitter_ == address(0)
                || permanentLiquidityVault_ == address(0) || vault_ == address(0) || liquidityRouter_ == address(0)
                || treasuryReceiver_ == address(0) || defaultPayoutToken_ == address(0)
        ) {
            revert ZeroAddress();
        }

        protocolFeeController = IProtocolFeeController(protocolFeeController_);
        adminFeeSplitter = AdminFeeSplitter(adminFeeSplitter_);
        permanentLiquidityVault = PermanentLiquidityVaultV2(permanentLiquidityVault_);
        vault = IBalancerV3Vault(vault_);
        liquidityRouter = IBalancerV3Router(liquidityRouter_);
        treasuryReceiver = treasuryReceiver_;
        feeConverterStorage = treasuryReceiver_;
        defaultPayoutToken = defaultPayoutToken_;
    }

    function setKeeper(address keeper, bool approved) external onlyOwner {
        if (keeper == address(0)) revert ZeroAddress();
        isKeeper[keeper] = approved;
        emit KeeperUpdated(keeper, approved);
    }

    function setCreatorFeeSplitterRegistrar(address registrar, bool approved) external onlyOwner {
        if (registrar == address(0)) revert ZeroAddress();
        isCreatorFeeSplitterRegistrar[registrar] = approved;
        emit CreatorFeeSplitterRegistrarUpdated(registrar, approved);
    }

    function setCreatorFeeSplitter(address pool, address splitter) external {
        if (msg.sender != owner && !isCreatorFeeSplitterRegistrar[msg.sender]) {
            revert UnauthorizedCreatorFeeSplitterRegistrar();
        }
        if (pool == address(0) || splitter == address(0)) revert ZeroAddress();
        creatorFeeSplitterOf[pool] = splitter;
        emit CreatorFeeSplitterUpdated(pool, splitter);
    }

    function setTreasuryReceiver(address newReceiver) external onlyOwner {
        if (newReceiver == address(0)) revert ZeroAddress();
        address previousReceiver = treasuryReceiver;
        treasuryReceiver = newReceiver;
        emit TreasuryReceiverUpdated(previousReceiver, newReceiver);
    }

    function setFeeConverterStorage(address newStorage) external onlyOwner {
        if (newStorage == address(0)) revert ZeroAddress();
        address previousStorage = feeConverterStorage;
        feeConverterStorage = newStorage;
        emit FeeConverterStorageUpdated(previousStorage, newStorage);
    }

    function setDefaultPayoutToken(address newToken) external onlyOwner {
        if (newToken == address(0)) revert ZeroAddress();
        address previousToken = defaultPayoutToken;
        defaultPayoutToken = newToken;
        emit DefaultPayoutTokenUpdated(previousToken, newToken);
    }

    function setPayoutTokenOverride(address pool, address receiver, address token) external onlyOwner {
        _setPayoutTokenOverride(pool, receiver, token);
    }

    function setPayoutTokenOverrideFromRegistrar(address pool, address receiver, address token) external {
        if (!isCreatorFeeSplitterRegistrar[msg.sender]) revert UnauthorizedCreatorFeeSplitterRegistrar();
        _setPayoutTokenOverride(pool, receiver, token);
    }

    function setCreatorPayoutTokenOverrideFromRegistrar(address pool, address token) external {
        if (!isCreatorFeeSplitterRegistrar[msg.sender]) revert UnauthorizedCreatorFeeSplitterRegistrar();
        _setCreatorPayoutTokenOverride(pool, token);
    }

    function setPartnerPayoutTokenOverride(address pool, uint8 partnerRole, address token) external onlyOwner {
        _setPartnerPayoutTokenOverride(pool, partnerRole, token);
    }

    function setPartnerPayoutTokenOverrideFromRegistrar(address pool, uint8 partnerRole, address token) external {
        if (!isCreatorFeeSplitterRegistrar[msg.sender]) revert UnauthorizedCreatorFeeSplitterRegistrar();
        _setPartnerPayoutTokenOverride(pool, partnerRole, token);
    }

    function _setPayoutTokenOverride(address pool, address receiver, address token) private {
        if (pool == address(0) || receiver == address(0) || token == address(0)) revert ZeroAddress();
        address previousToken = payoutTokenOverride[pool][receiver];
        payoutTokenOverride[pool][receiver] = token;
        emit PayoutTokenOverrideUpdated(pool, receiver, previousToken, token);
    }

    function _setCreatorPayoutTokenOverride(address pool, address token) private {
        if (pool == address(0) || token == address(0)) revert ZeroAddress();
        address previousToken = creatorPayoutTokenOverride[pool];
        creatorPayoutTokenOverride[pool] = token;
        emit CreatorPayoutTokenOverrideUpdated(pool, previousToken, token);
    }

    function _setPartnerPayoutTokenOverride(address pool, uint8 partnerRole, address token) private {
        if (pool == address(0) || token == address(0)) revert ZeroAddress();
        if (partnerRole != PARTNER_ROLE_CREATOR && partnerRole != PARTNER_ROLE_ADMIN) {
            revert InvalidPartnerRole(partnerRole);
        }
        address previousToken = partnerPayoutTokenOverride[pool][partnerRole];
        partnerPayoutTokenOverride[pool][partnerRole] = token;
        emit PartnerPayoutTokenOverrideUpdated(pool, partnerRole, previousToken, token);
    }

    function preferredPayoutToken(address pool, address receiver) external view returns (address) {
        return _preferredPayoutToken(pool, receiver);
    }

    function setProtectedBptSettlementHook(address hook, bool approved) external onlyOwner {
        if (hook == address(0)) revert ZeroAddress();
        isProtectedBptSettlementHook[hook] = approved;
        emit ProtectedBptSettlementHookUpdated(hook, approved);
    }

    function reconcileDustToTreasury(address pool, address token, uint256 amount) external onlyOwner {
        if (pool == address(0) || token == address(0)) revert ZeroAddress();
        uint256 attributed = poolDust[pool][token];
        if (amount == 0 || amount > attributed) revert DustAmountTooHigh();
        poolDust[pool][token] = attributed - amount;
        totalAccountedDust[token] -= amount;
        SafeERC20Transfer.safeTransfer(token, treasuryReceiver, amount);
        emit DustReconciled(pool, token, amount, treasuryReceiver);
    }

    function recoverUnaccountedToken(address token, address receiver, uint256 amount) external onlyOwner {
        if (token == address(0) || receiver == address(0)) revert ZeroAddress();
        uint256 balance = IERC20Settlement(token).balanceOf(address(this));
        uint256 accounted = totalAccountedDust[token];
        if (balance < accounted) revert AccountedDustInvariant();
        if (amount == 0 || amount > balance - accounted) revert DustAmountTooHigh();
        SafeERC20Transfer.safeTransfer(token, receiver, amount);
        emit UnaccountedTokenRecovered(token, receiver, amount);
    }

    function collect(address pool) external nonReentrant {
        _requireCollector();
        _collectAndSettle(pool, false);
    }

    function collectPartnerPoL(address pool) external nonReentrant {
        _requireCollector();
        _collectAndSettle(pool, true);
    }

    function _collectAndSettle(address pool, bool strictPartnerPoL) private {
        address[] memory poolTokens = vault.getPoolTokens(pool);
        uint256[] memory startingBalances = _snapshotPoolTokenBalances(poolTokens);

        protocolFeeController.collectAggregateFees(pool);
        uint256[] memory protocolFeeAmounts = protocolFeeController.getProtocolFeeAmounts(pool);
        uint256[] memory creatorFeeAmounts = protocolFeeController.getPoolCreatorFeeAmounts(pool);
        if (protocolFeeAmounts.length != poolTokens.length || creatorFeeAmounts.length != poolTokens.length) {
            revert ArrayLengthMismatch();
        }

        _claimBalancerFees(pool);
        _processCreatorPermanentLiquidity(pool, protocolFeeAmounts, creatorFeeAmounts, strictPartnerPoL);
        bool partnerPoLProcessed;
        if (strictPartnerPoL) {
            _processPartnerPoL(pool, protocolFeeAmounts, true);
            partnerPoLProcessed = true;
        } else {
            try this.executePartnerPoLFromSettlement(pool, protocolFeeAmounts) returns (bool processed) {
                partnerPoLProcessed = processed;
            } catch {
                emit PartnerPoLSkipped(pool, 6);
            }
        }
        _processNormalPayouts(pool, protocolFeeAmounts, creatorFeeAmounts, partnerPoLProcessed);
        _storeDust(pool, poolTokens, startingBalances);
    }

    function canSettlePartnerPoL(address pool) external returns (bool ok, uint8 reason) {
        protocolFeeController.collectAggregateFees(pool);
        return _preflightPartnerPoL(pool, protocolFeeController.getProtocolFeeAmounts(pool));
    }

    function previewPartnerPoL(address pool)
        external
        returns (
            bool ok,
            uint8 reason,
            uint256[] memory exactAmountsIn,
            uint256 baseBptOut,
            uint256 quotedAtBlock
        )
    {
        protocolFeeController.collectAggregateFees(pool);
        uint256[] memory protocolFeeAmounts = protocolFeeController.getProtocolFeeAmounts(pool);
        PoolFeePolicyRegistry.PartnerPoLConfig memory config = _registry().getPartnerPoLConfig(pool);
        quotedAtBlock = block.number;
        if (!config.enabled) return (false, 5, new uint256[](0), 0, quotedAtBlock);
        (exactAmountsIn, baseBptOut, ok, reason) =
            _quotePartnerBaseBasket(pool, protocolFeeAmounts);
        if (!ok || baseBptOut == 0) return (false, reason, exactAmountsIn, baseBptOut, quotedAtBlock);
        return (true, 0, exactAmountsIn, baseBptOut, quotedAtBlock);
    }

    function executePartnerPoLFromSettlement(address pool, uint256[] calldata protocolFeeAmounts)
        external
        returns (bool)
    {
        if (msg.sender != address(this)) revert NotSelfCall();
        _processPartnerPoL(pool, protocolFeeAmounts, false);
        return true;
    }

    function executePermanentLiquidityJoinFromSettlement(
        address sourcePool,
        address targetPool,
        uint256[] calldata exactAmountsIn,
        PermanentLiquidityVaultV2.LiquidityOrigin origin,
        address creatorController,
        address creatorPayoutReceiver
    ) external returns (bool) {
        if (msg.sender != address(this)) revert NotSelfCall();
        _joinPermanentLiquidityStrict(
            sourcePool,
            targetPool,
            exactAmountsIn,
            origin,
            creatorController,
            creatorPayoutReceiver
        );
        return true;
    }

    function executeBptPayoutFromSettlement(address pool, uint256[] calldata amounts, address receiver)
        external
        returns (bool)
    {
        if (msg.sender != address(this)) revert NotSelfCall();
        _payBptAmountsStrict(pool, amounts, receiver);
        return true;
    }

    function executeSamePoolSwapFromSettlement(address pool, address tokenIn, address tokenOut, uint256 amountIn)
        external
        returns (uint256 amountOut)
    {
        if (msg.sender != address(this)) revert NotSelfCall();
        return _swapThroughSourcePool(pool, tokenIn, tokenOut, amountIn);
    }

    function _claimBalancerFees(address pool) internal {
        emit SettlementPhase(pool, PHASE_CLAIM);
        protocolFeeController.withdrawProtocolFees(pool, address(this));
        address splitter = creatorFeeSplitterOf[pool];
        if (splitter == address(0)) revert MissingCreatorFeeSplitter();
        CreatorFeeSplitter(splitter).withdrawCreatorFeesToSettlementRouter();
    }

    function _processCreatorPermanentLiquidity(
        address pool,
        uint256[] memory protocolFeeAmounts,
        uint256[] memory creatorFeeAmounts,
        bool strict
    ) internal {
        emit SettlementPhase(pool, PHASE_CREATOR_PERMANENT_LIQUIDITY);
        address splitter = creatorFeeSplitterOf[pool];
        if (splitter == address(0)) revert MissingCreatorFeeSplitter();
        (,, uint256[] memory permanentLiquidity,,) =
            CreatorFeeSplitter(splitter).quoteCreatorAllocation(creatorFeeAmounts);
        (uint256[] memory adminCreatorPermanentLiquidity,,,) =
            adminFeeSplitter.quoteAdminAllocation(pool, protocolFeeAmounts);
        if (strict) {
            _joinPermanentLiquidityStrict(
                pool,
                pool,
                permanentLiquidity,
                PermanentLiquidityVaultV2.LiquidityOrigin.CreatorPermanentLiquidity,
                _registry().creatorControllerOf(pool),
                _registry().creatorPayoutReceiverOf(pool)
            );
            _joinPermanentLiquidityStrict(
                pool,
                pool,
                adminCreatorPermanentLiquidity,
                PermanentLiquidityVaultV2.LiquidityOrigin.AdminPermanentLiquidity,
                address(0),
                address(0)
            );
            return;
        }
        _joinPermanentLiquidity(
            pool,
            pool,
            permanentLiquidity,
            PermanentLiquidityVaultV2.LiquidityOrigin.CreatorPermanentLiquidity,
            _registry().creatorControllerOf(pool),
            _registry().creatorPayoutReceiverOf(pool)
        );
        _joinPermanentLiquidity(
            pool,
            pool,
            adminCreatorPermanentLiquidity,
            PermanentLiquidityVaultV2.LiquidityOrigin.AdminPermanentLiquidity,
            address(0),
            address(0)
        );
    }

    function _processPartnerPoL(address pool, uint256[] memory protocolFeeAmounts, bool strict) internal {
        emit SettlementPhase(pool, PHASE_PARTNER_POL);
        PoolFeePolicyRegistry.PartnerPoLConfig memory config = _registry().getPartnerPoLConfig(pool);
        if (!config.enabled) revert PartnerPoLUnavailable();

        (, uint256[] memory adminExtraPermanentPoL,,) =
            adminFeeSplitter.quoteAdminAllocation(pool, protocolFeeAmounts);
        (uint256[] memory quotedAmountsIn, uint256 baseBptOut, bool baseOk, uint8 baseReason) =
            _quotePartnerBaseBasket(pool, protocolFeeAmounts);
        if (!baseOk || baseBptOut == 0) {
            if (strict) revert PartnerPoLUnavailable();
            _transferPermanentLiquidityFallbackToFeeConverterStorage(
                pool,
                pool,
                adminExtraPermanentPoL,
                PermanentLiquidityVaultV2.LiquidityOrigin.PartnerPoL
            );
            emit PartnerPoLSkipped(pool, baseReason == 0 ? 4 : baseReason);
            return;
        }
        uint256[] memory exactAmountsIn =
            _partnerBaseBasketStrict(pool, config.targetPool, adminExtraPermanentPoL, quotedAmountsIn.length);
        if (strict) {
            _joinPermanentLiquidityStrict(
                pool,
                config.targetPool,
                exactAmountsIn,
                PermanentLiquidityVaultV2.LiquidityOrigin.PartnerPoL,
                address(0),
                address(0)
            );
        } else {
            _joinPermanentLiquidity(
                pool,
                config.targetPool,
                exactAmountsIn,
                PermanentLiquidityVaultV2.LiquidityOrigin.PartnerPoL,
                address(0),
                address(0)
            );
        }
    }

    function _processNormalPayouts(
        address pool,
        uint256[] memory protocolFeeAmounts,
        uint256[] memory creatorFeeAmounts,
        bool partnerPoLProcessed
    ) internal {
        emit SettlementPhase(pool, PHASE_NORMAL_PAYOUTS);
        (
            ,
            uint256[] memory adminExtraPermanentPoL,
            uint256[] memory adminPartnerRevenue,
            uint256[] memory treasury
        ) = adminFeeSplitter.quoteAdminAllocation(pool, protocolFeeAmounts);
        (
            uint256[] memory creatorPayout,
            uint256[] memory creatorAdminCut,
            ,
            uint256[] memory creatorPartnerPayout,
            uint256[] memory creatorPartnerAdminCut
        ) = CreatorFeeSplitter(creatorFeeSplitterOf[pool]).quoteCreatorAllocation(creatorFeeAmounts);

        uint256[] memory treasuryAmounts = _sumArrays(treasury, creatorAdminCut);
        treasuryAmounts = _sumArrays(treasuryAmounts, creatorPartnerAdminCut);
        if (!partnerPoLProcessed) {
            treasuryAmounts = _sumArrays(treasuryAmounts, adminExtraPermanentPoL);
        }

        _payAmounts(pool, creatorPayout, _registry().creatorPayoutReceiverOf(pool));
        _payAmounts(pool, treasuryAmounts, treasuryReceiver);
        _payAmountsWithToken(
            pool,
            creatorPartnerPayout,
            _registry().creatorPartnerRevenueReceiverOf(pool),
            _preferredPartnerPayoutToken(pool, PARTNER_ROLE_CREATOR)
        );
        _payAmountsWithToken(
            pool,
            adminPartnerRevenue,
            _registry().adminPartnerRevenueReceiverOf(pool),
            _preferredPartnerPayoutToken(pool, PARTNER_ROLE_ADMIN)
        );
    }

    function _storeDust(address pool, address[] memory poolTokens, uint256[] memory startingBalances) internal {
        emit SettlementPhase(pool, PHASE_DUST);
        for (uint256 i = 0; i < poolTokens.length; ++i) {
            uint256 endingBalance = IERC20Settlement(poolTokens[i]).balanceOf(address(this));
            if (endingBalance < startingBalances[i]) revert AccountedDustInvariant();
            uint256 settlementDust = endingBalance - startingBalances[i];
            if (settlementDust == 0) continue;
            poolDust[pool][poolTokens[i]] += settlementDust;
            totalAccountedDust[poolTokens[i]] += settlementDust;
            emit DustStored(pool, poolTokens[i], settlementDust, poolDust[pool][poolTokens[i]]);
        }
    }

    function _requireCollector() private view {
        if (msg.sender != owner && !isKeeper[msg.sender]) revert UnauthorizedCollector();
    }

    function _partnerBaseBasketStrict(
        address sourcePool,
        address targetPool,
        uint256[] memory sourceAmounts,
        uint256 expectedTargetTokenCount
    )
        private
        returns (uint256[] memory exactAmountsIn)
    {
        bool ok;
        (exactAmountsIn, ok,) = _buildJoinBasket(sourcePool, targetPool, sourceAmounts);
        if (!ok) revert PartnerPoLUnavailable();
        if (exactAmountsIn.length != expectedTargetTokenCount) revert ArrayLengthMismatch();
    }

    function _quotePartnerBaseBasket(address pool, uint256[] memory protocolFeeAmounts)
        private
        returns (uint256[] memory exactAmountsIn, uint256 baseBptOut, bool ok, uint8 reason)
    {
        (, uint256[] memory adminExtraPermanentPoL,,) =
            adminFeeSplitter.quoteAdminAllocation(pool, protocolFeeAmounts);
        PoolFeePolicyRegistry.PartnerPoLConfig memory config = _registry().getPartnerPoLConfig(pool);
        (exactAmountsIn, ok, reason) =
            _quoteJoinBasket(pool, config.targetPool, adminExtraPermanentPoL);
        if (!ok) return (exactAmountsIn, 0, false, reason);
        (bool protectedOk, uint256 minBptOut) = _protectedBptMinOut(config.targetPool, exactAmountsIn);
        if (!protectedOk || minBptOut == 0) {
            return (exactAmountsIn, 0, false, 4);
        }
        return (exactAmountsIn, minBptOut, true, 0);
    }

    function _preflightPartnerPoL(address pool, uint256[] memory protocolFeeAmounts)
        private
        returns (bool ok, uint8 reason)
    {
        PoolFeePolicyRegistry.PartnerPoLConfig memory config = _registry().getPartnerPoLConfig(pool);
        if (!config.enabled) return (false, 5);
        (, uint256 baseBptOut, bool baseOk, uint8 baseReason) =
            _quotePartnerBaseBasket(pool, protocolFeeAmounts);
        if (!baseOk || baseBptOut == 0) return (false, baseReason);
        return (true, 0);
    }

    function _joinPermanentLiquidity(
        address sourcePool,
        address targetPool,
        uint256[] memory exactAmountsIn,
        PermanentLiquidityVaultV2.LiquidityOrigin origin,
        address creatorController,
        address creatorPayoutReceiver
    ) private {
        if (!_hasNonzeroAmount(exactAmountsIn)) return;
        try this.executePermanentLiquidityJoinFromSettlement(
            sourcePool,
            targetPool,
            exactAmountsIn,
            origin,
            creatorController,
            creatorPayoutReceiver
        ) returns (bool) {
            return;
        } catch {
            _transferPermanentLiquidityFallbackToFeeConverterStorage(sourcePool, targetPool, exactAmountsIn, origin);
        }
    }

    function _joinPermanentLiquidityStrict(
        address sourcePool,
        address targetPool,
        uint256[] memory exactAmountsIn,
        PermanentLiquidityVaultV2.LiquidityOrigin origin,
        address creatorController,
        address creatorPayoutReceiver
    ) private {
        if (!_hasNonzeroAmount(exactAmountsIn)) return;
        address[] memory targetTokens = vault.getPoolTokens(targetPool);
        if (exactAmountsIn.length != targetTokens.length) revert ArrayLengthMismatch();
        for (uint256 i = 0; i < targetTokens.length; ++i) {
            if (exactAmountsIn[i] > 0) {
                _approveRouterToken(targetTokens[i], exactAmountsIn[i]);
            }
        }
        (bool protectedQuoteOk, uint256 minBptOut) = _protectedBptMinOut(targetPool, exactAmountsIn);
        if (!protectedQuoteOk) revert ZeroQuote();
        uint256 bptOut =
            liquidityRouter.addLiquidityUnbalanced(targetPool, exactAmountsIn, minBptOut, false, "");
        for (uint256 i = 0; i < targetTokens.length; ++i) {
            if (exactAmountsIn[i] > 0) {
                _clearRouterTokenApproval(targetTokens[i]);
            }
        }
        SafeERC20Transfer.safeTransfer(targetPool, address(permanentLiquidityVault), bptOut);
        permanentLiquidityVault.recordPermanentLiquidity(
            sourcePool,
            targetPool,
            targetPool,
            bptOut,
            origin,
            creatorController,
            creatorPayoutReceiver
        );
        emit PermanentLiquidityJoined(sourcePool, targetPool, bptOut);
    }

    function _transferPermanentLiquidityFallbackToFeeConverterStorage(
        address sourcePool,
        address targetPool,
        uint256[] memory exactAmountsIn,
        PermanentLiquidityVaultV2.LiquidityOrigin origin
    ) private {
        address[] memory targetTokens = vault.getPoolTokens(targetPool);
        if (exactAmountsIn.length != targetTokens.length) revert ArrayLengthMismatch();
        for (uint256 i = 0; i < targetTokens.length; ++i) {
            uint256 amount = exactAmountsIn[i];
            if (amount == 0) continue;
            SafeERC20Transfer.safeTransfer(targetTokens[i], feeConverterStorage, amount);
            emit PermanentLiquidityFallbackToFeeConverterStorage(
                sourcePool,
                targetPool,
                targetTokens[i],
                amount,
                origin,
                feeConverterStorage
            );
        }
    }

    function _buildJoinBasket(address sourcePool, address targetPool, uint256[] memory sourceAmounts)
        private
        returns (uint256[] memory exactAmountsIn, bool ok, uint8 reason)
    {
        address[] memory sourceTokens = vault.getPoolTokens(sourcePool);
        address[] memory targetTokens = vault.getPoolTokens(targetPool);
        if (sourceAmounts.length != sourceTokens.length) revert ArrayLengthMismatch();
        exactAmountsIn = new uint256[](targetTokens.length);

        for (uint256 i = 0; i < sourceTokens.length; ++i) {
            if (sourceAmounts[i] == 0) continue;
            (bool isTargetToken, uint256 targetIndex) = _tryTokenIndexFromList(targetTokens, sourceTokens[i]);
            if (isTargetToken) {
                exactAmountsIn[targetIndex] += sourceAmounts[i];
                continue;
            }

            (bool converted, uint256 convertedIndex, uint256 convertedAmount) =
                _convertToTargetToken(sourcePool, sourceTokens, sourceTokens[i], sourceAmounts[i], targetTokens);
            if (!converted) return (exactAmountsIn, false, 1);
            exactAmountsIn[convertedIndex] += convertedAmount;
        }

        return (exactAmountsIn, true, 0);
    }

    function _quoteJoinBasket(address sourcePool, address targetPool, uint256[] memory sourceAmounts)
        private
        view
        returns (uint256[] memory exactAmountsIn, bool ok, uint8 reason)
    {
        address[] memory sourceTokens = vault.getPoolTokens(sourcePool);
        address[] memory targetTokens = vault.getPoolTokens(targetPool);
        if (sourceAmounts.length != sourceTokens.length) {
            return (new uint256[](targetTokens.length), false, 1);
        }
        exactAmountsIn = new uint256[](targetTokens.length);

        for (uint256 i = 0; i < sourceTokens.length; ++i) {
            if (sourceAmounts[i] == 0) continue;
            (bool isTargetToken, uint256 targetIndex) =
                _tryTokenIndexFromList(targetTokens, sourceTokens[i]);
            if (isTargetToken) {
                exactAmountsIn[targetIndex] += sourceAmounts[i];
                continue;
            }

            (bool converted, uint256 convertedIndex, uint256 convertedAmount) =
                _quoteToTargetToken(sourcePool, sourceTokens, sourceTokens[i], sourceAmounts[i], targetTokens);
            if (!converted) return (exactAmountsIn, false, 1);
            exactAmountsIn[convertedIndex] += convertedAmount;
        }

        return (exactAmountsIn, true, 0);
    }

    function _quoteToTargetToken(
        address sourcePool,
        address[] memory sourceTokens,
        address tokenIn,
        uint256 amountIn,
        address[] memory targetTokens
    )
        private
        view
        returns (bool converted, uint256 targetIndex, uint256 amountOut)
    {
        for (uint256 i = 0; i < targetTokens.length; ++i) {
            if (targetTokens[i] == tokenIn || !_isTokenInList(sourceTokens, targetTokens[i])) continue;
            (bool protectedOk, uint256 oracleMinAmountOut) =
                _protectedSwapMinOut(sourcePool, tokenIn, targetTokens[i], amountIn);
            if (protectedOk && oracleMinAmountOut != 0) return (true, i, oracleMinAmountOut);
        }
        return (false, 0, 0);
    }

    function _convertToTargetToken(
        address sourcePool,
        address[] memory sourceTokens,
        address tokenIn,
        uint256 amountIn,
        address[] memory targetTokens
    )
        private
        returns (bool converted, uint256 targetIndex, uint256 amountOut)
    {
        for (uint256 i = 0; i < targetTokens.length; ++i) {
            if (targetTokens[i] == tokenIn || !_isTokenInList(sourceTokens, targetTokens[i])) continue;
            try this.executeSamePoolSwapFromSettlement(sourcePool, tokenIn, targetTokens[i], amountIn) returns (
                uint256 received
            ) {
                if (received == 0) continue;
                amountOut = received;
                return (true, i, amountOut);
            } catch {}
        }
        return (false, 0, 0);
    }

    function _payAmounts(address pool, uint256[] memory amounts, address receiver) private {
        if (!_hasNonzeroAmount(amounts)) return;
        if (receiver == address(0)) revert MissingPayoutReceiver();
        if (amounts.length != vault.getPoolTokens(pool).length) revert ArrayLengthMismatch();

        _payAmountsWithToken(pool, amounts, receiver, _preferredPayoutToken(pool, receiver));
    }

    function _payAmountsWithToken(address pool, uint256[] memory amounts, address receiver, address payoutToken) private {
        if (!_hasNonzeroAmount(amounts)) return;
        if (receiver == address(0)) revert MissingPayoutReceiver();
        if (amounts.length != vault.getPoolTokens(pool).length) revert ArrayLengthMismatch();

        if (payoutToken == address(0)) {
            _payRawAmounts(pool, amounts, receiver, 1);
            return;
        }
        if (payoutToken == pool) {
            if (!_hasApprovedProtectedBptSettlementHook(pool)) {
                _payRawAmounts(pool, amounts, receiver, 4);
                return;
            }
            try this.executeBptPayoutFromSettlement(pool, amounts, receiver) returns (bool) {
                return;
            } catch {
                _payRawAmounts(pool, amounts, receiver, 2);
            }
            return;
        }

        address[] memory poolTokens = vault.getPoolTokens(pool);
        if (!_isTokenInList(poolTokens, payoutToken)) {
            _payRawAmounts(pool, amounts, receiver, 5);
            return;
        }
        for (uint256 i = 0; i < poolTokens.length; ++i) {
            uint256 amount = amounts[i];
            if (amount == 0) continue;

            if (poolTokens[i] != payoutToken) {
                try this.executeSamePoolSwapFromSettlement(pool, poolTokens[i], payoutToken, amount) returns (
                    uint256 payoutAmount
                ) {
                    SafeERC20Transfer.safeTransfer(payoutToken, receiver, payoutAmount);
                    emit FeePayout(pool, receiver, payoutToken, payoutAmount);
                    continue;
                } catch {
                    _payRawAmountToFeeConverterStorage(pool, receiver, poolTokens[i], amount, 3);
                    continue;
                }
            }

            SafeERC20Transfer.safeTransfer(poolTokens[i], receiver, amount);
            emit FeePayout(pool, receiver, poolTokens[i], amount);
        }
    }

    function _payRawAmounts(address pool, uint256[] memory amounts, address receiver, uint8 reason) private {
        address[] memory poolTokens = vault.getPoolTokens(pool);
        if (amounts.length != poolTokens.length) revert ArrayLengthMismatch();
        for (uint256 i = 0; i < poolTokens.length; ++i) {
            uint256 amount = amounts[i];
            if (amount == 0) continue;
            _payRawAmountToFeeConverterStorage(pool, receiver, poolTokens[i], amount, reason);
        }
    }

    function _payRawAmountToFeeConverterStorage(
        address pool,
        address intendedReceiver,
        address token,
        uint256 amount,
        uint8 reason
    ) private {
        SafeERC20Transfer.safeTransfer(token, feeConverterStorage, amount);
        emit FeePayout(pool, feeConverterStorage, token, amount);
        emit RawFeePayoutFallback(pool, intendedReceiver, token, amount, reason, feeConverterStorage);
    }

    function _payBptAmountsStrict(address pool, uint256[] memory amounts, address receiver) private {
        address[] memory poolTokens = vault.getPoolTokens(pool);
        for (uint256 i = 0; i < poolTokens.length; ++i) {
            if (amounts[i] > 0) {
                _approveRouterToken(poolTokens[i], amounts[i]);
            }
        }
        (bool protectedQuoteOk, uint256 minBptOut) = _protectedBptMinOut(pool, amounts);
        if (!protectedQuoteOk) revert ZeroQuote();
        uint256 bptOut = liquidityRouter.addLiquidityUnbalanced(pool, amounts, minBptOut, false, "");
        for (uint256 i = 0; i < poolTokens.length; ++i) {
            if (amounts[i] > 0) {
                _clearRouterTokenApproval(poolTokens[i]);
            }
        }
        SafeERC20Transfer.safeTransfer(pool, receiver, bptOut);
        emit FeePayout(pool, receiver, pool, bptOut);
    }

    function _swapThroughSourcePool(address pool, address tokenIn, address payoutToken, uint256 amountIn)
        private
        returns (uint256 amountOut)
    {
        (bool protectedQuoteOk, uint256 minAmountOut) =
            _protectedSwapMinOut(pool, tokenIn, payoutToken, amountIn);
        if (!protectedQuoteOk) revert ZeroQuote();
        _approveRouterToken(tokenIn, amountIn);
        amountOut = liquidityRouter.swapSingleTokenExactIn(
            pool,
            tokenIn,
            payoutToken,
            amountIn,
            minAmountOut,
            block.timestamp,
            false,
            ""
        );
        _clearRouterTokenApproval(tokenIn);
    }

    function _approveRouterToken(address token, uint256 amount) private {
        if (amount > type(uint160).max) revert Permit2AmountOverflow();
        address permit2 = liquidityRouter.getPermit2();
        SafeERC20Transfer.safeApprove(token, permit2, amount);
        IPermit2SettlementApprove(permit2).approve(token, address(liquidityRouter), uint160(amount), type(uint48).max);
    }

    function _clearRouterTokenApproval(address token) private {
        address permit2 = liquidityRouter.getPermit2();
        IPermit2SettlementApprove(permit2).approve(token, address(liquidityRouter), 0, 0);
        SafeERC20Transfer.safeApprove(token, permit2, 0);
    }

    function _preferredPayoutToken(address pool, address receiver) private view returns (address) {
        if (receiver == treasuryReceiver) return pool;
        try _registry().creatorPayoutReceiverOf(pool) returns (address creatorReceiver) {
            if (receiver == creatorReceiver) {
                address creatorToken = creatorPayoutTokenOverride[pool];
                if (creatorToken != address(0)) return creatorToken;
            }
        } catch {}
        address overrideToken = payoutTokenOverride[pool][receiver];
        if (overrideToken != address(0)) return overrideToken;
        return defaultPayoutToken;
    }

    function _preferredPartnerPayoutToken(address pool, uint8 partnerRole) private view returns (address) {
        address overrideToken = partnerPayoutTokenOverride[pool][partnerRole];
        if (overrideToken != address(0)) return overrideToken;
        return defaultPayoutToken;
    }

    function _hasApprovedProtectedBptSettlementHook(address pool) private view returns (bool) {
        try vault.getHooksConfig(pool) returns (HooksConfig memory hooksConfig) {
            return hooksConfig.hooksContract != address(0) && isProtectedBptSettlementHook[hooksConfig.hooksContract];
        } catch {
            return false;
        }
    }

    function _protectedBptMinOut(address pool, uint256[] memory amounts)
        private
        view
        returns (bool ok, uint256 minBptOut)
    {
        try vault.getHooksConfig(pool) returns (HooksConfig memory hooksConfig) {
            address hook = hooksConfig.hooksContract;
            if (hook == address(0) || !isProtectedBptSettlementHook[hook]) return (false, 0);
            try ICurveYieldPoolObservation(hook).quoteOracleProtectedBptOut(pool, amounts) returns (
                uint256,
                uint256 oracleMinBptOut
            ) {
                return (oracleMinBptOut != 0, oracleMinBptOut);
            } catch {
                return (false, 0);
            }
        } catch {
            return (false, 0);
        }
    }

    function _protectedSwapMinOut(address pool, address tokenIn, address tokenOut, uint256 amountIn)
        private
        view
        returns (bool ok, uint256 minAmountOut)
    {
        try vault.getHooksConfig(pool) returns (HooksConfig memory hooksConfig) {
            address hook = hooksConfig.hooksContract;
            if (hook == address(0) || !isProtectedBptSettlementHook[hook]) return (false, 0);
            try ICurveYieldPoolObservation(hook).quoteOracleProtectedSwapOut(
                pool,
                tokenIn,
                tokenOut,
                amountIn
            ) returns (
                uint256,
                uint256 oracleMinAmountOut
            ) {
                return (oracleMinAmountOut != 0, oracleMinAmountOut);
            } catch {
                return (false, 0);
            }
        } catch {
            return (false, 0);
        }
    }

    function _sumArrays(uint256[] memory a, uint256[] memory b) private pure returns (uint256[] memory result) {
        result = new uint256[](a.length);
        for (uint256 i = 0; i < a.length; ++i) {
            result[i] = a[i] + b[i];
        }
    }

    function _tryTokenIndexFromList(address[] memory tokens, address token)
        private
        pure
        returns (bool found, uint256 index)
    {
        for (uint256 i = 0; i < tokens.length; ++i) {
            if (tokens[i] == token) return (true, i);
        }
        return (false, 0);
    }

    function _isTokenInList(address[] memory tokens, address token) private pure returns (bool) {
        for (uint256 i = 0; i < tokens.length; ++i) {
            if (tokens[i] == token) return true;
        }
        return false;
    }

    function _hasNonzeroAmount(uint256[] memory amounts) private pure returns (bool) {
        for (uint256 i = 0; i < amounts.length; ++i) {
            if (amounts[i] > 0) return true;
        }
        return false;
    }

    function _snapshotPoolTokenBalances(address[] memory poolTokens)
        private
        view
        returns (uint256[] memory balances)
    {
        balances = new uint256[](poolTokens.length);
        for (uint256 i = 0; i < poolTokens.length; ++i) {
            balances[i] = IERC20Settlement(poolTokens[i]).balanceOf(address(this));
        }
    }

    function _registry() private view returns (PoolFeePolicyRegistry) {
        return adminFeeSplitter.registry();
    }
}
