// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

interface ISwapAdapter {
    function quote(address tokenIn, address tokenOut, uint256 amountIn, bytes calldata routeData)
        external
        returns (uint256 amountOut);

    function swap(address tokenIn, address tokenOut, uint256 amountIn, uint256 minAmountOut, bytes calldata routeData)
        external
        returns (uint256 amountOut);
}
