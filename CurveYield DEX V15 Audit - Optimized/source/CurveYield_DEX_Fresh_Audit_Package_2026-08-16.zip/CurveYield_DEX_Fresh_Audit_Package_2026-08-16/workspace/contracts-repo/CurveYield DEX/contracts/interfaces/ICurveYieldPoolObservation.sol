// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract supports a CurveYield implementation derived from Balancer's smart contracts.
 * Balancer's gracious use of open-source GPL licensing allows CurveYield to use it for the good of all.
 */

interface ICurveYieldPoolObservation {
    function initializeObservation(address pool) external;

    function checkpoint(address pool) external;

    function isObservationWarm(address pool) external view returns (bool);

    function getTimeWeightedBalancesPerBpt(
        address pool,
        uint32 secondsAgo
    ) external view returns (uint256[] memory balancesPerBpt);

    function quoteOracleProtectedBptOut(
        address pool,
        uint256[] calldata exactAmountsInRaw
    ) external view returns (uint256 oracleExpectedBptOut, uint256 oracleMinBptOut);

    function quoteOracleProtectedBptOutScaled18(
        address pool,
        uint256[] calldata exactAmountsInScaled18
    ) external view returns (uint256 oracleExpectedBptOut, uint256 oracleMinBptOut);

    function quoteOracleProtectedSwapOut(
        address pool,
        address tokenIn,
        address tokenOut,
        uint256 amountInRaw
    ) external view returns (uint256 oracleExpectedAmountOut, uint256 oracleMinAmountOut);
}
