// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import { AragonOwned } from "./access/AragonOwned.sol";
import { IBalancerV3Vault } from "./interfaces/IBalancerV3Vault.sol";
import { CurveYieldFeeMath } from "./lib/CurveYieldFeeMath.sol";

interface ICreatorFeeSync {
    function syncCreatorSwapFee() external;
}

contract PoolFeePolicyRegistry is AragonOwned {
    enum PoolType {
        StableSurge,
        Stable,
        Weighted,
        ReClamm
    }

    struct CreatorFeeConfig {
        uint16 creatorPersonalBps;
        uint16 creatorPermanentLiquidityBps;
        uint16 creatorPartnerRevenueBps;
    }

    struct AdminFeeConfig {
        uint16 adminCreatorPermanentLiquidityBps;
        uint16 adminExtraPermanentPoLBps;
        uint16 adminPartnerRevenueBps;
    }

    struct PartnerPoLConfig {
        bool enabled;
        address targetPool;
    }

    struct PoolPolicy {
        bool registered;
        PoolType poolType;
        address creatorFeeSplitter;
        address creatorController;
        address pendingCreatorController;
        address creatorPayoutReceiver;
        address creatorPartnerRevenueReceiver;
        address adminPartnerRevenueReceiver;
        CreatorFeeConfig creatorFeeConfig;
        AdminFeeConfig adminFeeConfig;
        PartnerPoLConfig partnerPoLConfig;
    }

    error AlreadyRegistered();
    error NotRegistered();
    error UnsupportedPoolType();
    error NotCreatorController();
    error NotPendingCreatorController();
    error UnauthorizedPoolRegistrar();
    error AdminFixedObligationsTooHigh();
    error InvalidPartnerPoLConfig();
    error MissingPartnerRevenueReceiver();
    error InvalidCreatorFeeSplitter();
    error ReClammBptSettlementUnsupported();

    mapping(address => PoolPolicy) private _policies;
    mapping(address => bool) public isPoolRegistrar;
    AdminFeeConfig private _defaultAdminFeeConfig;
    IBalancerV3Vault public immutable vault;

    event PoolRegistrarUpdated(address indexed registrar, bool approved);
    event PoolRegistered(
        address indexed pool,
        PoolType indexed poolType,
        address indexed creatorFeeSplitter,
        address creatorController,
        address creatorPayoutReceiver
    );
    event CreatorFeeConfigUpdated(
        address indexed pool,
        CreatorFeeConfig previousConfig,
        CreatorFeeConfig newConfig
    );
    event AdminFeeConfigUpdated(address indexed pool, AdminFeeConfig previousConfig, AdminFeeConfig newConfig);
    event PartnerPoLConfigUpdated(
        address indexed pool,
        PartnerPoLConfig previousConfig,
        PartnerPoLConfig newConfig
    );
    event CreatorPayoutReceiverUpdated(address indexed pool, address indexed previousReceiver, address indexed newReceiver);
    event CreatorPartnerRevenueReceiverUpdated(
        address indexed pool,
        address indexed previousReceiver,
        address indexed newReceiver
    );
    event AdminPartnerRevenueReceiverUpdated(
        address indexed pool,
        address indexed previousReceiver,
        address indexed newReceiver
    );
    event CreatorControllerTransferRequested(
        address indexed pool,
        address indexed previousController,
        address indexed pendingController
    );
    event CreatorControllerTransferred(
        address indexed pool,
        address indexed previousController,
        address indexed newController
    );
    event DefaultAdminFeeConfigUpdated(AdminFeeConfig previousConfig, AdminFeeConfig newConfig);

    constructor(address initialOwner, address vault_) AragonOwned(initialOwner) {
        if (vault_ == address(0)) revert ZeroAddress();
        vault = IBalancerV3Vault(vault_);
    }

    function registerPool(
        address pool,
        uint8 poolTypeId,
        address creatorFeeSplitter,
        address creatorController,
        address creatorPayoutReceiver,
        address creatorPartnerRevenueReceiver,
        address adminPartnerRevenueReceiver,
        CreatorFeeConfig calldata creatorFeeConfig,
        AdminFeeConfig calldata adminFeeConfig,
        PartnerPoLConfig calldata partnerPoLConfig
    ) external onlyOwner {
        _registerPool(
            pool,
            poolTypeId,
            creatorFeeSplitter,
            creatorController,
            creatorPayoutReceiver,
            creatorPartnerRevenueReceiver,
            adminPartnerRevenueReceiver,
            creatorFeeConfig,
            adminFeeConfig,
            partnerPoLConfig
        );
    }

    function registerPoolFromRegistrarDefaults(
        address pool,
        uint8 poolTypeId,
        address creatorFeeSplitter,
        address creatorController,
        address creatorPayoutReceiver,
        address creatorPartnerRevenueReceiver,
        CreatorFeeConfig calldata creatorFeeConfig
    ) external {
        if (!isPoolRegistrar[msg.sender]) revert UnauthorizedPoolRegistrar();
        PartnerPoLConfig memory disabledPartnerPoL;
        _registerPool(
            pool,
            poolTypeId,
            creatorFeeSplitter,
            creatorController,
            creatorPayoutReceiver,
            creatorPartnerRevenueReceiver,
            address(0),
            creatorFeeConfig,
            _defaultAdminFeeConfig,
            disabledPartnerPoL
        );
    }

    function setPoolRegistrar(address registrar, bool approved) external onlyOwner {
        if (registrar == address(0)) revert ZeroAddress();
        isPoolRegistrar[registrar] = approved;
        emit PoolRegistrarUpdated(registrar, approved);
    }

    function updateCreatorFeeConfig(address pool, CreatorFeeConfig calldata newConfig) external onlyOwner {
        PoolPolicy storage policy = _registeredPolicy(pool);
        _validateCreatorConfig(newConfig, policy.creatorPartnerRevenueReceiver);
        _validatePoolTypePolicyCompatibility(policy.poolType, newConfig, policy.adminFeeConfig, policy.partnerPoLConfig);
        CreatorFeeConfig memory previousConfig = policy.creatorFeeConfig;
        policy.creatorFeeConfig = newConfig;
        _syncCreatorFeeSplitter(policy.creatorFeeSplitter);
        emit CreatorFeeConfigUpdated(pool, previousConfig, newConfig);
    }

    function updateAdminFeeConfig(address pool, AdminFeeConfig calldata newConfig) external onlyOwner {
        PoolPolicy storage policy = _registeredPolicy(pool);
        _validateAdminConfig(newConfig);
        if (newConfig.adminPartnerRevenueBps != 0 && policy.adminPartnerRevenueReceiver == address(0)) {
            revert MissingPartnerRevenueReceiver();
        }
        _validatePartnerPoLConfig(pool, policy.partnerPoLConfig, newConfig);
        _validatePoolTypePolicyCompatibility(policy.poolType, policy.creatorFeeConfig, newConfig, policy.partnerPoLConfig);
        AdminFeeConfig memory previousConfig = policy.adminFeeConfig;
        policy.adminFeeConfig = newConfig;
        emit AdminFeeConfigUpdated(pool, previousConfig, newConfig);
    }

    function updatePartnerPoLConfig(address pool, PartnerPoLConfig calldata newConfig) external onlyOwner {
        PoolPolicy storage policy = _registeredPolicy(pool);
        _validatePartnerPoLConfig(pool, newConfig, policy.adminFeeConfig);
        _validatePoolTypePolicyCompatibility(policy.poolType, policy.creatorFeeConfig, policy.adminFeeConfig, newConfig);
        PartnerPoLConfig memory previousConfig = policy.partnerPoLConfig;
        policy.partnerPoLConfig = newConfig;
        emit PartnerPoLConfigUpdated(pool, previousConfig, newConfig);
    }

    function setDefaultAdminFeeConfig(AdminFeeConfig calldata newConfig) external onlyOwner {
        _validateAdminConfig(newConfig);
        if (newConfig.adminPartnerRevenueBps != 0) revert MissingPartnerRevenueReceiver();
        AdminFeeConfig memory previousConfig = _defaultAdminFeeConfig;
        _defaultAdminFeeConfig = newConfig;
        emit DefaultAdminFeeConfigUpdated(previousConfig, newConfig);
    }

    function setCreatorPayoutReceiver(address pool, address newReceiver) external {
        PoolPolicy storage policy = _registeredPolicy(pool);
        if (msg.sender != policy.creatorController) revert NotCreatorController();
        _setCreatorPayoutReceiver(pool, policy, newReceiver);
    }

    function adminSetCreatorPayoutReceiver(address pool, address newReceiver) external onlyOwner {
        PoolPolicy storage policy = _registeredPolicy(pool);
        _setCreatorPayoutReceiver(pool, policy, newReceiver);
    }

    function setCreatorPayoutReceiverFromSplitter(address pool, address caller, address newReceiver) external {
        PoolPolicy storage policy = _registeredPolicy(pool);
        if (msg.sender != policy.creatorFeeSplitter) revert InvalidCreatorFeeSplitter();
        if (caller != policy.creatorController) revert NotCreatorController();
        _setCreatorPayoutReceiver(pool, policy, newReceiver);
    }

    function adminSetCreatorPartnerRevenueReceiver(address pool, address newReceiver) external onlyOwner {
        PoolPolicy storage policy = _registeredPolicy(pool);
        if (newReceiver == address(0) && policy.creatorFeeConfig.creatorPartnerRevenueBps != 0) {
            revert MissingPartnerRevenueReceiver();
        }
        address previousReceiver = policy.creatorPartnerRevenueReceiver;
        policy.creatorPartnerRevenueReceiver = newReceiver;
        emit CreatorPartnerRevenueReceiverUpdated(pool, previousReceiver, newReceiver);
    }

    function adminSetAdminPartnerRevenueReceiver(address pool, address newReceiver) external onlyOwner {
        PoolPolicy storage policy = _registeredPolicy(pool);
        if (newReceiver == address(0) && policy.adminFeeConfig.adminPartnerRevenueBps != 0) {
            revert MissingPartnerRevenueReceiver();
        }
        address previousReceiver = policy.adminPartnerRevenueReceiver;
        policy.adminPartnerRevenueReceiver = newReceiver;
        emit AdminPartnerRevenueReceiverUpdated(pool, previousReceiver, newReceiver);
    }

    function requestCreatorControllerTransfer(address pool, address newController) external onlyOwner {
        if (newController == address(0)) revert ZeroAddress();
        PoolPolicy storage policy = _registeredPolicy(pool);
        policy.pendingCreatorController = newController;
        emit CreatorControllerTransferRequested(pool, policy.creatorController, newController);
    }

    function acceptCreatorControllerTransfer(address pool) external {
        PoolPolicy storage policy = _registeredPolicy(pool);
        if (msg.sender != policy.pendingCreatorController) revert NotPendingCreatorController();
        address previousController = policy.creatorController;
        policy.creatorController = msg.sender;
        policy.pendingCreatorController = address(0);
        emit CreatorControllerTransferred(pool, previousController, msg.sender);
    }

    function isPoolRegistered(address pool) external view returns (bool) {
        return _policies[pool].registered;
    }

    function poolTypeOf(address pool) external view returns (PoolType) {
        return _registeredPolicyView(pool).poolType;
    }

    function creatorControllerOf(address pool) external view returns (address) {
        return _registeredPolicyView(pool).creatorController;
    }

    function pendingCreatorControllerOf(address pool) external view returns (address) {
        return _registeredPolicyView(pool).pendingCreatorController;
    }

    function creatorFeeSplitterOf(address pool) external view returns (address) {
        return _registeredPolicyView(pool).creatorFeeSplitter;
    }

    function creatorPayoutReceiverOf(address pool) external view returns (address) {
        return _registeredPolicyView(pool).creatorPayoutReceiver;
    }

    function creatorPartnerRevenueReceiverOf(address pool) external view returns (address) {
        return _registeredPolicyView(pool).creatorPartnerRevenueReceiver;
    }

    function adminPartnerRevenueReceiverOf(address pool) external view returns (address) {
        return _registeredPolicyView(pool).adminPartnerRevenueReceiver;
    }

    function getCreatorFeeConfig(address pool) external view returns (CreatorFeeConfig memory) {
        return _registeredPolicyView(pool).creatorFeeConfig;
    }

    function getAdminFeeConfig(address pool) external view returns (AdminFeeConfig memory) {
        return _registeredPolicyView(pool).adminFeeConfig;
    }

    function getPartnerPoLConfig(address pool) external view returns (PartnerPoLConfig memory) {
        return _registeredPolicyView(pool).partnerPoLConfig;
    }

    function getDefaultAdminFeeConfig() external view returns (AdminFeeConfig memory) {
        return _defaultAdminFeeConfig;
    }

    function _setCreatorPayoutReceiver(address pool, PoolPolicy storage policy, address newReceiver) private {
        if (newReceiver == address(0)) revert ZeroAddress();
        address previousReceiver = policy.creatorPayoutReceiver;
        policy.creatorPayoutReceiver = newReceiver;
        emit CreatorPayoutReceiverUpdated(pool, previousReceiver, newReceiver);
    }

    function _registerPool(
        address pool,
        uint8 poolTypeId,
        address creatorFeeSplitter,
        address creatorController,
        address creatorPayoutReceiver,
        address creatorPartnerRevenueReceiver,
        address adminPartnerRevenueReceiver,
        CreatorFeeConfig memory creatorFeeConfig,
        AdminFeeConfig memory adminFeeConfig,
        PartnerPoLConfig memory partnerPoLConfig
    ) private {
        if (
            pool == address(0) || creatorFeeSplitter == address(0) || creatorController == address(0)
                || creatorPayoutReceiver == address(0)
        ) {
            revert ZeroAddress();
        }
        if (_policies[pool].registered) revert AlreadyRegistered();
        if (poolTypeId > uint8(PoolType.ReClamm)) revert UnsupportedPoolType();

        _validateCreatorConfig(creatorFeeConfig, creatorPartnerRevenueReceiver);
        _validateAdminConfig(adminFeeConfig);
        if (adminFeeConfig.adminPartnerRevenueBps != 0 && adminPartnerRevenueReceiver == address(0)) {
            revert MissingPartnerRevenueReceiver();
        }
        _validatePartnerPoLConfig(pool, partnerPoLConfig, adminFeeConfig);
        PoolType poolType = PoolType(poolTypeId);
        _validatePoolTypePolicyCompatibility(poolType, creatorFeeConfig, adminFeeConfig, partnerPoLConfig);

        PoolPolicy storage policy = _policies[pool];
        policy.registered = true;
        policy.poolType = poolType;
        policy.creatorFeeSplitter = creatorFeeSplitter;
        policy.creatorController = creatorController;
        policy.creatorPayoutReceiver = creatorPayoutReceiver;
        policy.creatorPartnerRevenueReceiver = creatorPartnerRevenueReceiver;
        policy.adminPartnerRevenueReceiver = adminPartnerRevenueReceiver;
        policy.creatorFeeConfig = creatorFeeConfig;
        policy.adminFeeConfig = adminFeeConfig;
        policy.partnerPoLConfig = partnerPoLConfig;

        emit PoolRegistered(
            pool,
            poolType,
            creatorFeeSplitter,
            creatorController,
            creatorPayoutReceiver
        );
        _syncCreatorFeeSplitter(creatorFeeSplitter);
    }

    function _syncCreatorFeeSplitter(address creatorFeeSplitter) private {
        if (creatorFeeSplitter.code.length == 0) revert InvalidCreatorFeeSplitter();
        ICreatorFeeSync(creatorFeeSplitter).syncCreatorSwapFee();
    }

    function _validateCreatorConfig(CreatorFeeConfig memory creatorConfig, address partnerReceiver) private pure {
        CurveYieldFeeMath.validateCreatorBps(
            creatorConfig.creatorPersonalBps,
            creatorConfig.creatorPermanentLiquidityBps,
            creatorConfig.creatorPartnerRevenueBps
        );
        if (creatorConfig.creatorPartnerRevenueBps != 0 && partnerReceiver == address(0)) {
            revert MissingPartnerRevenueReceiver();
        }
    }

    function _validateAdminConfig(AdminFeeConfig memory adminConfig) private pure {
        uint256 fixedObligations = uint256(adminConfig.adminCreatorPermanentLiquidityBps)
            + adminConfig.adminExtraPermanentPoLBps + adminConfig.adminPartnerRevenueBps;
        if (fixedObligations > CurveYieldFeeMath.BPS) revert AdminFixedObligationsTooHigh();
    }

    function _validatePoolTypePolicyCompatibility(
        PoolType poolType,
        CreatorFeeConfig memory creatorConfig,
        AdminFeeConfig memory adminConfig,
        PartnerPoLConfig memory partnerPoLConfig
    ) private pure {
        if (poolType == PoolType.ReClamm) {
            if (
                creatorConfig.creatorPermanentLiquidityBps != 0
                    || adminConfig.adminCreatorPermanentLiquidityBps != 0
                    || adminConfig.adminExtraPermanentPoLBps != 0
                    || partnerPoLConfig.enabled
            ) {
                revert ReClammBptSettlementUnsupported();
            }
        }
    }

    function _validatePartnerPoLConfig(
        address pool,
        PartnerPoLConfig memory config,
        AdminFeeConfig memory adminConfig
    )
        private
        view
    {
        if (!config.enabled) {
            if (config.targetPool != address(0)) {
                revert InvalidPartnerPoLConfig();
            }
            return;
        }
        if (config.targetPool == address(0) || adminConfig.adminExtraPermanentPoLBps == 0) {
            revert InvalidPartnerPoLConfig();
        }
        if (config.targetPool != pool) {
            if (!_policies[config.targetPool].registered) {
                revert InvalidPartnerPoLConfig();
            }
            if (_policies[config.targetPool].poolType == PoolType.ReClamm) {
                revert ReClammBptSettlementUnsupported();
            }
        }
        if (!_poolsShareToken(pool, config.targetPool)) {
            revert InvalidPartnerPoLConfig();
        }
        if (vault.getHooksConfig(config.targetPool).hooksContract == address(0)) {
            revert InvalidPartnerPoLConfig();
        }
    }

    function _poolsShareToken(address pool, address targetPool) private view returns (bool) {
        if (pool == targetPool) return true;
        address[] memory sourceTokens = vault.getPoolTokens(pool);
        address[] memory targetTokens = vault.getPoolTokens(targetPool);
        for (uint256 i = 0; i < sourceTokens.length; ++i) {
            for (uint256 j = 0; j < targetTokens.length; ++j) {
                if (sourceTokens[i] == targetTokens[j]) {
                    return true;
                }
            }
        }
        return false;
    }

    function _registeredPolicy(address pool) private view returns (PoolPolicy storage policy) {
        policy = _policies[pool];
        if (!policy.registered) revert NotRegistered();
    }

    function _registeredPolicyView(address pool) private view returns (PoolPolicy storage policy) {
        policy = _policies[pool];
        if (!policy.registered) revert NotRegistered();
    }
}
