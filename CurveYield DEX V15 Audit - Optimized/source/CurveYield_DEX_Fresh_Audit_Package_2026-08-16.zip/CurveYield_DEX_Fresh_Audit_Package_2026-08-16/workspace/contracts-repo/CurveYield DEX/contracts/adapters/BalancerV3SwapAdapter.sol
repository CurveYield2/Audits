// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import { AragonOwned } from "../access/AragonOwned.sol";
import { IBalancerV3Router } from "../interfaces/IBalancerV3Router.sol";
import { ISwapAdapter } from "../interfaces/ISwapAdapter.sol";
import { SafeERC20Transfer } from "../utils/SafeERC20Transfer.sol";

interface IPermit2Approve {
    function approve(address token, address spender, uint160 amount, uint48 expiration) external;
}

contract BalancerV3SwapAdapter is AragonOwned, ISwapAdapter {
    struct BalancerSingleSwapRoute {
        address pool;
        bool wethIsEth;
        bytes userData;
    }

    IBalancerV3Router public immutable router;
    mapping(address => bool) public isAuthorizedCaller;

    error Permit2AmountOverflow();
    error UnauthorizedCaller();

    event AuthorizedCallerUpdated(address indexed caller, bool approved);
    event TokenRecovered(address indexed token, address indexed receiver, uint256 amount);

    modifier onlyAuthorizedCaller() {
        if (!isAuthorizedCaller[msg.sender]) revert UnauthorizedCaller();
        _;
    }

    constructor(address initialOwner, address router_, address authorizedCaller) AragonOwned(initialOwner) {
        if (router_ == address(0) || authorizedCaller == address(0)) revert ZeroAddress();
        router = IBalancerV3Router(router_);
        isAuthorizedCaller[authorizedCaller] = true;
        emit AuthorizedCallerUpdated(authorizedCaller, true);
    }

    function setAuthorizedCaller(address caller, bool approved) external onlyOwner {
        if (caller == address(0)) revert ZeroAddress();
        isAuthorizedCaller[caller] = approved;
        emit AuthorizedCallerUpdated(caller, approved);
    }

    function quote(address tokenIn, address tokenOut, uint256 amountIn, bytes calldata routeData)
        external
        override
        returns (uint256 amountOut)
    {
        (address pool,, bytes memory userData) = abi.decode(routeData, (address, bool, bytes));
        return router.querySwapSingleTokenExactIn(pool, tokenIn, tokenOut, amountIn, address(this), userData);
    }

    function swap(address tokenIn, address tokenOut, uint256 amountIn, uint256 minAmountOut, bytes calldata routeData)
        external
        override
        onlyAuthorizedCaller
        returns (uint256 amountOut)
    {
        (address pool, bool wethIsEth, bytes memory userData) = abi.decode(routeData, (address, bool, bytes));
        if (amountIn > type(uint160).max) revert Permit2AmountOverflow();
        address permit2 = router.getPermit2();
        SafeERC20Transfer.safeApprove(tokenIn, permit2, amountIn);
        IPermit2Approve(permit2).approve(tokenIn, address(router), uint160(amountIn), type(uint48).max);
        amountOut = router.swapSingleTokenExactIn(
            pool,
            tokenIn,
            tokenOut,
            amountIn,
            minAmountOut,
            block.timestamp,
            wethIsEth,
            userData
        );
        IPermit2Approve(permit2).approve(tokenIn, address(router), 0, 0);
        SafeERC20Transfer.safeApprove(tokenIn, permit2, 0);
        SafeERC20Transfer.safeTransfer(tokenOut, msg.sender, amountOut);
    }

    function recoverToken(address token, address receiver, uint256 amount) external onlyOwner {
        if (token == address(0) || receiver == address(0)) revert ZeroAddress();
        SafeERC20Transfer.safeTransfer(token, receiver, amount);
        emit TokenRecovered(token, receiver, amount);
    }
}
