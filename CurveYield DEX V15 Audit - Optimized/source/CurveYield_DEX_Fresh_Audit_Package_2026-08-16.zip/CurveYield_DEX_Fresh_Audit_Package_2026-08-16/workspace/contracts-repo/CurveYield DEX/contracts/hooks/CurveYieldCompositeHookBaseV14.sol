// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract is derived from Balancer's hook, authentication, registry, and oracle architecture.
 * Balancer's gracious use of open-source GPL licensing allows CurveYield to use it for the good of all.
 */

import { IERC20 } from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import { Math } from "@openzeppelin/contracts/utils/math/Math.sol";

import {
    IBalancerContractRegistry
} from "@balancer-labs/v3-interfaces/contracts/standalone-utils/IBalancerContractRegistry.sol";
import { IStablePool } from "@balancer-labs/v3-interfaces/contracts/pool-stable/IStablePool.sol";
import { IWeightedPool } from "@balancer-labs/v3-interfaces/contracts/pool-weighted/IWeightedPool.sol";
import { ISenderGuard } from "@balancer-labs/v3-interfaces/contracts/vault/ISenderGuard.sol";
import { IVault } from "@balancer-labs/v3-interfaces/contracts/vault/IVault.sol";
import {
    AddLiquidityKind,
    LiquidityManagement,
    PoolData,
    PoolSwapParams,
    SwapKind,
    TokenConfig
} from "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";
import {
    ScalingHelpers
} from "@balancer-labs/v3-solidity-utils/contracts/helpers/ScalingHelpers.sol";
import { BaseHooks } from "@balancer-labs/v3-vault/contracts/BaseHooks.sol";
import {
    SingletonAuthentication
} from "@balancer-labs/v3-vault/contracts/SingletonAuthentication.sol";
import { VaultGuard } from "@balancer-labs/v3-vault/contracts/VaultGuard.sol";

import { PoolFeePolicyRegistry } from "../PoolFeePolicyRegistry.sol";
import { IBalancerV3Vault } from "../interfaces/IBalancerV3Vault.sol";
import {
    ICurveYieldFactoryProvenance
} from "../interfaces/ICurveYieldFactoryProvenance.sol";
import { CurveYieldHookConfigController } from "./CurveYieldHookConfigController.sol";
import {
    CurveYieldObservationController
} from "./CurveYieldObservationController.sol";
import {
    CurveYieldVolumeFeeController
} from "./CurveYieldVolumeFeeController.sol";
import {
    CurveYieldPoolKind,
    FactoryNotApproved,
    InvalidPoolKind,
    InvalidTokenCount,
    PoolFactoryMismatch,
    ProtectedBptMinimumTooLow,
    ProtectedSettlementIsPaused
} from "./CurveYieldHookTypes.sol";

abstract contract CurveYieldCompositeHookBaseV14 is BaseHooks, VaultGuard, SingletonAuthentication {
    using ScalingHelpers for uint256;

    IBalancerContractRegistry internal immutable _balancerContractRegistry;
    PoolFeePolicyRegistry internal immutable _poolFeePolicyRegistry;
    CurveYieldHookConfigController internal immutable _hookConfigController;
    CurveYieldObservationController internal immutable _observationController;
    CurveYieldVolumeFeeController internal immutable _volumeFeeController;

    error ZeroAddress();
    error InvalidTrustedRouterRegistry();
    error PolicyRegistryVaultMismatch(address expectedVault, address actualVault);
    error FactoryVaultMismatch(address factory, address expectedVault, address actualVault);
    error PoolTokenOrderMismatch(
        address pool,
        uint256 tokenIndex,
        address expectedToken,
        address suppliedToken
    );
    error RequiredPoolInterfaceMissing(address pool, CurveYieldPoolKind kind);

    event PoolAdmitted(
        address indexed factory,
        address indexed pool,
        CurveYieldPoolKind indexed kind
    );

    constructor(
        IVault vault,
        IBalancerContractRegistry balancerContractRegistry,
        PoolFeePolicyRegistry poolFeePolicyRegistry,
        CurveYieldHookConfigController hookConfigController,
        CurveYieldObservationController observationController,
        CurveYieldVolumeFeeController volumeFeeController
    ) VaultGuard(vault) SingletonAuthentication(vault) {
        if (
            address(vault) == address(0) ||
            address(balancerContractRegistry) == address(0) ||
            address(poolFeePolicyRegistry) == address(0) ||
            address(hookConfigController) == address(0) ||
            address(observationController) == address(0) ||
            address(volumeFeeController) == address(0)
        ) {
            revert ZeroAddress();
        }
        if (address(balancerContractRegistry).code.length == 0) {
            revert InvalidTrustedRouterRegistry();
        }

        bool trustsZero;
        try balancerContractRegistry.isTrustedRouter(address(0)) returns (bool trusted) {
            trustsZero = trusted;
        } catch {
            revert InvalidTrustedRouterRegistry();
        }
        if (trustsZero) revert InvalidTrustedRouterRegistry();

        address configuredVault;
        try poolFeePolicyRegistry.vault() returns (IBalancerV3Vault policyVault) {
            configuredVault = address(policyVault);
        } catch {
            revert PolicyRegistryVaultMismatch(address(vault), address(0));
        }
        if (configuredVault != address(vault)) {
            revert PolicyRegistryVaultMismatch(address(vault), configuredVault);
        }

        _balancerContractRegistry = balancerContractRegistry;
        _poolFeePolicyRegistry = poolFeePolicyRegistry;
        _hookConfigController = hookConfigController;
        _observationController = observationController;
        _volumeFeeController = volumeFeeController;
    }

    function onRegister(
        address factory,
        address pool,
        TokenConfig[] memory tokenConfig,
        LiquidityManagement calldata
    ) public virtual override onlyVault returns (bool) {
        CurveYieldPoolKind kind = _hookConfigController.factoryPoolKind(factory);
        if (kind == CurveYieldPoolKind.NONE) revert FactoryNotApproved(factory);
        if (!_supportsPoolKind(kind)) revert InvalidPoolKind(kind);

        address factoryVault;
        try ICurveYieldFactoryProvenance(factory).getVault() returns (address value) {
            factoryVault = value;
        } catch {
            revert FactoryVaultMismatch(factory, address(_vault), address(0));
        }
        if (factoryVault != address(_vault)) {
            revert FactoryVaultMismatch(factory, address(_vault), factoryVault);
        }

        bool poolFromFactory;
        try ICurveYieldFactoryProvenance(factory).isPoolFromFactory(pool) returns (bool value) {
            poolFromFactory = value;
        } catch {
            revert PoolFactoryMismatch(pool, factory);
        }
        if (!poolFromFactory) revert PoolFactoryMismatch(pool, factory);

        uint256 tokenCount = tokenConfig.length;
        if (tokenCount < 2 || tokenCount > 8) revert InvalidTokenCount(tokenCount);

        IERC20[] memory registeredTokens = _vault.getPoolTokens(pool);
        if (registeredTokens.length != tokenCount) {
            revert PoolTokenOrderMismatch(pool, type(uint256).max, address(0), address(0));
        }
        for (uint256 i = 0; i < tokenCount; ++i) {
            address expectedToken = address(registeredTokens[i]);
            address suppliedToken = address(tokenConfig[i].token);
            if (expectedToken != suppliedToken) {
                revert PoolTokenOrderMismatch(pool, i, expectedToken, suppliedToken);
            }
        }

        _requirePoolInterface(pool, kind);
        _hookConfigController.registerPool(pool, kind);
        _observationController.registerObservationPool(factory, pool, tokenConfig, kind);
        _volumeFeeController.registerPool(pool, kind);

        emit PoolAdmitted(factory, pool, kind);
        return true;
    }

    function creatorController(address pool) external view returns (address) {
        return _poolFeePolicyRegistry.creatorControllerOf(pool);
    }

    function registeredPoolKind(address pool) external view returns (CurveYieldPoolKind) {
        return _hookConfigController.registeredPoolKind(pool);
    }

    function getBalancerContractRegistry() external view virtual returns (IBalancerContractRegistry) {
        return _balancerContractRegistry;
    }

    function getPoolFeePolicyRegistry() external view returns (PoolFeePolicyRegistry) {
        return _poolFeePolicyRegistry;
    }

    function getHookConfigController() external view returns (CurveYieldHookConfigController) {
        return _hookConfigController;
    }

    function getObservationController() external view returns (CurveYieldObservationController) {
        return _observationController;
    }

    function getVolumeFeeController() external view returns (CurveYieldVolumeFeeController) {
        return _volumeFeeController;
    }

    function initializeObservation(address pool) external {
        _observationController.initializeObservation(pool);
    }

    function checkpoint(address pool) external {
        _observationController.checkpoint(pool);
    }

    function isObservationWarm(address pool) external view returns (bool) {
        return _observationController.isObservationWarm(pool);
    }

    function getCurrentVolumeSurcharge(address pool) external view returns (uint256) {
        return _currentVolumeSurcharge(pool);
    }

    function quoteOracleProtectedBptOut(
        address pool,
        uint256[] calldata exactAmountsInRaw
    ) external view returns (uint256 oracleExpectedBptOut, uint256 oracleMinBptOut) {
        _ensureProtectedSettlementActive();
        (uint32 window, uint16 slippageBps) = _hookConfigController.settlementOracleConfig(pool);
        return _observationController.quoteOracleProtectedBptOut(
            pool,
            exactAmountsInRaw,
            window,
            slippageBps
        );
    }

    function quoteOracleProtectedBptOutScaled18(
        address pool,
        uint256[] calldata exactAmountsInScaled18
    ) external view returns (uint256 oracleExpectedBptOut, uint256 oracleMinBptOut) {
        _ensureProtectedSettlementActive();
        (uint32 window, uint16 slippageBps) = _hookConfigController.settlementOracleConfig(pool);
        return _observationController.quoteOracleProtectedBptOutScaled18(
            pool,
            exactAmountsInScaled18,
            window,
            slippageBps
        );
    }

    function quoteOracleProtectedSwapOut(
        address pool,
        address tokenIn,
        address tokenOut,
        uint256 amountInRaw
    ) external view returns (uint256 oracleExpectedAmountOut, uint256 oracleMinAmountOut) {
        _ensureProtectedSettlementActive();
        (uint32 window, uint16 slippageBps) = _hookConfigController.settlementOracleConfig(pool);
        uint256 swapFeePercentage =
            _settlementSwapFeePercentage(pool, tokenIn, tokenOut, amountInRaw, msg.sender);
        return _observationController.quoteOracleProtectedSwapOut(
            pool,
            tokenIn,
            tokenOut,
            amountInRaw,
            window,
            slippageBps,
            swapFeePercentage
        );
    }

    function _supportsPoolKind(CurveYieldPoolKind kind) internal view virtual returns (bool);

    function _settlementSwapFeePercentage(
        address pool,
        address tokenIn,
        address tokenOut,
        uint256 amountInRaw,
        address settlementCaller
    ) internal view returns (uint256) {
        PoolData memory data = _vault.getPoolData(pool);
        (uint256 indexIn, uint256 indexOut) = _findPoolDataTokenIndexes(data, tokenIn, tokenOut);
        uint256 amountInScaled18 = amountInRaw.toScaled18ApplyRateRoundDown(
            data.decimalScalingFactors[indexIn],
            data.tokenRates[indexIn]
        );
        PoolSwapParams memory params = PoolSwapParams({
            kind: SwapKind.EXACT_IN,
            amountGivenScaled18: amountInScaled18,
            balancesScaled18: data.balancesLiveScaled18,
            indexIn: indexIn,
            indexOut: indexOut,
            router: address(0),
            userData: ""
        });
        return _computeSettlementSwapFeePercentage(
            params,
            pool,
            _vault.getStaticSwapFeePercentage(pool),
            settlementCaller
        );
    }

    function _computeSettlementSwapFeePercentage(
        PoolSwapParams memory params,
        address pool,
        uint256 staticSwapFeePercentage,
        address
    ) internal view virtual returns (uint256) {
        uint256 selectedTokenIndex = params.kind == SwapKind.EXACT_IN
            ? params.indexIn
            : params.indexOut;
        uint256 volumeSurcharge = _volumeFeeController.previewVolumeSurcharge(
            pool,
            params.amountGivenScaled18,
            selectedTokenIndex,
            params.balancesScaled18
        );
        uint256 combined = staticSwapFeePercentage + volumeSurcharge;
        uint256 capped = Math.min(combined, _hookConfigController.effectiveCombinedFeeCap(pool));
        return Math.max(staticSwapFeePercentage, capped);
    }

    function _isProtectedSettlementCaller(address router) internal view returns (bool) {
        if (!_balancerContractRegistry.isTrustedRouter(router)) return false;
        address originalSender = ISenderGuard(router).getSender();
        return _hookConfigController.isSettlementRouter(originalSender);
    }

    function _ensureProtectedSettlementActive() internal view {
        if (_hookConfigController.protectedSettlementPaused()) revert ProtectedSettlementIsPaused();
    }

    function _validateProtectedSettlementAdd(
        address router,
        address pool,
        AddLiquidityKind kind,
        uint256[] memory maxAmountsInScaled18,
        uint256 minBptAmountOut
    ) internal view {
        if (!_isProtectedSettlementCaller(router)) return;
        _ensureProtectedSettlementActive();
        if (kind != AddLiquidityKind.UNBALANCED) return;

        (uint32 window, uint16 slippageBps) = _hookConfigController.settlementOracleConfig(pool);
        (, uint256 requiredMinimum) = _observationController.quoteOracleProtectedBptOutScaled18(
            pool,
            maxAmountsInScaled18,
            window,
            slippageBps
        );
        if (minBptAmountOut < requiredMinimum) {
            revert ProtectedBptMinimumTooLow(
                pool,
                minBptAmountOut,
                requiredMinimum
            );
        }
    }

    function _observe(address pool, uint256[] memory balancesScaled18) internal {
        _observationController.observe(pool, balancesScaled18);
    }

    function _recordSwapActivity(
        address pool,
        uint256 amountGivenScaled18,
        uint256 selectedTokenIndex,
        uint256[] memory balancesScaled18
    ) internal returns (uint128 activity) {
        return _volumeFeeController.recordSwapActivity(
            pool,
            amountGivenScaled18,
            selectedTokenIndex,
            balancesScaled18
        );
    }

    function _currentVolumeSurcharge(address pool) internal view returns (uint256) {
        return _volumeFeeController.currentVolumeSurcharge(pool);
    }

    function _previewVolumeSurcharge(
        address pool,
        uint256 amountGivenScaled18,
        uint256 selectedTokenIndex,
        uint256[] memory balancesScaled18
    ) internal view returns (uint256) {
        return _volumeFeeController.previewVolumeSurcharge(
            pool,
            amountGivenScaled18,
            selectedTokenIndex,
            balancesScaled18
        );
    }

    function _findPoolDataTokenIndexes(
        PoolData memory data,
        address tokenIn,
        address tokenOut
    ) private pure returns (uint256 indexIn, uint256 indexOut) {
        bool foundIn;
        bool foundOut;
        for (uint256 i = 0; i < data.tokens.length; ++i) {
            address token = address(data.tokens[i]);
            if (token == tokenIn) {
                indexIn = i;
                foundIn = true;
            }
            if (token == tokenOut) {
                indexOut = i;
                foundOut = true;
            }
        }
        if (!foundIn || !foundOut) revert InvalidTokenCount(data.tokens.length);
    }

    function _poolKind(address pool) internal view returns (CurveYieldPoolKind kind) {
        kind = _hookConfigController.registeredPoolKind(pool);
    }

    function _requirePoolInterface(address pool, CurveYieldPoolKind kind) private view {
        if (kind == CurveYieldPoolKind.WEIGHTED) {
            try IWeightedPool(pool).getNormalizedWeights() returns (uint256[] memory) {
                return;
            } catch {
                revert RequiredPoolInterfaceMissing(pool, kind);
            }
        }

        try IStablePool(pool).getAmplificationParameter() returns (
            uint256,
            bool,
            uint256
        ) {
            return;
        } catch {
            revert RequiredPoolInterfaceMissing(pool, kind);
        }
    }
}
