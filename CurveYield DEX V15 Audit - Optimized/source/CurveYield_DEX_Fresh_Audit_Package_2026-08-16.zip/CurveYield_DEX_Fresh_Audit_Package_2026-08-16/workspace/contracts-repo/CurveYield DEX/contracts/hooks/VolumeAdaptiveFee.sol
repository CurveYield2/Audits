// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract supports a CurveYield implementation derived from Balancer's smart contracts.
 * Balancer's gracious use of open-source GPL licensing allows CurveYield to use it for the good of all.
 */

import { FixedPoint } from "@balancer-labs/v3-solidity-utils/contracts/math/FixedPoint.sol";
import { Math } from "@openzeppelin/contracts/utils/math/Math.sol";

import {
    CurveYieldPoolKind,
    InvalidHalfLife,
    InvalidPoolKind,
    InvalidReactiveness,
    InvalidVolumeSurcharge
} from "./CurveYieldHookTypes.sol";

library VolumeAdaptiveFee {
    uint256 internal constant WAD = 1e18;
    uint256 internal constant HALF_WAD = 0.5e18;
    uint256 internal constant WEIGHTED_MAX_SURCHARGE = 0.05e18;
    uint256 internal constant STABLE_MAX_SURCHARGE = 0.02e18;
    uint256 internal constant DIRECT_POW_MAX_EXPONENT = 40e18;

    error ZeroTurnoverDenominator();
    error ZeroActivityThreshold();
    error ZeroHalfLifeSeconds();

    function weightedTurnover(
        uint256 amountGivenScaled18,
        uint256 selectedWeight,
        uint256 selectedBalanceScaled18
    ) internal pure returns (uint256) {
        if (selectedBalanceScaled18 == 0) revert ZeroTurnoverDenominator();
        return Math.mulDiv(amountGivenScaled18, selectedWeight, selectedBalanceScaled18, Math.Rounding.Ceil);
    }

    function stableTurnover(
        uint256 amountGivenScaled18,
        uint256[] memory balancesScaled18
    ) internal pure returns (uint256) {
        uint256 totalBalance;
        for (uint256 i = 0; i < balancesScaled18.length; ++i) {
            totalBalance = Math.saturatingAdd(totalBalance, balancesScaled18[i]);
        }
        if (totalBalance == 0) revert ZeroTurnoverDenominator();
        return Math.mulDiv(amountGivenScaled18, WAD, totalBalance, Math.Rounding.Ceil);
    }

    function decayActivity(
        uint256 previousActivity,
        uint256 elapsedSeconds,
        uint256 halfLifeSeconds
    ) internal pure returns (uint256) {
        if (halfLifeSeconds == 0) revert ZeroHalfLifeSeconds();
        if (previousActivity == 0 || elapsedSeconds == 0) return previousActivity;

        uint256 exponent = Math.mulDiv(elapsedSeconds, WAD, halfLifeSeconds);
        if (exponent <= DIRECT_POW_MAX_EXPONENT) {
            uint256 decayFactor = FixedPoint.powUp(HALF_WAD, exponent);
            return FixedPoint.mulUp(previousActivity, decayFactor);
        }

        uint256 wholeHalfLives = exponent / WAD;
        if (wholeHalfLives >= 128) return 1;

        uint256 decayedActivity = Math.ceilDiv(previousActivity, uint256(1) << wholeHalfLives);
        uint256 fractionalExponent = exponent % WAD;
        if (fractionalExponent == 0) return decayedActivity;

        uint256 fractionalDecayFactor = FixedPoint.powUp(HALF_WAD, fractionalExponent);
        return FixedPoint.mulUp(decayedActivity, fractionalDecayFactor);
    }

    function nextActivity(
        uint256 previousActivity,
        uint256 turnover,
        uint256 elapsedSeconds,
        uint256 halfLifeSeconds
    ) internal pure returns (uint128) {
        uint256 decayedActivity = decayActivity(previousActivity, elapsedSeconds, halfLifeSeconds);
        uint256 accumulatedActivity = Math.saturatingAdd(decayedActivity, turnover);
        return uint128(Math.min(accumulatedActivity, type(uint128).max));
    }

    function threshold(
        CurveYieldPoolKind kind,
        uint8 reactiveness,
        uint8 halfLifeHours
    ) internal pure returns (uint256) {
        _validatePoolKind(kind);
        _validateReactivenessAndHalfLife(reactiveness, halfLifeHours);

        uint256 sensitivity = WAD + Math.mulDiv(19e18, reactiveness - 1, 99);

        uint256 weightedBaseThreshold;
        if (halfLifeHours <= 12) {
            weightedBaseThreshold = uint256(halfLifeHours) * 0.10e18;
        } else if (halfLifeHours <= 24) {
            weightedBaseThreshold = 1.20e18 + Math.mulDiv(halfLifeHours - 12, 0.80e18, 12);
        } else {
            weightedBaseThreshold = Math.mulDiv(2.00e18, halfLifeHours, 24);
        }

        uint256 poolKindBaseThreshold = kind == CurveYieldPoolKind.WEIGHTED
            ? weightedBaseThreshold
            : 4 * weightedBaseThreshold;

        return Math.mulDiv(poolKindBaseThreshold, WAD, sensitivity);
    }

    function volumeSurcharge(
        uint256 activity,
        uint256 thresholdValue,
        uint256 maximumSurcharge
    ) internal pure returns (uint256) {
        if (thresholdValue == 0) revert ZeroActivityThreshold();

        uint256 t = Math.min(FixedPoint.divUp(activity, thresholdValue), WAD);
        uint256 t2 = FixedPoint.mulUp(t, t);
        uint256 t3 = FixedPoint.mulDown(t2, t);
        uint256 factor = Math.min((3 * t2) - (2 * t3), WAD);
        return Math.min(FixedPoint.mulUp(maximumSurcharge, factor), maximumSurcharge);
    }

    function validateConfig(
        CurveYieldPoolKind kind,
        uint256 maxVolumeSurcharge,
        uint8 reactiveness,
        uint8 halfLifeHours
    ) internal pure {
        _validatePoolKind(kind);
        _validateReactivenessAndHalfLife(reactiveness, halfLifeHours);

        uint256 maximum = kind == CurveYieldPoolKind.WEIGHTED
            ? WEIGHTED_MAX_SURCHARGE
            : STABLE_MAX_SURCHARGE;
        if (maxVolumeSurcharge > maximum) revert InvalidVolumeSurcharge(maxVolumeSurcharge);
    }

    function _validatePoolKind(CurveYieldPoolKind kind) private pure {
        if (
            kind != CurveYieldPoolKind.WEIGHTED &&
            kind != CurveYieldPoolKind.STABLE &&
            kind != CurveYieldPoolKind.STABLE_SURGE
        ) {
            revert InvalidPoolKind(kind);
        }
    }

    function _validateReactivenessAndHalfLife(uint8 reactiveness, uint8 halfLifeHours) private pure {
        if (reactiveness < 1 || reactiveness > 100) revert InvalidReactiveness(reactiveness);
        if (halfLifeHours < 1 || halfLifeHours > 48) revert InvalidHalfLife(halfLifeHours);
    }
}
