// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract is a fork of one of Balancer's reCLAMM smart contracts. Balancer's gracious use of
 * open-source GPL licensing allows CurveYield to use it for the good of all.
 */

import { SafeCast } from "@openzeppelin/contracts/utils/math/SafeCast.sol";
// solhint-disable-next-line no-unused-import
import { IERC20 } from "@openzeppelin/contracts/token/ERC20/IERC20.sol";

import { IPoolVersion } from "@balancer-labs/v3-interfaces/contracts/solidity-utils/helpers/IPoolVersion.sol";
import { IVault } from "@balancer-labs/v3-interfaces/contracts/vault/IVault.sol";
import {
    TokenConfig,
    PoolRoleAccounts,
    LiquidityManagement
} from "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";

import { BasePoolFactory } from "@balancer-labs/v3-pool-utils/contracts/BasePoolFactory.sol";
import { Version } from "@balancer-labs/v3-solidity-utils/contracts/helpers/Version.sol";

import {
    ReClammPoolFactoryLib,
    ReClammPriceParams
} from "@balancer-labs/v3-pool-reclamm/contracts/lib/ReClammPoolFactoryLib.sol";
import { ReClammPoolParams } from "@balancer-labs/v3-pool-reclamm/contracts/interfaces/IReClammPool.sol";
import { ReClammPool } from "@balancer-labs/v3-pool-reclamm/contracts/ReClammPool.sol";
import { ReClammPoolHelper } from "@balancer-labs/v3-pool-reclamm/contracts/ReClammPoolHelper.sol";

import { CurveYieldFactoryAllowlist } from "./CurveYieldFactoryAllowlist.sol";

/// @notice CurveYield allowlisted fork of Balancer's reCLAMM Pool factory.
contract CurveYieldReClammPoolFactory is IPoolVersion, BasePoolFactory, Version, CurveYieldFactoryAllowlist {
    using SafeCast for uint256;

    // solhint-disable-next-line immutable-vars-naming
    ReClammPoolHelper public immutable reClammPoolHelper;

    string private _poolVersion;

    /// @notice Thrown if the provided helper was not deployed with the same Vault as the factory.
    error WrongHelperDeployment();

    constructor(
        IVault vault,
        ReClammPoolHelper helper,
        uint32 pauseWindowDuration,
        string memory factoryVersion,
        string memory poolVersion,
        address initialOwner
    )
        BasePoolFactory(vault, pauseWindowDuration, type(ReClammPool).creationCode)
        Version(factoryVersion)
        CurveYieldFactoryAllowlist(initialOwner)
    {
        require(address(helper.vault()) == address(getVault()), WrongHelperDeployment());

        reClammPoolHelper = helper;
        _poolVersion = poolVersion;
    }

    /// @inheritdoc IPoolVersion
    function getPoolVersion() external view returns (string memory) {
        return _poolVersion;
    }

    function create(
        string memory name,
        string memory symbol,
        TokenConfig[] memory tokens,
        PoolRoleAccounts memory roleAccounts,
        uint256 swapFeePercentage,
        ReClammPriceParams memory priceParams,
        uint256 dailyPriceShiftExponent,
        uint256 centerednessMargin,
        bytes32 salt
    ) external onlyAllowedPoolCreator returns (address pool) {
        ReClammPoolFactoryLib.validateTokenConfig(tokens, priceParams);

        LiquidityManagement memory liquidityManagement = getDefaultLiquidityManagement();
        liquidityManagement.enableDonation = false;
        liquidityManagement.disableUnbalancedLiquidity = true;

        ReClammPoolParams memory poolParams = ReClammPoolParams({
            name: name,
            symbol: symbol,
            version: _poolVersion,
            initialMinPrice: priceParams.initialMinPrice,
            initialMaxPrice: priceParams.initialMaxPrice,
            initialTargetPrice: priceParams.initialTargetPrice,
            tokenAPriceIncludesRate: priceParams.tokenAPriceIncludesRate,
            tokenBPriceIncludesRate: priceParams.tokenBPriceIncludesRate,
            dailyPriceShiftExponent: dailyPriceShiftExponent,
            centerednessMargin: centerednessMargin.toUint64()
        });

        ReClammPoolFactoryLib.validatePoolParams(poolParams);

        pool = _create(abi.encode(poolParams, getVault(), reClammPoolHelper), salt);

        _registerPoolWithVault(
            pool,
            tokens,
            swapFeePercentage,
            false,
            roleAccounts,
            pool,
            liquidityManagement
        );
    }
}
