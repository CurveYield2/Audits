// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract is derived from Balancer's StableSurgeHook, SurgeHookCommon, and
 * StableSurgeMedianMath. Balancer's gracious use of open-source GPL licensing allows CurveYield to
 * use it for the good of all.
 */

import {
    ISurgeHookCommon
} from "@balancer-labs/v3-interfaces/contracts/pool-hooks/ISurgeHookCommon.sol";
import {
    PoolSwapParams,
    SwapKind
} from "@balancer-labs/v3-interfaces/contracts/vault/VaultTypes.sol";

import { StablePool } from "@balancer-labs/v3-pool-stable/contracts/StablePool.sol";
import {
    ScalingHelpers
} from "@balancer-labs/v3-solidity-utils/contracts/helpers/ScalingHelpers.sol";
import { FixedPoint } from "@balancer-labs/v3-solidity-utils/contracts/math/FixedPoint.sol";

import {
    StableSurgeMedianMath
} from "@balancer-labs/v3-pool-hooks/contracts/utils/StableSurgeMedianMath.sol";

library StableSurgeQueryProcessor {
    using FixedPoint for uint256;

    function computeSwapSurgeFeePercentage(
        PoolSwapParams calldata params,
        address pool,
        uint256 staticSwapFeePercentage,
        ISurgeHookCommon.SurgeFeeData memory surgeFeeData
    ) external view returns (uint256 surgeFeePercentage) {
        (bool isSurging, uint256 newTotalImbalance) = _isSurgingSwap(
            params,
            pool,
            staticSwapFeePercentage,
            surgeFeeData
        );

        if (isSurging) {
            surgeFeePercentage =
                staticSwapFeePercentage +
                (surgeFeeData.maxSurgeFeePercentage - staticSwapFeePercentage).mulDown(
                    (newTotalImbalance - surgeFeeData.thresholdPercentage).divDown(
                        uint256(surgeFeeData.thresholdPercentage).complement()
                    )
                );
        } else {
            surgeFeePercentage = staticSwapFeePercentage;
        }
    }

    function computeSwapSurgeFeePercentageMemory(
        PoolSwapParams memory params,
        address pool,
        uint256 staticSwapFeePercentage,
        ISurgeHookCommon.SurgeFeeData memory surgeFeeData
    ) internal view returns (uint256 surgeFeePercentage) {
        (bool isSurging, uint256 newTotalImbalance) = _isSurgingSwapMemory(
            params,
            pool,
            staticSwapFeePercentage,
            surgeFeeData
        );

        if (isSurging) {
            surgeFeePercentage =
                staticSwapFeePercentage +
                (surgeFeeData.maxSurgeFeePercentage - staticSwapFeePercentage).mulDown(
                    (newTotalImbalance - surgeFeeData.thresholdPercentage).divDown(
                        uint256(surgeFeeData.thresholdPercentage).complement()
                    )
                );
        } else {
            surgeFeePercentage = staticSwapFeePercentage;
        }
    }

    function isSurgingSwap(
        PoolSwapParams calldata params,
        address pool,
        uint256 staticSwapFeePercentage,
        ISurgeHookCommon.SurgeFeeData memory surgeFeeData
    ) external view returns (bool isSurging) {
        (isSurging, ) = _isSurgingSwap(
            params,
            pool,
            staticSwapFeePercentage,
            surgeFeeData
        );
    }

    function isSurgingUnbalancedLiquidity(
        uint64 thresholdPercentage,
        uint256[] memory oldBalancesScaled18,
        uint256[] memory balancesScaled18
    ) external pure returns (bool) {
        uint256 oldTotalImbalance = StableSurgeMedianMath.calculateImbalance(
            oldBalancesScaled18
        );
        uint256 newTotalImbalance = StableSurgeMedianMath.calculateImbalance(
            balancesScaled18
        );
        return _isSurging(
            thresholdPercentage,
            oldTotalImbalance,
            newTotalImbalance
        );
    }

    function _isSurgingSwap(
        PoolSwapParams calldata params,
        address pool,
        uint256 staticSwapFeePercentage,
        ISurgeHookCommon.SurgeFeeData memory surgeFeeData
    ) private view returns (bool isSurging, uint256 newTotalImbalance) {
        if (surgeFeeData.maxSurgeFeePercentage < staticSwapFeePercentage) {
            return (false, 0);
        }

        uint256 amountCalculatedScaled18 = StablePool(pool).onSwap(params);
        uint256[] memory newBalancesScaled18 = new uint256[](
            params.balancesScaled18.length
        );
        ScalingHelpers.copyToArray(
            params.balancesScaled18,
            newBalancesScaled18
        );

        if (params.kind == SwapKind.EXACT_IN) {
            newBalancesScaled18[params.indexIn] += params.amountGivenScaled18;
            newBalancesScaled18[params.indexOut] -= amountCalculatedScaled18;
        } else {
            newBalancesScaled18[params.indexIn] += amountCalculatedScaled18;
            newBalancesScaled18[params.indexOut] -= params.amountGivenScaled18;
        }

        uint256 oldTotalImbalance = StableSurgeMedianMath.calculateImbalance(
            params.balancesScaled18
        );
        newTotalImbalance = StableSurgeMedianMath.calculateImbalance(
            newBalancesScaled18
        );
        isSurging = _isSurging(
            surgeFeeData.thresholdPercentage,
            oldTotalImbalance,
            newTotalImbalance
        );
    }

    function _isSurgingSwapMemory(
        PoolSwapParams memory params,
        address pool,
        uint256 staticSwapFeePercentage,
        ISurgeHookCommon.SurgeFeeData memory surgeFeeData
    ) private view returns (bool isSurging, uint256 newTotalImbalance) {
        if (surgeFeeData.maxSurgeFeePercentage < staticSwapFeePercentage) {
            return (false, 0);
        }

        uint256 amountCalculatedScaled18 = StablePool(pool).onSwap(params);
        uint256[] memory newBalancesScaled18 = new uint256[](
            params.balancesScaled18.length
        );
        ScalingHelpers.copyToArray(
            params.balancesScaled18,
            newBalancesScaled18
        );

        if (params.kind == SwapKind.EXACT_IN) {
            newBalancesScaled18[params.indexIn] += params.amountGivenScaled18;
            newBalancesScaled18[params.indexOut] -= amountCalculatedScaled18;
        } else {
            newBalancesScaled18[params.indexIn] += amountCalculatedScaled18;
            newBalancesScaled18[params.indexOut] -= params.amountGivenScaled18;
        }

        uint256 oldTotalImbalance = StableSurgeMedianMath.calculateImbalance(
            params.balancesScaled18
        );
        newTotalImbalance = StableSurgeMedianMath.calculateImbalance(
            newBalancesScaled18
        );
        isSurging = _isSurging(
            surgeFeeData.thresholdPercentage,
            oldTotalImbalance,
            newTotalImbalance
        );
    }

    function _isSurging(
        uint64 thresholdPercentage,
        uint256 oldTotalImbalance,
        uint256 newTotalImbalance
    ) private pure returns (bool) {
        if (newTotalImbalance == 0) return false;
        return (
            newTotalImbalance > oldTotalImbalance &&
            newTotalImbalance > thresholdPercentage
        );
    }
}
