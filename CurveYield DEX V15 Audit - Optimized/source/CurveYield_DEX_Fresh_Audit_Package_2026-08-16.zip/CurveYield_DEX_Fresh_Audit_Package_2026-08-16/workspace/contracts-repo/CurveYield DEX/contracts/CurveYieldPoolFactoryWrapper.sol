// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import { AragonOwned } from "./access/AragonOwned.sol";
import { CreatorFeeSplitter } from "./CreatorFeeSplitter.sol";
import { IBalancerV3Vault } from "./interfaces/IBalancerV3Vault.sol";
import { IProtocolFeeController } from "./interfaces/IProtocolFeeController.sol";
import { CurveYieldFeeMath } from "./lib/CurveYieldFeeMath.sol";
import { PoolFeePolicyRegistry } from "./PoolFeePolicyRegistry.sol";
import { ReentrancyGuard } from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

enum BalancerTokenType {
    STANDARD,
    WITH_RATE
}

struct BalancerTokenConfig {
    address token;
    BalancerTokenType tokenType;
    address rateProvider;
    bool paysYieldFees;
}

struct BalancerPoolRoleAccounts {
    address pauseManager;
    address swapFeeManager;
    address poolCreator;
}

struct BalancerRoleManagersInput {
    address pauseManager;
    address swapFeeManager;
}

struct StableSurgePoolInput {
    string name;
    string symbol;
    BalancerTokenConfig[] tokens;
    uint256 amplificationParameter;
    BalancerRoleManagersInput roleManagers;
    uint256 swapFeePercentage;
    bool enableDonation;
    bytes32 salt;
}

struct StablePoolInput {
    string name;
    string symbol;
    BalancerTokenConfig[] tokens;
    uint256 amplificationParameter;
    BalancerRoleManagersInput roleManagers;
    uint256 swapFeePercentage;
    address poolHooksContract;
    bool enableDonation;
    bool disableUnbalancedLiquidity;
    bytes32 salt;
}

struct WeightedPoolInput {
    string name;
    string symbol;
    BalancerTokenConfig[] tokens;
    uint256[] normalizedWeights;
    BalancerRoleManagersInput roleManagers;
    uint256 swapFeePercentage;
    address poolHooksContract;
    bool enableDonation;
    bool disableUnbalancedLiquidity;
    bytes32 salt;
}

struct ReClammPriceParams {
    uint256 initialMinPrice;
    uint256 initialMaxPrice;
    uint256 initialTargetPrice;
    bool tokenAPriceIncludesRate;
    bool tokenBPriceIncludesRate;
}

struct ReClammPoolInput {
    string name;
    string symbol;
    BalancerTokenConfig[] tokens;
    BalancerRoleManagersInput roleManagers;
    uint256 swapFeePercentage;
    ReClammPriceParams priceParams;
    uint256 dailyPriceShiftExponent;
    uint256 centerednessMargin;
    bytes32 salt;
}

struct StablePoolNewPoolParams {
    string name;
    string symbol;
    uint256 amplificationParameter;
    string version;
}

struct WeightedPoolNewPoolParams {
    string name;
    string symbol;
    uint256 numTokens;
    uint256[] normalizedWeights;
    string version;
    uint256[] minTokenBalances;
}

struct ReClammPoolParams {
    string name;
    string symbol;
    string version;
    uint256 dailyPriceShiftExponent;
    uint64 centerednessMargin;
    uint256 initialMinPrice;
    uint256 initialMaxPrice;
    uint256 initialTargetPrice;
    bool tokenAPriceIncludesRate;
    bool tokenBPriceIncludesRate;
}

interface ICreatorFeeSplitterRegistrar {
    function setCreatorFeeSplitter(address pool, address splitter) external;
    function setPayoutTokenOverrideFromRegistrar(address pool, address receiver, address token) external;
    function setCreatorPayoutTokenOverrideFromRegistrar(address pool, address token) external;
    function setPartnerPayoutTokenOverrideFromRegistrar(address pool, uint8 partnerRole, address token) external;
}

interface IERC20MetadataLike {
    function decimals() external view returns (uint8);
}

interface IBalancerBasePoolFactory {
    function getDeploymentAddress(bytes memory constructorArgs, bytes32 salt) external view returns (address);
    function getPoolVersion() external view returns (string memory);
    function getVault() external view returns (address);
}

interface IStableSurgePoolFactory is IBalancerBasePoolFactory {
    function create(
        string memory name,
        string memory symbol,
        BalancerTokenConfig[] memory tokens,
        uint256 amplificationParameter,
        BalancerPoolRoleAccounts memory roleAccounts,
        uint256 swapFeePercentage,
        bool enableDonation,
        bytes32 salt
    ) external returns (address pool);
}

interface IStablePoolFactory is IBalancerBasePoolFactory {
    function create(
        string memory name,
        string memory symbol,
        BalancerTokenConfig[] memory tokens,
        uint256 amplificationParameter,
        BalancerPoolRoleAccounts memory roleAccounts,
        uint256 swapFeePercentage,
        address poolHooksContract,
        bool enableDonation,
        bool disableUnbalancedLiquidity,
        bytes32 salt
    ) external returns (address pool);
}

interface IWeightedPoolFactory is IBalancerBasePoolFactory {
    function create(
        string memory name,
        string memory symbol,
        BalancerTokenConfig[] memory tokens,
        uint256[] memory normalizedWeights,
        BalancerPoolRoleAccounts memory roleAccounts,
        uint256 swapFeePercentage,
        address poolHooksContract,
        bool enableDonation,
        bool disableUnbalancedLiquidity,
        bytes32 salt
    ) external returns (address pool);
}

interface IReClammPoolFactory is IBalancerBasePoolFactory {
    function reClammPoolHelper() external view returns (address);

    function create(
        string memory name,
        string memory symbol,
        BalancerTokenConfig[] memory tokens,
        BalancerPoolRoleAccounts memory roleAccounts,
        uint256 swapFeePercentage,
        ReClammPriceParams memory priceParams,
        uint256 dailyPriceShiftExponent,
        uint256 centerednessMargin,
        bytes32 salt
    ) external returns (address pool);
}

contract CurveYieldPoolFactoryWrapper is AragonOwned, ReentrancyGuard {
    struct PoolPolicyInput {
        address creatorController;
        address creatorPayoutReceiver;
        address creatorPayoutToken;
        address creatorPartnerRevenueReceiver;
        address expectedPool;
        bytes32 splitterSalt;
        PoolFeePolicyRegistry.CreatorFeeConfig creatorFeeConfig;
    }

    PoolFeePolicyRegistry public immutable registry;
    IProtocolFeeController public immutable protocolFeeController;
    ICreatorFeeSplitterRegistrar public immutable settlementRouter;
    address public immutable stableSurgeFactory;
    address public immutable stableFactory;
    address public immutable weightedFactory;
    address public immutable reClammFactory;
    address public poolCreationFeeReceiver;
    uint256 public poolCreationFeeWei = 110_000_000_000_000;

    error FactoryCallFailed();
    error UnexpectedPoolAddress();
    error InvalidPoolCreationFee();
    error PoolCreationFeeTransferFailed();
    error InvalidReClammCenterednessMargin();
    error InvalidCreatorPayoutToken();
    error UnsupportedTokenDecimals(uint8 decimals);
    error YieldFeesUnsupported();
    error UnbalancedLiquidityRequired();
    error ReClammBptSettlementUnsupported();

    event PoolCreated(
        address indexed pool,
        address indexed factory,
        address indexed creatorFeeSplitter,
        PoolFeePolicyRegistry.PoolType poolType
    );
    event PoolCreationFeeConfigUpdated(address indexed receiver, uint256 feeWei);

    constructor(
        address initialOwner,
        address registry_,
        address protocolFeeController_,
        address settlementRouter_,
        address stableSurgeFactory_,
        address stableFactory_,
        address weightedFactory_,
        address reClammFactory_
    ) AragonOwned(initialOwner) {
        if (
            registry_ == address(0) || protocolFeeController_ == address(0) || settlementRouter_ == address(0)
                || stableSurgeFactory_ == address(0) || stableFactory_ == address(0) || weightedFactory_ == address(0)
                || reClammFactory_ == address(0)
        ) {
            revert ZeroAddress();
        }

        registry = PoolFeePolicyRegistry(registry_);
        protocolFeeController = IProtocolFeeController(protocolFeeController_);
        settlementRouter = ICreatorFeeSplitterRegistrar(settlementRouter_);
        stableSurgeFactory = stableSurgeFactory_;
        stableFactory = stableFactory_;
        weightedFactory = weightedFactory_;
        reClammFactory = reClammFactory_;
        poolCreationFeeReceiver = initialOwner;
    }

    function setPoolCreationFeeConfig(address receiver, uint256 feeWei) external onlyOwner {
        if (receiver == address(0)) revert ZeroAddress();
        poolCreationFeeReceiver = receiver;
        poolCreationFeeWei = feeWei;
        emit PoolCreationFeeConfigUpdated(receiver, feeWei);
    }

    function computeCreatorFeeSplitterAddress(PoolPolicyInput memory policy) public view returns (address) {
        bytes32 bytecodeHash = keccak256(_creatorFeeSplitterCreationCode(policy));
        return address(uint160(uint256(keccak256(abi.encodePacked(bytes1(0xff), address(this), policy.splitterSalt, bytecodeHash)))));
    }

    function computeStableSurgePoolAddress(StableSurgePoolInput calldata input) external view returns (address) {
        return IBalancerBasePoolFactory(stableSurgeFactory).getDeploymentAddress(
            stableSurgePoolConstructorArgs(input),
            input.salt
        );
    }

    function computeStablePoolAddress(StablePoolInput calldata input) external view returns (address) {
        return IBalancerBasePoolFactory(stableFactory).getDeploymentAddress(stablePoolConstructorArgs(input), input.salt);
    }

    function computeWeightedPoolAddress(WeightedPoolInput calldata input) external view returns (address) {
        return IBalancerBasePoolFactory(weightedFactory).getDeploymentAddress(weightedPoolConstructorArgs(input), input.salt);
    }

    function computeReClammPoolAddress(ReClammPoolInput calldata input) external view returns (address) {
        return IBalancerBasePoolFactory(reClammFactory).getDeploymentAddress(reClammPoolConstructorArgs(input), input.salt);
    }

    function stableSurgePoolConstructorArgs(StableSurgePoolInput calldata input) public view returns (bytes memory) {
        return abi.encode(
            StablePoolNewPoolParams({
                name: input.name,
                symbol: input.symbol,
                amplificationParameter: input.amplificationParameter,
                version: IBalancerBasePoolFactory(stableSurgeFactory).getPoolVersion()
            }),
            IBalancerBasePoolFactory(stableSurgeFactory).getVault()
        );
    }

    function stablePoolConstructorArgs(StablePoolInput calldata input) public view returns (bytes memory) {
        return abi.encode(
            StablePoolNewPoolParams({
                name: input.name,
                symbol: input.symbol,
                amplificationParameter: input.amplificationParameter,
                version: IBalancerBasePoolFactory(stableFactory).getPoolVersion()
            }),
            IBalancerBasePoolFactory(stableFactory).getVault()
        );
    }

    function weightedPoolConstructorArgs(WeightedPoolInput calldata input) public view returns (bytes memory) {
        return abi.encode(
            WeightedPoolNewPoolParams({
                name: input.name,
                symbol: input.symbol,
                numTokens: input.tokens.length,
                normalizedWeights: input.normalizedWeights,
                version: IBalancerBasePoolFactory(weightedFactory).getPoolVersion(),
                minTokenBalances: _computeMinTokenBalances(input.tokens)
            }),
            IBalancerBasePoolFactory(weightedFactory).getVault()
        );
    }

    function reClammPoolConstructorArgs(ReClammPoolInput calldata input) public view returns (bytes memory) {
        if (input.centerednessMargin > type(uint64).max) revert InvalidReClammCenterednessMargin();

        return abi.encode(
            ReClammPoolParams({
                name: input.name,
                symbol: input.symbol,
                version: IBalancerBasePoolFactory(reClammFactory).getPoolVersion(),
                dailyPriceShiftExponent: input.dailyPriceShiftExponent,
                centerednessMargin: uint64(input.centerednessMargin),
                initialMinPrice: input.priceParams.initialMinPrice,
                initialMaxPrice: input.priceParams.initialMaxPrice,
                initialTargetPrice: input.priceParams.initialTargetPrice,
                tokenAPriceIncludesRate: input.priceParams.tokenAPriceIncludesRate,
                tokenBPriceIncludesRate: input.priceParams.tokenBPriceIncludesRate
            }),
            IBalancerBasePoolFactory(reClammFactory).getVault(),
            IReClammPoolFactory(reClammFactory).reClammPoolHelper()
        );
    }

    function createStableSurgePool(StableSurgePoolInput calldata input, PoolPolicyInput calldata policy)
        external
        payable
        nonReentrant
        returns (address pool)
    {
        _validatePolicyInput(policy, PoolFeePolicyRegistry.PoolType.StableSurge);
        _validateTokenConfigs(input.tokens);
        _validatePoolCreationFee();
        address splitter = _deployCreatorFeeSplitter(policy);

        pool = _callFactory(
            stableSurgeFactory,
            abi.encodeWithSelector(
                IStableSurgePoolFactory.create.selector,
                input.name,
                input.symbol,
                input.tokens,
                input.amplificationParameter,
                _roleAccounts(input.roleManagers, splitter),
                input.swapFeePercentage,
                input.enableDonation,
                input.salt
            )
        );

        _finishPoolCreated(pool, stableSurgeFactory, PoolFeePolicyRegistry.PoolType.StableSurge, splitter, policy);
        _transferPoolCreationFee();
    }

    function createStablePool(StablePoolInput calldata input, PoolPolicyInput calldata policy)
        external
        payable
        nonReentrant
        returns (address pool)
    {
        _validatePolicyInput(policy, PoolFeePolicyRegistry.PoolType.Stable);
        _validateUnbalancedLiquidityCompatibility(input.disableUnbalancedLiquidity, policy);
        _validateTokenConfigs(input.tokens);
        _validatePoolCreationFee();
        address splitter = _deployCreatorFeeSplitter(policy);

        pool = _callFactory(
            stableFactory,
            abi.encodeWithSelector(
                IStablePoolFactory.create.selector,
                input.name,
                input.symbol,
                input.tokens,
                input.amplificationParameter,
                _roleAccounts(input.roleManagers, splitter),
                input.swapFeePercentage,
                input.poolHooksContract,
                input.enableDonation,
                input.disableUnbalancedLiquidity,
                input.salt
            )
        );

        _finishPoolCreated(pool, stableFactory, PoolFeePolicyRegistry.PoolType.Stable, splitter, policy);
        _transferPoolCreationFee();
    }

    function createWeightedPool(WeightedPoolInput calldata input, PoolPolicyInput calldata policy)
        external
        payable
        nonReentrant
        returns (address pool)
    {
        _validatePolicyInput(policy, PoolFeePolicyRegistry.PoolType.Weighted);
        _validateUnbalancedLiquidityCompatibility(input.disableUnbalancedLiquidity, policy);
        _validateTokenConfigs(input.tokens);
        _validatePoolCreationFee();
        address splitter = _deployCreatorFeeSplitter(policy);

        pool = _callFactory(
            weightedFactory,
            abi.encodeWithSelector(
                IWeightedPoolFactory.create.selector,
                input.name,
                input.symbol,
                input.tokens,
                input.normalizedWeights,
                _roleAccounts(input.roleManagers, splitter),
                input.swapFeePercentage,
                input.poolHooksContract,
                input.enableDonation,
                input.disableUnbalancedLiquidity,
                input.salt
            )
        );

        _finishPoolCreated(pool, weightedFactory, PoolFeePolicyRegistry.PoolType.Weighted, splitter, policy);
        _transferPoolCreationFee();
    }

    function createReClammPool(ReClammPoolInput calldata input, PoolPolicyInput calldata policy)
        external
        payable
        nonReentrant
        returns (address pool)
    {
        _validatePolicyInput(policy, PoolFeePolicyRegistry.PoolType.ReClamm);
        _validateTokenConfigs(input.tokens);
        _validatePoolCreationFee();
        address splitter = _deployCreatorFeeSplitter(policy);

        pool = _callFactory(
            reClammFactory,
            abi.encodeWithSelector(
                IReClammPoolFactory.create.selector,
                input.name,
                input.symbol,
                input.tokens,
                _roleAccounts(input.roleManagers, splitter),
                input.swapFeePercentage,
                input.priceParams,
                input.dailyPriceShiftExponent,
                input.centerednessMargin,
                input.salt
            )
        );

        _finishPoolCreated(pool, reClammFactory, PoolFeePolicyRegistry.PoolType.ReClamm, splitter, policy);
        _transferPoolCreationFee();
    }

    function _finishPoolCreated(
        address pool,
        address factory,
        PoolFeePolicyRegistry.PoolType poolType,
        address splitter,
        PoolPolicyInput calldata policy
    ) private {
        if (pool != policy.expectedPool) revert UnexpectedPoolAddress();

        registry.registerPoolFromRegistrarDefaults(
            pool,
            uint8(poolType),
            splitter,
            policy.creatorController,
            policy.creatorPayoutReceiver,
            policy.creatorPartnerRevenueReceiver,
            policy.creatorFeeConfig
        );
        CreatorFeeSplitter(splitter).syncCreatorSwapFee();
        settlementRouter.setCreatorFeeSplitter(pool, splitter);
        settlementRouter.setCreatorPayoutTokenOverrideFromRegistrar(
            pool,
            _resolveCreatorPayoutToken(pool, factory, policy.creatorPayoutToken)
        );
        if (policy.creatorPartnerRevenueReceiver != address(0)) {
            settlementRouter.setPartnerPayoutTokenOverrideFromRegistrar(
                pool,
                1,
                _resolveCreatorPayoutToken(pool, factory, policy.creatorPayoutToken)
            );
        }

        emit PoolCreated(pool, factory, splitter, poolType);
    }

    function _callFactory(address factory, bytes memory callData) private returns (address pool) {
        (bool ok, bytes memory returnData) = factory.call(callData);
        if (!ok) {
            if (returnData.length > 0) {
                assembly {
                    revert(add(returnData, 0x20), mload(returnData))
                }
            }
            revert FactoryCallFailed();
        }

        pool = abi.decode(returnData, (address));
    }

    function _validatePoolCreationFee() private view {
        if (msg.value != poolCreationFeeWei) revert InvalidPoolCreationFee();
    }

    function _transferPoolCreationFee() private {
        uint256 feeWei = poolCreationFeeWei;
        if (feeWei == 0) return;
        (bool ok,) = poolCreationFeeReceiver.call{ value: feeWei }("");
        if (!ok) revert PoolCreationFeeTransferFailed();
    }

    function _roleAccounts(BalancerRoleManagersInput calldata managers, address splitter)
        private
        pure
        returns (BalancerPoolRoleAccounts memory)
    {
        return BalancerPoolRoleAccounts({
            pauseManager: managers.pauseManager,
            swapFeeManager: managers.swapFeeManager,
            poolCreator: splitter
        });
    }

    function _deployCreatorFeeSplitter(PoolPolicyInput calldata policy) private returns (address splitter) {
        bytes memory bytecode = _creatorFeeSplitterCreationCode(policy);
        bytes32 salt = policy.splitterSalt;
        assembly {
            splitter := create2(0, add(bytecode, 0x20), mload(bytecode), salt)
        }
        if (splitter == address(0)) revert FactoryCallFailed();
    }

    function _creatorFeeSplitterCreationCode(PoolPolicyInput memory policy) private view returns (bytes memory) {
        return abi.encodePacked(
            type(CreatorFeeSplitter).creationCode,
            abi.encode(
                owner,
                address(registry),
                address(protocolFeeController),
                address(settlementRouter),
                policy.expectedPool
            )
        );
    }

    function _validatePolicyInput(PoolPolicyInput calldata policy, PoolFeePolicyRegistry.PoolType poolType) private pure {
        if (
            policy.creatorController == address(0) || policy.creatorPayoutReceiver == address(0)
                || policy.creatorPayoutToken == address(0) || policy.expectedPool == address(0)
                || (policy.creatorFeeConfig.creatorPartnerRevenueBps != 0
                    && policy.creatorPartnerRevenueReceiver == address(0))
        ) {
            revert ZeroAddress();
        }
        CurveYieldFeeMath.validateCreatorBps(
            policy.creatorFeeConfig.creatorPersonalBps,
            policy.creatorFeeConfig.creatorPermanentLiquidityBps,
            policy.creatorFeeConfig.creatorPartnerRevenueBps
        );
        if (
            poolType == PoolFeePolicyRegistry.PoolType.ReClamm
                && (
                    policy.creatorPayoutToken == policy.expectedPool
                        || policy.creatorFeeConfig.creatorPermanentLiquidityBps != 0
                )
        ) {
            revert ReClammBptSettlementUnsupported();
        }
    }

    function _validateUnbalancedLiquidityCompatibility(bool disableUnbalancedLiquidity, PoolPolicyInput calldata policy)
        private
        view
    {
        if (!disableUnbalancedLiquidity) return;
        PoolFeePolicyRegistry.AdminFeeConfig memory defaultAdminConfig = registry.getDefaultAdminFeeConfig();
        if (
            policy.creatorPayoutToken == policy.expectedPool
                || policy.creatorFeeConfig.creatorPermanentLiquidityBps != 0
                || defaultAdminConfig.adminCreatorPermanentLiquidityBps != 0
                || defaultAdminConfig.adminExtraPermanentPoLBps != 0
        ) {
            revert UnbalancedLiquidityRequired();
        }
    }

    function _resolveCreatorPayoutToken(address pool, address factory, address requestedToken)
        private
        view
        returns (address)
    {
        return _validateResolvedCreatorPayoutToken(pool, factory, requestedToken);
    }

    function _validateResolvedCreatorPayoutToken(address pool, address factory, address requestedToken)
        private
        view
        returns (address)
    {
        if (requestedToken == address(0) || requestedToken == pool) return pool;

        address vaultAddress = IBalancerBasePoolFactory(factory).getVault();
        address[] memory poolTokens = IBalancerV3Vault(vaultAddress).getPoolTokens(pool);
        for (uint256 i = 0; i < poolTokens.length; ++i) {
            if (poolTokens[i] == requestedToken) return requestedToken;
        }

        revert InvalidCreatorPayoutToken();
    }

    function _computeMinTokenBalances(BalancerTokenConfig[] calldata tokens)
        private
        view
        returns (uint256[] memory minTokenBalances)
    {
        uint256 length = tokens.length;
        minTokenBalances = new uint256[](length);

        for (uint256 i; i < length; ++i) {
            uint8 decimals = IERC20MetadataLike(tokens[i].token).decimals();
            if (decimals > 18) revert UnsupportedTokenDecimals(decimals);
            uint256 atomicUnitFloor = 10 ** (18 - decimals);
            minTokenBalances[i] = atomicUnitFloor > 1e6 ? atomicUnitFloor : 1e6;
        }
    }

    function _validateTokenConfigs(BalancerTokenConfig[] calldata tokens) private view {
        for (uint256 i; i < tokens.length; ++i) {
            if (tokens[i].paysYieldFees) revert YieldFeesUnsupported();
            uint8 decimals = IERC20MetadataLike(tokens[i].token).decimals();
            if (decimals > 18) revert UnsupportedTokenDecimals(decimals);
        }
    }
}
