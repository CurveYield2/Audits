// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

import { AragonOwned } from "./access/AragonOwned.sol";

contract RouteRegistry is AragonOwned {
    struct Route {
        address adapter;
        bytes routeData;
        bool enabled;
    }

    error AdapterNotAllowed();
    error RouteDisabled();

    mapping(address => bool) public isAdapterAllowed;
    mapping(bytes32 => Route) private _routes;

    event AdapterWhitelistUpdated(address indexed adapter, bool previousAllowed, bool newAllowed);
    event RouteUpdated(
        address indexed tokenIn,
        address indexed tokenOut,
        address previousAdapter,
        bytes previousRouteData,
        bool previousEnabled,
        address newAdapter,
        bytes newRouteData,
        bool newEnabled
    );

    constructor(address initialOwner) AragonOwned(initialOwner) {}

    function setAdapterAllowed(address adapter, bool allowed) external onlyOwner {
        if (adapter == address(0)) revert ZeroAddress();
        bool previousAllowed = isAdapterAllowed[adapter];
        isAdapterAllowed[adapter] = allowed;
        emit AdapterWhitelistUpdated(adapter, previousAllowed, allowed);
    }

    function setRoute(address tokenIn, address tokenOut, address adapter, bytes calldata routeData, bool enabled)
        external
        onlyOwner
    {
        if (tokenIn == address(0) || tokenOut == address(0) || adapter == address(0)) revert ZeroAddress();
        if (!isAdapterAllowed[adapter]) revert AdapterNotAllowed();

        bytes32 key = _routeKey(tokenIn, tokenOut);
        Route memory previousRoute = _routes[key];

        _routes[key] = Route({ adapter: adapter, routeData: routeData, enabled: enabled });

        emit RouteUpdated(
            tokenIn,
            tokenOut,
            previousRoute.adapter,
            previousRoute.routeData,
            previousRoute.enabled,
            adapter,
            routeData,
            enabled
        );
    }

    function getRoute(address tokenIn, address tokenOut)
        external
        view
        returns (address adapter, bytes memory routeData, bool enabled)
    {
        Route storage route = _routes[_routeKey(tokenIn, tokenOut)];
        return (route.adapter, route.routeData, route.enabled);
    }

    function getExecutableRoute(address tokenIn, address tokenOut)
        external
        view
        returns (address adapter, bytes memory routeData)
    {
        Route storage route = _routes[_routeKey(tokenIn, tokenOut)];
        if (!route.enabled || route.adapter == address(0)) revert RouteDisabled();
        if (!isAdapterAllowed[route.adapter]) revert AdapterNotAllowed();
        return (route.adapter, route.routeData);
    }

    function _routeKey(address tokenIn, address tokenOut) private pure returns (bytes32) {
        return keccak256(abi.encode(tokenIn, tokenOut));
    }
}
