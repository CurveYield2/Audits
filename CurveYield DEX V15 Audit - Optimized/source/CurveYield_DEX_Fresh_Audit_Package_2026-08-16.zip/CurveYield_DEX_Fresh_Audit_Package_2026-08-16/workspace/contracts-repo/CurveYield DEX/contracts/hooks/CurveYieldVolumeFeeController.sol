// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

/**
 * This contract exports CurveYield's volume-adaptive fee state into a separate deployed component
 * so V14 hook wrappers can stay below EIP-170 while original hook/reference files remain unchanged.
 */

import { IVault } from "@balancer-labs/v3-interfaces/contracts/vault/IVault.sol";
import {
    SingletonAuthentication
} from "@balancer-labs/v3-vault/contracts/SingletonAuthentication.sol";

import { PoolFeePolicyRegistry } from "../PoolFeePolicyRegistry.sol";
import {
    ActivityState,
    CallerIsNotCreatorController,
    CreatorChangesAreFrozen,
    CreatorConfigDelayNotElapsed,
    CurveYieldHookConstants,
    CurveYieldPoolKind,
    InvalidTokenCount,
    PendingCreatorConfigNotFound,
    PendingVolumeFeeConfig,
    PoolNotRegistered,
    VolumeFeeConfig
} from "./CurveYieldHookTypes.sol";
import { CurveYieldObservationController } from "./CurveYieldObservationController.sol";
import { VolumeAdaptiveFee } from "./VolumeAdaptiveFee.sol";

contract CurveYieldVolumeFeeController is SingletonAuthentication {
    uint64 internal constant _DEFAULT_WEIGHTED_MAX_SURCHARGE = 0.03e18;
    uint64 internal constant _DEFAULT_STABLE_MAX_SURCHARGE = 0.01e18;
    uint8 internal constant _DEFAULT_REACTIVENESS = 20;
    uint8 internal constant _DEFAULT_HALF_LIFE_HOURS = 8;

    PoolFeePolicyRegistry internal immutable _poolFeePolicyRegistry;
    CurveYieldObservationController internal immutable _observationController;

    mapping(address hook => bool approved) public isApprovedHook;
    mapping(address pool => CurveYieldPoolKind kind) public registeredPoolKind;
    mapping(address pool => VolumeFeeConfig config) public poolVolumeFeeConfig;
    mapping(address pool => PendingVolumeFeeConfig config) public pendingVolumeFeeConfig;
    mapping(address pool => ActivityState state) internal _poolActivityState;

    error ZeroAddress();
    error UnauthorizedHook(address hook);

    event ApprovedHookSet(address indexed hook, bool approved);
    event PoolRegistered(address indexed pool, CurveYieldPoolKind indexed kind);
    event CreatorVolumeFeeConfigQueued(
        address indexed pool,
        uint256 maxVolumeSurcharge,
        uint8 reactiveness,
        uint8 halfLifeHours,
        uint48 executableAt
    );
    event CreatorVolumeFeeConfigCancelled(address indexed pool);
    event PoolVolumeFeeConfigSet(
        address indexed pool,
        uint256 maxVolumeSurcharge,
        uint8 reactiveness,
        uint8 halfLifeHours
    );
    event CreatorVolumeFeeConfigFreezeSet(address indexed pool, bool frozen);

    modifier onlyApprovedHook() {
        if (!isApprovedHook[msg.sender]) revert UnauthorizedHook(msg.sender);
        _;
    }

    constructor(
        IVault vault,
        PoolFeePolicyRegistry poolFeePolicyRegistry,
        CurveYieldObservationController observationController
    ) SingletonAuthentication(vault) {
        if (address(poolFeePolicyRegistry) == address(0) || address(observationController) == address(0)) {
            revert ZeroAddress();
        }
        _poolFeePolicyRegistry = poolFeePolicyRegistry;
        _observationController = observationController;
    }

    function setApprovedHook(address hook, bool approved) external authenticate {
        if (hook == address(0)) revert ZeroAddress();
        isApprovedHook[hook] = approved;
        emit ApprovedHookSet(hook, approved);
    }

    function registerPool(address pool, CurveYieldPoolKind kind) external onlyApprovedHook {
        if (pool == address(0)) revert ZeroAddress();
        registeredPoolKind[pool] = kind;
        poolVolumeFeeConfig[pool] = VolumeFeeConfig({
            maxVolumeSurcharge: kind == CurveYieldPoolKind.WEIGHTED
                ? _DEFAULT_WEIGHTED_MAX_SURCHARGE
                : _DEFAULT_STABLE_MAX_SURCHARGE,
            reactiveness: _DEFAULT_REACTIVENESS,
            halfLifeHours: _DEFAULT_HALF_LIFE_HOURS,
            creatorChangesFrozen: false
        });
        emit PoolRegistered(pool, kind);
    }

    function queueCreatorVolumeFeeConfig(
        address pool,
        uint256 maxVolumeSurcharge,
        uint8 reactiveness,
        uint8 halfLifeHours
    ) external {
        CurveYieldPoolKind kind = _poolKind(pool);
        _ensureCreatorController(pool);
        if (poolVolumeFeeConfig[pool].creatorChangesFrozen) {
            revert CreatorChangesAreFrozen(pool);
        }
        VolumeAdaptiveFee.validateConfig(kind, maxVolumeSurcharge, reactiveness, halfLifeHours);

        uint48 executableAt = uint48(block.timestamp) + CurveYieldHookConstants.CREATOR_CONFIG_DELAY;
        pendingVolumeFeeConfig[pool] = PendingVolumeFeeConfig({
            maxVolumeSurcharge: uint64(maxVolumeSurcharge),
            reactiveness: reactiveness,
            halfLifeHours: halfLifeHours,
            executableAt: executableAt,
            exists: true
        });
        emit CreatorVolumeFeeConfigQueued(
            pool,
            maxVolumeSurcharge,
            reactiveness,
            halfLifeHours,
            executableAt
        );
    }

    function cancelCreatorVolumeFeeConfig(address pool) external {
        _poolKind(pool);
        _ensureCreatorController(pool);
        _deletePendingCreatorConfig(pool);
    }

    function executeCreatorVolumeFeeConfig(address pool) external {
        CurveYieldPoolKind kind = _poolKind(pool);
        PendingVolumeFeeConfig memory pending = pendingVolumeFeeConfig[pool];
        if (!pending.exists) revert PendingCreatorConfigNotFound(pool);
        if (block.timestamp < pending.executableAt) {
            revert CreatorConfigDelayNotElapsed(pool, pending.executableAt);
        }
        VolumeAdaptiveFee.validateConfig(
            kind,
            pending.maxVolumeSurcharge,
            pending.reactiveness,
            pending.halfLifeHours
        );
        _setPoolVolumeFeeConfig(
            pool,
            pending.maxVolumeSurcharge,
            pending.reactiveness,
            pending.halfLifeHours
        );
        delete pendingVolumeFeeConfig[pool];
    }

    function setPoolVolumeFeeConfigImmediately(
        address pool,
        uint256 maxVolumeSurcharge,
        uint8 reactiveness,
        uint8 halfLifeHours
    ) external authenticate {
        CurveYieldPoolKind kind = _poolKind(pool);
        VolumeAdaptiveFee.validateConfig(kind, maxVolumeSurcharge, reactiveness, halfLifeHours);
        _setPoolVolumeFeeConfig(pool, maxVolumeSurcharge, reactiveness, halfLifeHours);
        delete pendingVolumeFeeConfig[pool];
    }

    function cancelPendingCreatorVolumeFeeConfig(address pool) external authenticate {
        _poolKind(pool);
        _deletePendingCreatorConfig(pool);
    }

    function freezeCreatorVolumeFeeConfig(address pool, bool frozen) external authenticate {
        _poolKind(pool);
        poolVolumeFeeConfig[pool].creatorChangesFrozen = frozen;
        if (frozen) delete pendingVolumeFeeConfig[pool];
        emit CreatorVolumeFeeConfigFreezeSet(pool, frozen);
    }

    function recordSwapActivity(
        address pool,
        uint256 amountGivenScaled18,
        uint256 selectedTokenIndex,
        uint256[] memory balancesScaled18
    ) external onlyApprovedHook returns (uint128 activity) {
        CurveYieldPoolKind kind = _poolKind(pool);
        VolumeFeeConfig memory config = poolVolumeFeeConfig[pool];
        ActivityState storage state = _poolActivityState[pool];
        uint48 timestamp = uint48(block.timestamp);
        uint256 elapsed = state.lastUpdated == 0 ? 0 : timestamp - state.lastUpdated;
        uint256 turnover = _turnover(kind, pool, amountGivenScaled18, selectedTokenIndex, balancesScaled18);

        activity = VolumeAdaptiveFee.nextActivity(
            state.activity,
            turnover,
            elapsed,
            uint256(config.halfLifeHours) * 1 hours
        );
        state.activity = activity;
        state.lastUpdated = timestamp;
    }

    function currentVolumeSurcharge(address pool) external view returns (uint256) {
        CurveYieldPoolKind kind = _poolKind(pool);
        VolumeFeeConfig memory config = poolVolumeFeeConfig[pool];
        ActivityState memory state = _poolActivityState[pool];
        uint256 elapsed = state.lastUpdated == 0 ? 0 : block.timestamp - state.lastUpdated;
        uint256 activity = VolumeAdaptiveFee.decayActivity(
            state.activity,
            elapsed,
            uint256(config.halfLifeHours) * 1 hours
        );
        uint256 maximumFeeTurnover = VolumeAdaptiveFee.threshold(
            kind,
            config.reactiveness,
            config.halfLifeHours
        );
        return VolumeAdaptiveFee.volumeSurcharge(
            activity,
            maximumFeeTurnover,
            config.maxVolumeSurcharge
        );
    }

    function previewVolumeSurcharge(
        address pool,
        uint256 amountGivenScaled18,
        uint256 selectedTokenIndex,
        uint256[] memory balancesScaled18
    ) external view returns (uint256) {
        CurveYieldPoolKind kind = _poolKind(pool);
        VolumeFeeConfig memory config = poolVolumeFeeConfig[pool];
        ActivityState memory state = _poolActivityState[pool];
        uint256 elapsed = state.lastUpdated == 0 ? 0 : block.timestamp - state.lastUpdated;
        uint256 turnover = _turnover(kind, pool, amountGivenScaled18, selectedTokenIndex, balancesScaled18);

        uint256 activity = VolumeAdaptiveFee.nextActivity(
            state.activity,
            turnover,
            elapsed,
            uint256(config.halfLifeHours) * 1 hours
        );
        uint256 maximumFeeTurnover = VolumeAdaptiveFee.threshold(
            kind,
            config.reactiveness,
            config.halfLifeHours
        );
        return VolumeAdaptiveFee.volumeSurcharge(
            activity,
            maximumFeeTurnover,
            config.maxVolumeSurcharge
        );
    }

    function getPoolActivityState(
        address pool
    ) external view returns (uint128 activity, uint48 lastUpdated) {
        ActivityState memory state = _poolActivityState[pool];
        return (state.activity, state.lastUpdated);
    }

    function _turnover(
        CurveYieldPoolKind kind,
        address pool,
        uint256 amountGivenScaled18,
        uint256 selectedTokenIndex,
        uint256[] memory balancesScaled18
    ) private view returns (uint256) {
        if (kind == CurveYieldPoolKind.WEIGHTED) {
            if (selectedTokenIndex >= balancesScaled18.length) {
                revert InvalidTokenCount(balancesScaled18.length);
            }
            return VolumeAdaptiveFee.weightedTurnover(
                amountGivenScaled18,
                _observationController.normalizedWeight(pool, selectedTokenIndex),
                balancesScaled18[selectedTokenIndex]
            );
        }
        return VolumeAdaptiveFee.stableTurnover(amountGivenScaled18, balancesScaled18);
    }

    function _poolKind(address pool) private view returns (CurveYieldPoolKind kind) {
        kind = registeredPoolKind[pool];
        if (kind == CurveYieldPoolKind.NONE) revert PoolNotRegistered(pool);
    }

    function _setPoolVolumeFeeConfig(
        address pool,
        uint256 maxVolumeSurcharge,
        uint8 reactiveness,
        uint8 halfLifeHours
    ) private {
        bool frozen = poolVolumeFeeConfig[pool].creatorChangesFrozen;
        poolVolumeFeeConfig[pool] = VolumeFeeConfig({
            maxVolumeSurcharge: uint64(maxVolumeSurcharge),
            reactiveness: reactiveness,
            halfLifeHours: halfLifeHours,
            creatorChangesFrozen: frozen
        });
        emit PoolVolumeFeeConfigSet(pool, maxVolumeSurcharge, reactiveness, halfLifeHours);
    }

    function _deletePendingCreatorConfig(address pool) private {
        if (!pendingVolumeFeeConfig[pool].exists) revert PendingCreatorConfigNotFound(pool);
        delete pendingVolumeFeeConfig[pool];
        emit CreatorVolumeFeeConfigCancelled(pool);
    }

    function _ensureCreatorController(address pool) private view {
        if (msg.sender != _poolFeePolicyRegistry.creatorControllerOf(pool)) {
            revert CallerIsNotCreatorController(pool, msg.sender);
        }
    }
}
