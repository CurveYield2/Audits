const forking =
  process.env.HARDHAT_DISABLE_FORK === "1"
    ? undefined
    : {
        url:
          process.env.HARDHAT_FORK_URL ||
          "https://base-mainnet.core.chainstack.com/e9c42c80240f7039626857286cb976bc",
      };

module.exports = {
  solidity: "0.8.30",
  networks: {
    hardhat: {
      chainId: 8453,
      initialBaseFeePerGas: 1_000_000,
      ...(forking ? { forking } : {}),
    },
  },
};
