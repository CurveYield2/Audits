# Contract Classification and Roles

## Classification Key

- **Pure Balancer fork:** exact upstream source compiled directly from the vendored Balancer tree. No CurveYield source modification.
- **Adapted Balancer fork:** Balancer logic retained but intentionally extended or restricted by CurveYield.
- **CurveYield custom:** designed for CurveYield, although it may use Balancer interfaces and base utilities.
- **Support source:** library, interface, or abstract module used by deployable contracts.

## Pure Balancer V3 and ReClamm Deployments

| Contract | Purpose and role | Primary relationships |
|---|---|---|
| `TimelockAuthorizer` | Balancer-native Vault permission authority and root-transfer system. | Installed on `Vault`; grants action IDs to DAO, settlement router, and initial configurator. |
| `ProtocolFeeController` | Calculates, accrues, and withdraws protocol fees for registered pools. | Constructed for the predicted `Vault`; authorizes `FeeSettlementRouter.withdrawProtocolFees`. |
| `VaultAdmin` | Administrative implementation for Vault configuration and pool lifecycle controls. | Bound to the predicted `Vault`; called through Vault delegation. |
| `VaultExtension` | Main extension implementation containing Vault operational logic. | Bound to `Vault` and `VaultAdmin`; passed into the `Vault` constructor. |
| `Vault` | Core Balancer V3 accounting, pool registration, token custody, hooks, swaps, and liquidity operations. | Central dependency for every pool, router, factory, hook, and fee component. |
| `Router` | Standard single-operation swaps and liquidity actions. | Calls `Vault`; used by users, settlement, and permanent-liquidity flows. |
| `BatchRouter` | Balancer-native batched and multistep routing. | Calls `Vault`; exposed as general CurveYield routing infrastructure. |
| `CompositeLiquidityRouter` | Balancer-native composite liquidity operations. | Calls `Vault`; supports complex liquidity operations without modifying core accounting. |
| `BalancerContractRegistry` | Canonical registry and aliases for routers, factories, hooks, and helpers. | Used by hooks and off-chain integrations to identify approved protocol components. |
| `ProtocolFeeSweeper` | Balancer-native administrative recovery/sweeping utility. | Connected to `Vault`; fee recipient is the CurveYield DAO. |
| `ReClammPoolHelper` | Upstream ReClamm helper for price and centeredness calculations. | Used by `CurveYieldReClammPoolFactory` and ReClamm pools. |

## Upstream Pool Implementations Created by Factories

These implementations are not global constructor deployments in the script; factory calls deploy them per pool.

| Pool implementation | Lineage | Role |
|---|---|---|
| `WeightedPool` | Pure Balancer V3 | Configurable-weight pools for non-correlated assets. |
| `StablePool` | Pure Balancer V3 | Amplified invariant pools for correlated assets. |
| Stable pool plus StableSurge hook | Pure Balancer pool with adapted hook | Stable invariant with dynamic imbalance and volume fees. |
| `ReClammPool` | Pure upstream ReClamm | Readjusting concentrated-liquidity pool. ReClamm settlement protections remain a separate concern. |

## Adapted Balancer Forks

| Contract | Purpose and modifications | Primary relationships |
|---|---|---|
| `CurveYieldWeightedPoolFactory` | Balancer WeightedPool factory with CurveYield factory allowlisting. | Only approved creators, principally the public wrapper, may deploy pools; registers pools in `Vault`. |
| `CurveYieldStablePoolFactory` | Balancer StablePool factory with the same creation restriction. | Called by `CurveYieldPoolFactoryWrapper`; registers pools in `Vault`. |
| `CurveYieldStableSurgePoolFactory` | Balancer StableSurge factory adapted to the CurveYield composite StableSurge/volume hook and wrapper allowlist. | Creates stable pools tied to `CurveYieldStableSurgeVolumeHookV14`. |
| `CurveYieldReClammPoolFactory` | ReClamm factory with CurveYield wrapper allowlisting. | Uses `Vault` and `ReClammPoolHelper`; called by the wrapper. |
| `CurveYieldMevVolumeHookV14` | Balancer MEV Capture logic combined with CurveYield volume-adaptive fees and time-weighted observation support. | Reads the registry and policy registry; uses hook, observation, and volume controllers; protects settlement BPT joins. |
| `CurveYieldStableSurgeVolumeHookV14` | Balancer StableSurge logic combined with CurveYield volume-adaptive fees and observations. | Used by StableSurge pools and the protected settlement path. |
| `CurveYieldCompositeHookBaseV14` | Shared Balancer-derived authentication, hook admission, registry, observation, and settlement-protection base. | Parent of both V14 hooks. |
| `PoolObservation` | Balancer-oracle-derived rolling observation storage. | Parent of `CurveYieldObservationController`. |
| `ObservationQueryProcessor` | Balancer-oracle-derived library for time-weighted settlement quotes. | Linked into observation and protected BPT settlement logic. |
| `StableSurgeQueryProcessor` | Balancer StableSurge-derived query and median calculation library. | Linked into `CurveYieldStableSurgeVolumeHookV14`. |

## CurveYield Fee and Settlement Contracts

| Contract | Purpose and role | Primary relationships |
|---|---|---|
| `PoolFeePolicyRegistry` | Stores immutable-at-creation creator fee policy and DAO-managed protocol settlement settings for each pool. | Registered only by approved wrapper; reads `Vault`; consumed by splitters, hooks, and settlement router. |
| `AdminFeeSplitter` | Applies the configured admin-side allocation weights to collected protocol-fee revenue. | Reads `PoolFeePolicyRegistry`; called by `FeeSettlementRouter`. |
| `CreatorFeeSplitter` | Per-pool receiver and accounting component for creator-side fee revenue. | Deployed by wrapper; registered with settlement router; creator may update only the permitted payout address/configuration. |
| `FeeSettlementRouter` | Claims protocol and creator fee tokens, attempts protected same-pool BPT settlement, handles permanent-liquidity allocations, and routes configured payouts or fallback storage. | Calls `ProtocolFeeController`, `Vault`, `Router`, splitters, hooks, and `PermanentLiquidityVaultV2`; callable through approved keepers. |
| `FeeSettlementKeeper` | Public one-input entrypoint for collecting all fee tokens associated with a pool. | Calls `FeeSettlementRouter.collect(pool)` using keeper authorization. |
| `PermanentLiquidityVaultV2` | Holds DAO-owned permanent BPT and permits only governed atomic migrations. | Receives BPT from settlement; uses `Router`, `Vault`, `RouteRegistry`, Permit2, and the authorized adapter. |
| `RouteRegistry` | Retained migration route and adapter authorization registry. | Read by `PermanentLiquidityVaultV2`; approves `BalancerV3SwapAdapter`. It is not a general fee-payout route system. |
| `BalancerV3SwapAdapter` | Executes authorized Balancer V3 swaps for migration workflows. | Calls the fresh `Router`; authorized for the permanent-liquidity vault. |

## CurveYield Pool Creation and Access Control

| Contract | Purpose and role | Primary relationships |
|---|---|---|
| `CurveYieldPoolFactoryWrapper` | Public pool-creation gateway. Validates tokens and fees, predicts pool addresses, deploys each creator splitter, registers policy, and calls the selected allowlisted factory. | Calls all four factories, `PoolFeePolicyRegistry`, `ProtocolFeeController`, and `FeeSettlementRouter`. |
| `CurveYieldFactoryAllowlist` | Shared restriction preventing direct factory use that bypasses wrapper registration. | Inherited by each CurveYield pool factory; DAO manages allowed pool creators. |
| `CurveYieldBootstrapAuthorizer` | Minimal temporary authorizer used to resolve the Vault/TimelockAuthorizer constructor dependency. | Initially passed to `Vault`; replaced by `TimelockAuthorizer` during configuration. It has no intended continuing governance role. |

## CurveYield Hook Controllers and Libraries

| Contract | Purpose and role | Primary relationships |
|---|---|---|
| `CurveYieldHookConfigController` | Central approved-hook, factory-kind, settlement-oracle, pause, and combined-fee-cap configuration. | Authenticated through `Vault`/Authorizer; read by both hooks and settlement router. |
| `CurveYieldObservationController` | Stores approved-hook observations and exposes time-weighted pool data. | Writes are restricted to approved hooks; queried for settlement protection. |
| `CurveYieldVolumeFeeController` | Calculates and controls pool volume-adaptive surcharge configuration. | Reads policy and observation state; callable by approved hooks. |
| `VolumeAdaptiveFee` | Pure math for decay, turnover/reactiveness, and nonlinear dynamic-fee interpolation. | Used by `CurveYieldVolumeFeeController`. |
| `CurveYieldHookTypes` | Shared hook configuration constants and types. | Imported by hooks and controllers. |
| `CurveYieldFeeMath` | Shared fee-allocation arithmetic and caps. | Used by fee policy and settlement components. |

## Interfaces and Small Utilities

The `contracts/interfaces/`, `contracts/utils/`, and `contracts/lib/Errors.sol` files define local ABI boundaries, safe ERC-20 transfer handling, common errors, and factory/hook provenance checks. They do not hold funds or protocol state independently, but they are in audit scope because incorrect ABI assumptions could affect settlement or pool creation.

## Ownership and Control

- Initial deployment/configuration is performed by `0x11b78837cadC8E894F1c6e13fA9f3A085a75FA35`.
- The intended final owner and governance authority is the CurveYield DAO at `0x7142b1Cc5F91A736A62e77581F406338328F05bC`.
- Factory creation is restricted to approved creator contracts, while the wrapper itself remains public.
- The deployment script grants the settlement router only the protocol-fee withdrawal permission it requires.

